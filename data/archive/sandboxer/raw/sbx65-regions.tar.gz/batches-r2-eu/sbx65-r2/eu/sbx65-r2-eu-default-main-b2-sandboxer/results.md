# Sandbox provider benchmark sbx65-r2-eu-default-main-b2-sandboxer

Schema v2 · 2026-10-28T19:02:31.307Z · seed 45 · track default
Allocation sandboxer: requested null; template default
Collection: 2026-10-28T19:02:31.307Z through 2026-10-28T19:07:52.918Z
Host: Intel Core Processor (Haswell, no TSX); linux; v26.3.0
Metadata: {"repositoryCommit":"a89eb27916660b995e632ee91e2691058b37f907","harnessCommit":"a89eb27916660b995e632ee91e2691058b37f907","sdkCommit":"dfbd85047ebe9687da6865799dbdde01507b87fb","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"runnerRegion":"eu","runner":{"region":"eu","label":"eu-ovh-frankfurt","transport":"ssh","host":"redacted","datacenter":{"provider":"ovh","location":"Frankfurt, DE (vps-41a131f1)","serverType":"VPS 2 vCore / 4 GB"},"batchId":"sbx65-r2"},"clientLocation":{"ip":"redacted","city":"Frankfurt am Main","region":"Hesse","country":"DE","org":"AS16276 OVH SAS"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: nearest

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|cold|ms|10|0|0|0|923.68 [909.34, 1004.7]|1101.8|1101.8|953.12 [909.46, 1001.5]|834.13|1101.8|74.238|100.0% [0.72247, 1.0000]|0.00013000 USD|
|sandboxer|fingerprint|ms|10|0|0|0|1579.1 [1578.2, 1581.5]|1592.3|1592.3|1581.1 [1579.0, 1583.8]|1578.0|1592.3|4.1406|100.0% [0.72247, 1.0000]|0.00020000 USD|
|sandboxer|perf|ms|9|1|0|0|580.42 [578.87, 581.20]|1582.6|1582.6|691.31 [579.39, 914.31]|578.15|1582.6|315.11|90.0% [0.59585, 0.98212]|0.00011000 USD|
|sandboxer|cpu-single|iterations/s|9|1|0|0|1.8098e+7 [1.7751e+7, 1.8580e+7]|2.0132e+7|2.0132e+7|1.8085e+7 [1.7388e+7, 1.8750e+7]|1.5854e+7|2.0132e+7|1.0304e+6|90.0% [0.59585, 0.98212]|0.00011000 USD|
|sandboxer|cpu-all|iterations/s|9|1|0|0|5.8719e+7 [5.1004e+7, 6.3419e+7]|6.3989e+7|6.3989e+7|5.7750e+7 [5.4460e+7, 6.1032e+7]|4.9615e+7|6.3989e+7|5.0172e+6|90.0% [0.59585, 0.98212]|0.00011000 USD|
|sandboxer|memory-mbps|MB/s|9|1|0|0|44599 [43100, 46757]|49984|49984|44280 [41689, 46389]|35963|49984|3582.0|90.0% [0.59585, 0.98212]|0.00011000 USD|
|sandboxer|disk-write-mbps|MB/s|9|1|0|0|1860.6 [1798.2, 1867.9]|1871.3|1871.3|1686.2 [1354.2, 1863.4]|374.67|1871.3|464.38|90.0% [0.59585, 0.98212]|0.00011000 USD|
|sandboxer|disk-read-mbps|MB/s|9|1|0|0|19844 [18021, 22196]|22507|22507|18258 [14140, 20944]|2823.7|22507|5650.2|90.0% [0.59585, 0.98212]|0.00011000 USD|
|sandboxer|disk-4k-write-iops|IOPS|9|1|0|0|11910 [9094.4, 12176]|12450|12450|10169 [7505.8, 11984]|356.47|12450|3633.2|90.0% [0.59585, 0.98212]|0.00011000 USD|
|sandboxer|disk-4k-read-iops|IOPS|9|1|0|0|6.2984e+5 [6.0867e+5, 6.4849e+5]|6.5464e+5|6.5464e+5|5.7222e+5 [4.4831e+5, 6.3978e+5]|87356|6.5464e+5|1.7192e+5|90.0% [0.59585, 0.98212]|0.00011000 USD|
|sandboxer|tcp-ms|ms|9|1|0|0|1.4990 [1.4712, 1.5572]|2.7925|2.7925|1.6433 [1.4844, 1.9358]|1.4529|2.7925|0.40745|90.0% [0.59585, 0.98212]|0.00011000 USD|
|sandboxer|command|ms|10|0|0|0|378.38 [376.90, 381.13]|383.30|383.30|379.25 [377.57, 380.86]|374.69|383.30|2.6667|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|npm-install-prepare|ms|3|0|0|0|3990.1 [3868.6, 4021.5]|4021.5|4021.5|3960.1 [3868.6, 4021.5]|3868.6|4021.5|65.904|100.0% [0.43850, 1.0000]|0.00013000 USD|
|sandboxer|npm-install|ms|3|0|0|0|780.12 [778.43, 781.90]|781.90|781.90|780.15 [778.43, 781.90]|778.43|781.90|1.4169|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|preview-provisioning|ms|3|0|0|0|289.71 [288.69, 292.30]|292.30|292.30|290.23 [288.69, 292.30]|288.69|292.30|1.5192|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|dev-server|ms|3|0|0|0|4299.1 [4284.4, 4337.3]|4337.3|4337.3|4307.0 [4284.4, 4337.3]|4284.4|4337.3|22.304|100.0% [0.43850, 1.0000]|0.00015000 USD|
|sandboxer|preview-first-byte|ms|3|0|0|0|669.06 [579.69, 744.48]|744.48|744.48|664.41 [579.69, 744.48]|579.69|744.48|67.354|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|edit-loop|ms|2|1|0|0|1284.8 [1284.8, 1304.8]|1304.8|1304.8|1294.8 [1284.8, 1304.8]|1284.8|1304.8|10.014|66.7% [0.20766, 0.93851]|0.000050000 USD|
|sandboxer|pause-resume|ms|10|0|0|0|1512.9 [1512.0, 1528.9]|1611.6|1611.6|1526.8 [1513.9, 1546.9]|1508.9|1611.6|29.193|100.0% [0.72247, 1.0000]|0.00020000 USD|
|sandboxer|tool-replay|ms|3|0|0|0|43032 [42958, 43220]|43220|43220|43070 [42958, 43220]|42958|43220|110.24|100.0% [0.43850, 1.0000]|0.0013100 USD|
|sandboxer|files-1kb|ms|9|1|0|0|810.21 [806.42, 843.86]|1010.7|1010.7|841.25 [811.48, 886.88]|803.43|1010.7|61.886|90.0% [0.59585, 0.98212]|0.00011000 USD|
|sandboxer|git-clone|ms|2|1|0|0|1781.0 [1781.0, 1980.0]|1980.0|1980.0|1880.5 [1781.0, 1980.0]|1781.0|1980.0|99.480|66.7% [0.20766, 0.93851]|0.000050000 USD|
|sandboxer|pip-install|ms|2|1|0|0|2780.9 [2780.9, 2781.4]|2781.4|2781.4|2781.2 [2780.9, 2781.4]|2780.9|2781.4|0.26201|66.7% [0.20766, 0.93851]|0.000070000 USD|
|sandboxer|reconnect|ms|10|0|0|0|686.44 [677.59, 714.74]|716.51|716.51|694.53 [684.25, 704.95]|676.38|716.51|16.898|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|files-10mb|ms|9|1|0|0|6551.5 [6000.7, 6646.4]|6783.1|6783.1|6411.5 [6219.3, 6592.3]|5967.4|6783.1|285.47|90.0% [0.59585, 0.98212]|0.00067000 USD|
|sandboxer|destroy|ms|10|0|0|0|520.58 [520.18, 522.55]|862.76|862.76|555.28 [520.48, 623.82]|519.74|862.76|102.50|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|reconnect-cleanup|ms|10|0|0|0|0.35474 [0.24451, 0.48117]|0.59457|0.59457|0.38638 [0.31177, 0.46273]|0.23023|0.59457|0.12183|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|sandbox-lifetime|ms|10|0|0|0|13923 [13525, 71445]|76228|76228|31879 [14050, 50007]|13213|76228|27457|100.0% [0.72247, 1.0000]|0.0032600 USD|
|sandboxer|tool-replay-prepare|ms|2|0|0|0|3958.3 [3958.3, 3976.2]|3976.2|3976.2|3967.2 [3958.3, 3976.2]|3958.3|3976.2|8.9618|100.0% [0.34238, 1.0000]|0.000080000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux azure-jovial-peach 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux modern-loyal-sapphire 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux polite-casual-buffalo 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux wise-perky-raven 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux dense-golden-breeze 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux zealous-major-squid 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux easy-daring-husky 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux fluent-hidden-hawk 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux placid-urban-rabbit 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux global-glossy-badger 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|0.0032600|0.32600|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|unknown|0.017400|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|0/219|0.018179|0.18500|1.0271e+5|1.4539e+5|

Flagged samples:

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 10 sandbox attempts, estimated budget USD 0.0032600; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.
- sandboxer/files-10mb failure: Sandboxer request failed (HTTP 502). The provider reported unavailable. Check the sandbox and Sandboxer service before retrying.
- sandboxer/edit-loop failure: Sandboxer request failed (HTTP 502). The provider reported unavailable. Check the sandbox and Sandboxer service before retrying.
- sandboxer/files-1kb failure: Sandboxer request failed (HTTP 502). The provider reported unavailable. Check the sandbox and Sandboxer service before retrying.
- sandboxer/pip-install failure: Command launch outcome is unknown; inspect or destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/git-clone failure: Command launch outcome is unknown; inspect or destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/perf failure: Command launch outcome is unknown; inspect or destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/cpu-single failure: Command launch outcome is unknown; inspect or destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/cpu-all failure: Command launch outcome is unknown; inspect or destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/memory-mbps failure: Command launch outcome is unknown; inspect or destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/disk-write-mbps failure: Command launch outcome is unknown; inspect or destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/disk-read-mbps failure: Command launch outcome is unknown; inspect or destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/disk-4k-write-iops failure: Command launch outcome is unknown; inspect or destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/disk-4k-read-iops failure: Command launch outcome is unknown; inspect or destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/tcp-ms failure: Command launch outcome is unknown; inspect or destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. Starts are admitted against live minute/hour/day limits before scenario deadlines; quota-waits.ndjson records admission wait separately from measured phases. The comp account supports 25 active sandboxes.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
