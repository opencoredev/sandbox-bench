# Sandbox provider benchmark sbx65-r2-eu-default-main-b1-sandboxer

Schema v2 · 2026-10-28T18:57:21.139Z · seed 45 · track default
Allocation sandboxer: requested null; template default
Collection: 2026-10-28T18:57:21.139Z through 2026-10-28T19:02:23.439Z
Host: Intel Core Processor (Haswell, no TSX); linux; v26.3.0
Metadata: {"repositoryCommit":"a89eb27916660b995e632ee91e2691058b37f907","harnessCommit":"a89eb27916660b995e632ee91e2691058b37f907","sdkCommit":"dfbd85047ebe9687da6865799dbdde01507b87fb","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"runnerRegion":"eu","runner":{"region":"eu","label":"eu-ovh-frankfurt","transport":"ssh","host":"redacted","datacenter":{"provider":"ovh","location":"Frankfurt, DE (vps-41a131f1)","serverType":"VPS 2 vCore / 4 GB"},"batchId":"sbx65-r2"},"clientLocation":{"ip":"redacted","city":"Frankfurt am Main","region":"Hesse","country":"DE","org":"AS16276 OVH SAS"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: nearest

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|cold|ms|10|0|0|0|928.02 [868.16, 938.58]|1346.1|1346.1|960.13 [900.21, 1050.3]|860.89|1346.1|133.19|100.0% [0.72247, 1.0000]|0.00011000 USD|
|sandboxer|fingerprint|ms|10|0|0|0|1589.8 [1588.6, 1591.7]|1595.0|1595.0|1590.5 [1589.3, 1591.9]|1587.6|1595.0|2.0778|100.0% [0.72247, 1.0000]|0.00020000 USD|
|sandboxer|perf|ms|9|0|1|0|589.17 [587.50, 589.76]|590.04|590.04|588.72 [588.00, 589.34]|587.01|590.04|1.0277|100.0% [0.70085, 1.0000]|0.00010000 USD|
|sandboxer|cpu-single|iterations/s|9|0|1|0|1.8042e+7 [1.4215e+7, 1.8483e+7]|1.8643e+7|1.8643e+7|1.7086e+7 [1.5454e+7, 1.8309e+7]|1.1950e+7|1.8643e+7|2.2171e+6|100.0% [0.70085, 1.0000]|0.00010000 USD|
|sandboxer|cpu-all|iterations/s|9|0|1|0|5.9505e+7 [5.3806e+7, 6.3153e+7]|6.5554e+7|6.5554e+7|5.8706e+7 [5.5208e+7, 6.2085e+7]|4.8441e+7|6.5554e+7|5.2005e+6|100.0% [0.70085, 1.0000]|0.00010000 USD|
|sandboxer|memory-mbps|MB/s|9|0|1|0|43298 [39215, 47469]|47659|47659|43194 [40592, 45732]|36760|47659|3982.6|100.0% [0.70085, 1.0000]|0.00010000 USD|
|sandboxer|disk-write-mbps|MB/s|9|0|1|0|1831.6 [1756.1, 1890.3]|1923.7|1923.7|1768.1 [1600.9, 1870.0]|1150.0|1923.7|222.94|100.0% [0.70085, 1.0000]|0.00010000 USD|
|sandboxer|disk-read-mbps|MB/s|9|0|1|0|19203 [18677, 20284]|22917|22917|19723 [18952, 20694]|18060|22917|1327.1|100.0% [0.70085, 1.0000]|0.00010000 USD|
|sandboxer|disk-4k-write-iops|IOPS|9|0|1|0|10559 [9274.2, 11166]|11646|11646|10270 [9555.7, 10857]|8144.9|11646|999.84|100.0% [0.70085, 1.0000]|0.00010000 USD|
|sandboxer|disk-4k-read-iops|IOPS|9|0|1|0|6.4682e+5 [6.3963e+5, 6.9363e+5]|7.0365e+5|7.0365e+5|6.5933e+5 [6.4442e+5, 6.7648e+5]|6.3252e+5|7.0365e+5|24232|100.0% [0.70085, 1.0000]|0.00010000 USD|
|sandboxer|tcp-ms|ms|9|0|1|0|1.4876 [1.4585, 1.5090]|1.5142|1.5142|1.4839 [1.4679, 1.4980]|1.4411|1.5142|0.023160|100.0% [0.70085, 1.0000]|0.00010000 USD|
|sandboxer|command|ms|9|0|1|0|387.57 [387.23, 389.29]|389.90|389.90|388.09 [387.50, 388.74]|387.15|389.90|0.95903|100.0% [0.70085, 1.0000]|0.00010000 USD|
|sandboxer|npm-install-prepare|ms|2|0|1|0|3962.0 [3962.0, 4102.6]|4102.6|4102.6|4032.3 [3962.0, 4102.6]|3962.0|4102.6|70.313|100.0% [0.34238, 1.0000]|0.00010000 USD|
|sandboxer|npm-install|ms|2|0|1|0|787.68 [787.68, 788.24]|788.24|788.24|787.96 [787.68, 788.24]|787.68|788.24|0.28041|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|preview-provisioning|ms|2|0|1|0|293.30 [293.30, 294.87]|294.87|294.87|294.09 [293.30, 294.87]|293.30|294.87|0.78084|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|dev-server|ms|2|0|1|0|4414.9 [4414.9, 4444.4]|4444.4|4444.4|4429.7 [4414.9, 4444.4]|4414.9|4444.4|14.761|100.0% [0.34238, 1.0000]|0.00011000 USD|
|sandboxer|preview-first-byte|ms|2|0|1|0|540.72 [540.72, 545.61]|545.61|545.61|543.16 [540.72, 545.61]|540.72|545.61|2.4414|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|edit-loop|ms|2|0|1|0|1314.7 [1314.7, 1318.2]|1318.2|1318.2|1316.5 [1314.7, 1318.2]|1314.7|1318.2|1.7606|100.0% [0.34238, 1.0000]|0.000050000 USD|
|sandboxer|pause-resume|ms|9|0|1|0|1558.5 [1556.4, 1562.4]|1843.9|1843.9|1590.0 [1556.9, 1654.0]|1552.8|1843.9|89.789|100.0% [0.70085, 1.0000]|0.00019000 USD|
|sandboxer|tool-replay|ms|2|1|0|0|43988 [43988, 44039]|44039|44039|44014 [43988, 44039]|43988|44039|25.767|66.7% [0.20766, 0.93851]|0.0010700 USD|
|sandboxer|files-1kb|ms|10|0|0|0|826.95 [823.07, 857.59]|865.32|865.32|838.76 [828.13, 849.71]|820.51|865.32|17.187|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|git-clone|ms|2|1|0|0|1594.2 [1594.2, 1788.6]|1788.6|1788.6|1691.4 [1594.2, 1788.6]|1594.2|1788.6|97.181|66.7% [0.20766, 0.93851]|0.000050000 USD|
|sandboxer|pip-install|ms|2|0|1|0|2788.4 [2788.4, 2792.3]|2792.3|2792.3|2790.3 [2788.4, 2792.3]|2788.4|2792.3|1.9365|100.0% [0.34238, 1.0000]|0.000070000 USD|
|sandboxer|reconnect|ms|9|1|0|0|701.75 [694.91, 733.85]|735.99|735.99|712.27 [699.58, 725.22]|689.66|735.99|18.866|90.0% [0.59585, 0.98212]|0.00010000 USD|
|sandboxer|files-10mb|ms|9|0|1|0|8228.5 [7729.1, 9097.8]|15836|15836|8927.4 [7736.5, 10761]|6812.3|15836|2511.1|100.0% [0.70085, 1.0000]|0.00086000 USD|
|sandboxer|destroy|ms|10|0|0|0|535.73 [535.05, 537.53]|628.60|628.60|545.47 [535.72, 564.11]|534.34|628.60|27.733|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|reconnect-cleanup|ms|9|0|0|0|0.41983 [0.28053, 0.93774]|1.4069|1.4069|0.53540 [0.33208, 0.80054]|0.25699|1.4069|0.36455|100.0% [0.70085, 1.0000]|0.000090000 USD|
|sandboxer|sandbox-lifetime|ms|10|0|0|0|15824 [15625, 27333]|78253|78253|29935 [17202, 46128]|15167|78253|23788|100.0% [0.72247, 1.0000]|0.0030400 USD|
|sandboxer|tool-replay-prepare|ms|2|0|0|0|4043.3 [4043.3, 4061.1]|4061.1|4061.1|4052.2 [4043.3, 4061.1]|4043.3|4061.1|8.9157|100.0% [0.34238, 1.0000]|0.00010000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux indigo-airy-osprey 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux cheery-fresh-timber 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux fluent-ideal-cherry 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux misty-steady-jackal 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux fancy-tranquil-glacier 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux jaunty-vivid-creek 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux coastal-mossy-hill 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux sonic-lucid-owl 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux bold-fast-timber 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux maple-fern-stork 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|0.0030400|0.30400|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|unknown|0.015300|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|0/218|0.013717|0.66500|87548|1.1301e+5|

Flagged samples:

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 10 sandbox attempts, estimated budget USD 0.0030400; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.
- sandboxer/tool-replay failure: Sandboxer request failed (HTTP 429). The provider reported quota. Check the sandbox and Sandboxer service before retrying.
- sandboxer/git-clone failure: Sandboxer request failed (HTTP 429). The provider reported quota. Check the sandbox and Sandboxer service before retrying.
- sandboxer/reconnect failure: Sandboxer request failed (HTTP 429). The provider reported quota. Check the sandbox and Sandboxer service before retrying.
- sandboxer/perf blocked: Blocked by reconnect
- sandboxer/cpu-single blocked: Blocked by reconnect
- sandboxer/cpu-all blocked: Blocked by reconnect
- sandboxer/memory-mbps blocked: Blocked by reconnect
- sandboxer/disk-write-mbps blocked: Blocked by reconnect
- sandboxer/disk-read-mbps blocked: Blocked by reconnect
- sandboxer/disk-4k-write-iops blocked: Blocked by reconnect
- sandboxer/disk-4k-read-iops blocked: Blocked by reconnect
- sandboxer/tcp-ms blocked: Blocked by reconnect
- sandboxer/command blocked: Blocked by reconnect
- sandboxer/npm-install-prepare blocked: Blocked by reconnect
- sandboxer/npm-install blocked: Blocked by npm-install-prepare
- sandboxer/preview-provisioning blocked: Blocked by npm-install-prepare
- sandboxer/dev-server blocked: Blocked by npm-install-prepare
- sandboxer/preview-first-byte blocked: Blocked by npm-install-prepare
- sandboxer/edit-loop blocked: Blocked by npm-install-prepare
- sandboxer/pip-install blocked: Blocked by reconnect
- sandboxer/pause-resume blocked: Blocked by reconnect
- sandboxer/files-10mb blocked: Blocked by reconnect

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. Starts are admitted against live minute/hour/day limits before scenario deadlines; quota-waits.ndjson records admission wait separately from measured phases. The comp account supports 25 active sandboxes.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
