# Sandbox provider benchmark sbx65-r3-us-east-default-main-b2-sandboxer

Schema v2 · 2026-10-28T19:17:39.881Z · seed 45 · track default
Allocation sandboxer: requested null; template default
Collection: 2026-10-28T19:17:39.881Z through 2026-10-28T19:20:25.654Z
Host: AMD Ryzen 9 9955HX 16-Core Processor; linux; v26.3.0
Metadata: {"repositoryCommit":"a89eb27916660b995e632ee91e2691058b37f907","harnessCommit":"a89eb27916660b995e632ee91e2691058b37f907","sdkCommit":"dfbd85047ebe9687da6865799dbdde01507b87fb","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"runnerRegion":"us-east","runner":{"region":"us-east","label":"us-east-ms-a2","transport":"local","host":null,"datacenter":{"provider":"home","location":"Boca Raton, FL (ms-a2)"},"batchId":"sbx65-r3"},"clientLocation":{"ip":"redacted","city":"Boca Raton","region":"Florida","country":"US","org":"AS7018 AT&T Enterprises, LLC"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: nearest

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|cold|ms|10|0|0|0|350.57 [329.65, 378.37]|397.78|397.78|355.22 [340.78, 369.83]|322.95|397.78|23.726|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|fingerprint|ms|10|0|0|0|1291.5 [1278.0, 1471.1]|1484.8|1484.8|1361.2 [1303.1, 1420.5]|1276.4|1484.8|93.858|100.0% [0.72247, 1.0000]|0.00020000 USD|
|sandboxer|perf|ms|10|0|0|0|872.58 [870.42, 879.65]|913.74|913.74|878.13 [872.17, 886.76]|868.23|913.74|12.628|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|cpu-single|iterations/s|10|0|0|0|1.3726e+7 [1.3345e+7, 1.4019e+7]|1.4184e+7|1.4184e+7|1.3546e+7 [1.3007e+7, 1.3908e+7]|1.1449e+7|1.4184e+7|7.5107e+5|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|cpu-all|iterations/s|10|0|0|0|3.1086e+7 [3.0346e+7, 3.3432e+7]|3.6253e+7|3.6253e+7|3.2179e+7 [3.0821e+7, 3.3659e+7]|2.9032e+7|3.6253e+7|2.2132e+6|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|memory-mbps|MB/s|10|0|0|0|37501 [34003, 38605]|39167|39167|36731 [35131, 38090]|31426|39167|2419.2|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-write-mbps|MB/s|10|0|0|0|1612.5 [1572.1, 1691.5]|2038.1|2038.1|1667.0 [1599.5, 1764.4]|1552.6|2038.1|136.11|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-read-mbps|MB/s|10|0|0|0|20123 [9831.9, 21125]|22495|22495|17409 [13925, 20483]|8706.2|22495|5225.5|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-4k-write-iops|IOPS|10|0|0|0|724.15 [675.26, 762.46]|815.08|815.08|732.81 [700.91, 765.22]|640.88|815.08|51.398|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-4k-read-iops|IOPS|10|0|0|0|2.3623e+5 [2.3265e+5, 2.5983e+5]|2.6857e+5|2.6857e+5|2.4284e+5 [2.3461e+5, 2.5227e+5]|2.2468e+5|2.6857e+5|14043|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|tcp-ms|ms|10|0|0|0|1.3467 [1.3030, 1.4141]|1.5186|1.5186|1.3709 [1.3321, 1.4120]|1.2851|1.5186|0.064882|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|command|ms|10|0|0|0|69.991 [68.042, 74.379]|86.697|86.697|72.765 [68.862, 77.391]|64.619|86.697|6.8721|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|npm-install-prepare|ms|3|0|0|0|1297.1 [1236.5, 1341.0]|1341.0|1341.0|1291.6 [1236.5, 1341.0]|1236.5|1341.0|42.840|100.0% [0.43850, 1.0000]|0.000060000 USD|
|sandboxer|npm-install|ms|3|0|0|0|1269.4 [1073.2, 1271.9]|1271.9|1271.9|1204.9 [1073.2, 1271.9]|1073.2|1271.9|93.103|100.0% [0.43850, 1.0000]|0.000060000 USD|
|sandboxer|preview-provisioning|ms|3|0|0|0|135.17 [131.93, 135.41]|135.41|135.41|134.17 [131.93, 135.41]|131.93|135.41|1.5832|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|dev-server|ms|3|0|0|0|1130.0 [1122.9, 1139.1]|1139.1|1139.1|1130.7 [1122.9, 1139.1]|1122.9|1139.1|6.6586|100.0% [0.43850, 1.0000]|0.000060000 USD|
|sandboxer|preview-first-byte|ms|3|0|0|0|354.57 [353.67, 377.54]|377.54|377.54|361.93 [353.67, 377.54]|353.67|377.54|11.048|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|edit-loop|ms|3|0|0|0|640.89 [633.86, 668.20]|668.20|668.20|647.65 [633.86, 668.20]|633.86|668.20|14.810|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|pause-resume|ms|10|0|0|0|796.54 [788.17, 808.46]|967.41|967.41|818.37 [793.94, 853.79]|787.94|967.41|52.599|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|tool-replay|ms|3|0|0|0|16707 [16333, 18360]|18360|18360|17134 [16333, 18360]|16333|18360|880.74|100.0% [0.43850, 1.0000]|0.00053000 USD|
|sandboxer|files-1kb|ms|10|0|0|0|301.26 [285.45, 358.25]|387.09|387.09|321.20 [297.96, 345.55]|281.44|387.09|38.694|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|git-clone|ms|3|0|0|0|471.19 [466.55, 2474.5]|2474.5|2474.5|1137.4 [466.55, 2474.5]|466.55|2474.5|945.48|100.0% [0.43850, 1.0000]|0.000050000 USD|
|sandboxer|pip-install|ms|3|0|0|0|4269.0 [4074.6, 10270]|10270|10270|6204.5 [4074.6, 10270]|4074.6|10270|2875.8|100.0% [0.43850, 1.0000]|0.00021000 USD|
|sandboxer|reconnect|ms|10|0|0|0|257.08 [185.56, 267.03]|283.70|283.70|236.23 [210.74, 260.22]|184.62|283.70|39.212|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|files-10mb|ms|10|0|0|0|2738.6 [1901.3, 3205.8]|4247.4|4247.4|2832.0 [2404.4, 3269.4]|1820.1|4247.4|698.96|100.0% [0.72247, 1.0000]|0.00033000 USD|
|sandboxer|destroy|ms|10|0|0|0|347.82 [343.42, 354.98]|401.33|401.33|354.08 [346.78, 365.52]|342.17|401.33|16.329|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|reconnect-cleanup|ms|10|0|0|0|0.61326 [0.53816, 0.64975]|1.2526|1.2526|0.67034 [0.57695, 0.80830]|0.51892|1.2526|0.20209|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|sandbox-lifetime|ms|10|0|0|0|7222.1 [6375.2, 35644]|41540|41540|16435 [7196.2, 25957]|6305.0|41540|14395|100.0% [0.72247, 1.0000]|0.0017000 USD|
|sandboxer|tool-replay-prepare|ms|2|0|0|0|1372.3 [1372.3, 1548.4]|1548.4|1548.4|1460.4 [1372.3, 1548.4]|1372.3|1548.4|88.016|100.0% [0.34238, 1.0000]|0.000040000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux rustic-valid-cherry 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux solar-ready-marsh 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux stormy-placid-willow 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux grassy-limber-dolphin 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux smart-basic-badger 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux tulip-modest-thistle 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux frugal-pearly-acorn 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux valid-open-yak 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux cobalt-brave-apple 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux funny-silver-lagoon 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|0.0017000|0.17000|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|unknown|0.010200|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|0/219|0.091091|0.11281|2.8706e+5|4.3223e+5|

Flagged samples:

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 10 sandbox attempts, estimated budget USD 0.0017000; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. Starts are admitted against live minute/hour/day limits before scenario deadlines; quota-waits.ndjson records admission wait separately from measured phases. The comp account supports 25 active sandboxes.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
