# Sandbox provider benchmark sbx65-r3-us-east-default-main-b1-sandboxer

Schema v2 · 2026-10-28T19:14:59.671Z · seed 45 · track default
Allocation sandboxer: requested null; template default
Collection: 2026-10-28T19:14:59.671Z through 2026-10-28T19:17:26.540Z
Host: AMD Ryzen 9 9955HX 16-Core Processor; linux; v26.3.0
Metadata: {"repositoryCommit":"a89eb27916660b995e632ee91e2691058b37f907","harnessCommit":"a89eb27916660b995e632ee91e2691058b37f907","sdkCommit":"dfbd85047ebe9687da6865799dbdde01507b87fb","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"runnerRegion":"us-east","runner":{"region":"us-east","label":"us-east-ms-a2","transport":"local","host":null,"datacenter":{"provider":"home","location":"Boca Raton, FL (ms-a2)"},"batchId":"sbx65-r3"},"clientLocation":{"ip":"redacted","city":"Boca Raton","region":"Florida","country":"US","org":"AS7018 AT&T Enterprises, LLC"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: nearest

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|cold|ms|10|0|0|0|344.47 [324.02, 355.13]|405.45|405.45|349.19 [332.86, 367.03]|309.23|405.45|27.722|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|fingerprint|ms|10|0|0|0|1468.3 [1270.0, 1476.7]|1673.2|1673.2|1413.0 [1333.2, 1493.3]|1268.1|1673.2|128.24|100.0% [0.72247, 1.0000]|0.00020000 USD|
|sandboxer|perf|ms|10|0|0|0|871.68 [870.03, 873.89]|875.24|875.24|872.21 [871.20, 873.30]|869.91|875.24|1.6794|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|cpu-single|iterations/s|10|0|0|0|1.4038e+7 [1.3709e+7, 1.4169e+7]|1.4325e+7|1.4325e+7|1.3986e+7 [1.3858e+7, 1.4112e+7]|1.3709e+7|1.4325e+7|2.0745e+5|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|cpu-all|iterations/s|10|0|0|0|3.3998e+7 [3.0114e+7, 3.5839e+7]|3.6628e+7|3.6628e+7|3.3790e+7 [3.2339e+7, 3.5098e+7]|2.9745e+7|3.6628e+7|2.2864e+6|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|memory-mbps|MB/s|10|0|0|0|38396 [35559, 38777]|38891|38891|37532 [36138, 38583]|32063|38891|2055.1|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-write-mbps|MB/s|10|0|0|0|1624.1 [1566.0, 1685.3]|1757.6|1757.6|1644.5 [1607.4, 1684.0]|1564.3|1757.6|62.217|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-read-mbps|MB/s|10|0|0|0|10018 [8682.7, 21388]|21928|21928|15169 [11290, 18918]|8423.6|21928|6198.6|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-4k-write-iops|IOPS|10|0|0|0|681.07 [647.29, 698.72]|743.14|743.14|681.95 [664.62, 701.67]|624.27|743.14|30.184|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-4k-read-iops|IOPS|10|0|0|0|2.3556e+5 [2.3376e+5, 2.3689e+5]|5.7888e+5|5.7888e+5|2.6862e+5 [2.3128e+5, 3.3899e+5]|2.1972e+5|5.7888e+5|1.0354e+5|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|tcp-ms|ms|10|0|0|0|1.3717 [1.3129, 1.4066]|1.4731|1.4731|1.3474 [1.2562, 1.4060]|0.98960|1.4731|0.12610|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|command|ms|10|0|0|0|69.284 [65.938, 71.839]|72.549|72.549|69.158 [67.412, 70.634]|64.440|72.549|2.6056|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|npm-install-prepare|ms|3|0|0|0|1280.3 [1196.6, 1344.3]|1344.3|1344.3|1273.7 [1196.6, 1344.3]|1196.6|1344.3|60.470|100.0% [0.43850, 1.0000]|0.000060000 USD|
|sandboxer|npm-install|ms|3|0|0|0|1270.1 [1270.0, 1272.3]|1272.3|1272.3|1270.8 [1270.0, 1272.3]|1270.0|1272.3|1.0581|100.0% [0.43850, 1.0000]|0.000060000 USD|
|sandboxer|preview-provisioning|ms|3|0|0|0|133.21 [131.51, 141.21]|141.21|141.21|135.31 [131.51, 141.21]|131.51|141.21|4.2309|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|dev-server|ms|3|0|0|0|1090.5 [1064.0, 1138.6]|1138.6|1138.6|1097.7 [1064.0, 1138.6]|1064.0|1138.6|30.888|100.0% [0.43850, 1.0000]|0.000060000 USD|
|sandboxer|preview-first-byte|ms|3|0|0|0|477.18 [425.51, 930.69]|930.69|930.69|611.13 [425.51, 930.69]|425.51|930.69|226.95|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|edit-loop|ms|3|0|0|0|667.87 [650.86, 690.59]|690.59|690.59|669.78 [650.86, 690.59]|650.86|690.59|16.275|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|pause-resume|ms|10|0|0|0|795.69 [789.40, 796.71]|802.42|802.42|794.90 [792.44, 797.13]|788.37|802.42|3.8365|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|tool-replay|ms|3|0|0|0|16390 [16293, 16393]|16393|16393|16359 [16293, 16393]|16293|16393|46.782|100.0% [0.43850, 1.0000]|0.00051000 USD|
|sandboxer|files-1kb|ms|10|0|0|0|282.60 [277.54, 354.15]|377.00|377.00|312.47 [288.19, 337.86]|275.09|377.00|39.268|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|git-clone|ms|3|0|0|0|672.50 [669.62, 1268.2]|1268.2|1268.2|870.11 [669.62, 1268.2]|669.62|1268.2|281.50|100.0% [0.43850, 1.0000]|0.000040000 USD|
|sandboxer|pip-install|ms|3|0|0|0|4073.8 [4065.6, 5073.8]|5073.8|5073.8|4404.4 [4065.6, 5073.8]|4065.6|5073.8|473.35|100.0% [0.43850, 1.0000]|0.00016000 USD|
|sandboxer|reconnect|ms|10|0|0|0|191.90 [188.64, 257.44]|257.87|257.87|217.66 [197.62, 237.71]|187.49|257.87|32.662|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|files-10mb|ms|10|0|0|0|1632.0 [1613.5, 1756.2]|2743.9|2743.9|1784.7 [1642.3, 2022.3]|1611.1|2743.9|329.86|100.0% [0.72247, 1.0000]|0.00021000 USD|
|sandboxer|destroy|ms|10|0|0|0|344.18 [343.86, 344.93]|348.73|348.73|344.59 [343.56, 345.76]|341.45|348.73|1.7394|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|reconnect-cleanup|ms|10|0|0|0|0.64362 [0.52820, 0.66887]|0.82786|0.82786|0.64082 [0.58227, 0.70250]|0.50272|0.82786|0.10049|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|sandbox-lifetime|ms|10|0|0|0|6298.8 [5998.4, 33569]|34071|34071|14562 [6482.4, 22789]|5975.2|34071|12560|100.0% [0.72247, 1.0000]|0.0015300 USD|
|sandboxer|tool-replay-prepare|ms|2|0|0|0|1239.0 [1239.0, 1424.3]|1424.3|1424.3|1331.7 [1239.0, 1424.3]|1239.0|1424.3|92.643|100.0% [0.34238, 1.0000]|0.000040000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux rapid-wavy-husky 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux lucky-zealous-bluff 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux stormy-arctic-panda 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux level-clear-marsh 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux modern-cheery-ridge 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux arctic-apt-onyx 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux jolly-tranquil-arbor 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux peachy-misty-kettle 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux stormy-funny-sparrow 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux chief-lunar-willow 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|0.0015300|0.15300|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|unknown|0.0090000|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|0/219|0.048450|0.057500|4.0905e+5|6.9103e+5|

Flagged samples:

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 10 sandbox attempts, estimated budget USD 0.0015300; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. Starts are admitted against live minute/hour/day limits before scenario deadlines; quota-waits.ndjson records admission wait separately from measured phases. The comp account supports 25 active sandboxes.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
