# Sandbox provider benchmark sbx65-r3-eu-default-main-b2-sandboxer

Schema v2 · 2026-10-28T19:20:43.177Z · seed 45 · track default
Allocation sandboxer: requested null; template default
Collection: 2026-10-28T19:20:43.177Z through 2026-10-28T19:26:13.512Z
Host: Intel Core Processor (Haswell, no TSX); linux; v26.3.0
Metadata: {"repositoryCommit":"a89eb27916660b995e632ee91e2691058b37f907","harnessCommit":"a89eb27916660b995e632ee91e2691058b37f907","sdkCommit":"dfbd85047ebe9687da6865799dbdde01507b87fb","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"runnerRegion":"eu","runner":{"region":"eu","label":"eu-ovh-frankfurt","transport":"ssh","host":"redacted","datacenter":{"provider":"ovh","location":"Frankfurt, DE (vps-41a131f1)","serverType":"VPS 2 vCore / 4 GB"},"batchId":"sbx65-r3"},"clientLocation":{"ip":"redacted","city":"Frankfurt am Main","region":"Hesse","country":"DE","org":"AS16276 OVH SAS"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: nearest

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|cold|ms|10|0|0|0|907.72 [864.87, 913.75]|1257.3|1257.3|934.21 [886.25, 1011.2]|848.65|1257.3|109.93|100.0% [0.72247, 1.0000]|0.00011000 USD|
|sandboxer|fingerprint|ms|10|0|0|0|1578.3 [1577.7, 1582.2]|1592.4|1592.4|1580.9 [1578.4, 1584.2]|1576.9|1592.4|4.6658|100.0% [0.72247, 1.0000]|0.00020000 USD|
|sandboxer|perf|ms|10|0|0|0|577.95 [576.63, 579.31]|581.14|581.14|578.45 [577.48, 579.49]|576.03|581.14|1.6081|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|cpu-single|iterations/s|10|0|0|0|1.8213e+7 [1.7604e+7, 1.8381e+7]|1.8717e+7|1.8717e+7|1.8179e+7 [1.7937e+7, 1.8389e+7]|1.7578e+7|1.8717e+7|3.6422e+5|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|cpu-all|iterations/s|10|0|0|0|5.4576e+7 [5.2322e+7, 6.1238e+7]|6.6219e+7|6.6219e+7|5.7392e+7 [5.4374e+7, 6.0765e+7]|5.0930e+7|6.6219e+7|5.0135e+6|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|memory-mbps|MB/s|10|0|0|0|44791 [41887, 45826]|47701|47701|44754 [43617, 45931]|41517|47701|1914.0|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-write-mbps|MB/s|10|0|0|0|1838.3 [1758.2, 1877.0]|1948.5|1948.5|1842.9 [1806.1, 1878.7]|1741.0|1948.5|57.430|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-read-mbps|MB/s|10|0|0|0|19957 [19276, 22254]|23214|23214|20812 [19857, 21807]|18671|23214|1541.6|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-4k-write-iops|IOPS|10|0|0|0|10712 [10044, 11385]|11793|11793|10786 [10375, 11180]|9717.9|11793|639.43|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-4k-read-iops|IOPS|10|0|0|0|6.5222e+5 [6.4017e+5, 6.8075e+5]|7.0638e+5|7.0638e+5|6.5770e+5 [6.4215e+5, 6.7331e+5]|6.1286e+5|7.0638e+5|25238|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|tcp-ms|ms|10|0|0|0|1.4882 [1.4590, 1.4915]|1.5134|1.5134|1.4872 [1.4761, 1.4980]|1.4574|1.5134|0.017462|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|command|ms|10|0|0|0|378.35 [375.20, 379.78]|385.39|385.39|378.36 [376.63, 380.40]|375.05|385.39|3.0751|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|npm-install-prepare|ms|3|0|0|0|3983.1 [3879.6, 4006.4]|4006.4|4006.4|3956.4 [3879.6, 4006.4]|3879.6|4006.4|55.072|100.0% [0.43850, 1.0000]|0.00013000 USD|
|sandboxer|npm-install|ms|3|0|0|0|780.52 [777.89, 781.13]|781.13|781.13|779.85 [777.89, 781.13]|777.89|781.13|1.4061|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|preview-provisioning|ms|3|0|0|0|290.10 [289.25, 290.41]|290.41|290.41|289.92 [289.25, 290.41]|289.25|290.41|0.48927|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|dev-server|ms|3|0|0|0|4296.4 [4293.5, 4307.4]|4307.4|4307.4|4299.1 [4293.5, 4307.4]|4293.5|4307.4|5.9656|100.0% [0.43850, 1.0000]|0.00015000 USD|
|sandboxer|preview-first-byte|ms|3|0|0|0|616.56 [592.07, 648.93]|648.93|648.93|619.19 [592.07, 648.93]|592.07|648.93|23.285|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|edit-loop|ms|3|0|0|0|1289.6 [1287.6, 1291.4]|1291.4|1291.4|1289.6 [1287.6, 1291.4]|1287.6|1291.4|1.5218|100.0% [0.43850, 1.0000]|0.000060000 USD|
|sandboxer|pause-resume|ms|10|0|0|0|1512.4 [1510.0, 1513.9]|1520.7|1520.7|1512.8 [1510.9, 1515.0]|1507.5|1520.7|3.2318|100.0% [0.72247, 1.0000]|0.00020000 USD|
|sandboxer|tool-replay|ms|3|0|0|0|43008 [43002, 43025]|43025|43025|43012 [43002, 43025]|43002|43025|9.6437|100.0% [0.43850, 1.0000]|0.0013200 USD|
|sandboxer|files-1kb|ms|10|0|0|0|805.77 [798.28, 838.20]|846.33|846.33|817.14 [805.19, 829.65]|797.36|846.33|19.588|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|git-clone|ms|3|0|0|0|1779.6 [1778.4, 1784.0]|1784.0|1784.0|1780.7 [1778.4, 1784.0]|1778.4|1784.0|2.4295|100.0% [0.43850, 1.0000]|0.000060000 USD|
|sandboxer|pip-install|ms|3|0|0|0|2779.0 [2778.4, 2779.1]|2779.1|2779.1|2778.8 [2778.4, 2779.1]|2778.4|2779.1|0.29413|100.0% [0.43850, 1.0000]|0.000090000 USD|
|sandboxer|reconnect|ms|10|0|0|0|676.30 [675.81, 708.92]|712.33|712.33|689.93 [679.89, 700.00]|675.26|712.33|16.306|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|files-10mb|ms|10|0|0|0|6887.2 [6303.3, 7459.6]|8226.4|8226.4|6983.4 [6602.3, 7378.1]|6094.0|8226.4|626.27|100.0% [0.72247, 1.0000]|0.00076000 USD|
|sandboxer|destroy|ms|10|0|0|0|520.13 [519.81, 520.51]|521.84|521.84|520.44 [520.06, 520.89]|519.80|521.84|0.67047|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|reconnect-cleanup|ms|10|0|0|0|0.41594 [0.32599, 0.60110]|0.92598|0.92598|0.48821 [0.38034, 0.61289]|0.27229|0.92598|0.18796|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|sandbox-lifetime|ms|10|0|0|0|14360 [13575, 73958]|77316|77316|32740 [14369, 51371]|13414|77316|28271|100.0% [0.72247, 1.0000]|0.0033400 USD|
|sandboxer|tool-replay-prepare|ms|2|0|0|0|3975.0 [3975.0, 3976.2]|3976.2|3976.2|3975.6 [3975.0, 3976.2]|3975.0|3976.2|0.58650|100.0% [0.34238, 1.0000]|0.000080000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux honest-indigo-hornet 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux mild-vital-acorn 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux snowy-dapper-jay 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux basic-modest-atlas 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux balmy-vast-puffin 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux jovial-woody-honey 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux cyan-light-yak 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux smooth-rugged-anchor 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux shiny-mellow-peach 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux earnest-jaunty-ocelot 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|0.0033400|0.33400|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|unknown|0.017700|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|0/219|0.020687|0.17000|1.0449e+5|1.3585e+5|

Flagged samples:

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 10 sandbox attempts, estimated budget USD 0.0033400; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. Starts are admitted against live minute/hour/day limits before scenario deadlines; quota-waits.ndjson records admission wait separately from measured phases. The comp account supports 25 active sandboxes.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
