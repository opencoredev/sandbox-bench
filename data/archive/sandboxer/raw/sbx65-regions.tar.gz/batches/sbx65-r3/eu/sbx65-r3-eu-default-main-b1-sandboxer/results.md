# Sandbox provider benchmark sbx65-r3-eu-default-main-b1-sandboxer

Schema v2 · 2026-10-28T19:09:06.188Z · seed 45 · track default
Allocation sandboxer: requested null; template default
Collection: 2026-10-28T19:09:06.188Z through 2026-10-28T19:14:41.779Z
Host: Intel Core Processor (Haswell, no TSX); linux; v26.3.0
Metadata: {"repositoryCommit":"a89eb27916660b995e632ee91e2691058b37f907","harnessCommit":"a89eb27916660b995e632ee91e2691058b37f907","sdkCommit":"dfbd85047ebe9687da6865799dbdde01507b87fb","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"runnerRegion":"eu","runner":{"region":"eu","label":"eu-ovh-frankfurt","transport":"ssh","host":"redacted","datacenter":{"provider":"ovh","location":"Frankfurt, DE (vps-41a131f1)","serverType":"VPS 2 vCore / 4 GB"},"batchId":"sbx65-r3"},"clientLocation":{"ip":"redacted","city":"Frankfurt am Main","region":"Hesse","country":"DE","org":"AS16276 OVH SAS"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: nearest

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|cold|ms|10|0|0|0|922.58 [918.57, 936.73]|1083.9|1083.9|936.46 [907.95, 973.82]|856.26|1083.9|54.099|100.0% [0.72247, 1.0000]|0.00011000 USD|
|sandboxer|fingerprint|ms|10|0|0|0|1587.3 [1586.6, 1589.9]|1602.2|1602.2|1589.4 [1587.2, 1592.5]|1586.5|1602.2|4.5662|100.0% [0.72247, 1.0000]|0.00020000 USD|
|sandboxer|perf|ms|10|0|0|0|588.59 [586.08, 589.94]|592.39|592.39|588.65 [587.37, 589.85]|585.24|592.39|1.9346|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|cpu-single|iterations/s|10|0|0|0|1.7975e+7 [1.7529e+7, 1.8316e+7]|1.8451e+7|1.8451e+7|1.7669e+7 [1.6821e+7, 1.8196e+7]|1.4091e+7|1.8451e+7|1.2275e+6|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|cpu-all|iterations/s|10|0|0|0|6.1130e+7 [5.2494e+7, 6.5484e+7]|6.5915e+7|6.5915e+7|6.0475e+7 [5.7142e+7, 6.3592e+7]|5.1999e+7|6.5915e+7|5.2968e+6|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|memory-mbps|MB/s|10|0|0|0|44354 [42393, 46244]|46963|46963|44555 [43462, 45621]|41179|46963|1745.6|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-write-mbps|MB/s|10|0|0|0|1802.5 [1745.7, 1852.3]|1867.9|1867.9|1750.0 [1598.3, 1841.0]|1095.3|1867.9|221.13|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-read-mbps|MB/s|10|0|0|0|20605 [19755, 21513]|23858|23858|21271 [20507, 22217]|19751|23858|1355.8|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-4k-write-iops|IOPS|10|0|0|0|11050 [10303, 11272]|11501|11501|10897 [10501, 11222]|9361.9|11501|608.69|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-4k-read-iops|IOPS|10|0|0|0|6.5446e+5 [6.2361e+5, 6.6489e+5]|6.8645e+5|6.8645e+5|6.5171e+5 [6.3805e+5, 6.6529e+5]|6.1697e+5|6.8645e+5|21241|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|tcp-ms|ms|10|0|0|0|1.4774 [1.4509, 1.5329]|1.5470|1.5470|1.4895 [1.4696, 1.5127]|1.4467|1.5470|0.034942|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|command|ms|10|0|0|0|386.36 [385.42, 388.12]|389.78|389.78|387.01 [386.02, 388.06]|384.51|389.78|1.6826|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|npm-install-prepare|ms|3|0|0|0|4061.2 [3959.9, 4091.2]|4091.2|4091.2|4037.4 [3959.9, 4091.2]|3959.9|4091.2|56.155|100.0% [0.43850, 1.0000]|0.00014000 USD|
|sandboxer|npm-install|ms|3|0|0|0|788.75 [786.68, 789.17]|789.17|789.17|788.20 [786.68, 789.17]|786.68|789.17|1.0891|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|preview-provisioning|ms|3|0|0|0|293.88 [292.84, 295.20]|295.20|295.20|293.97 [292.84, 295.20]|292.84|295.20|0.96596|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|dev-server|ms|3|0|0|0|4402.4 [4390.8, 4412.5]|4412.5|4412.5|4401.9 [4390.8, 4412.5]|4390.8|4412.5|8.8837|100.0% [0.43850, 1.0000]|0.00015000 USD|
|sandboxer|preview-first-byte|ms|3|0|0|0|648.43 [537.61, 754.44]|754.44|754.44|646.83 [537.61, 754.44]|537.61|754.44|88.530|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|edit-loop|ms|3|0|0|0|1313.3 [1309.6, 1315.1]|1315.1|1315.1|1312.7 [1309.6, 1315.1]|1309.6|1315.1|2.2967|100.0% [0.43850, 1.0000]|0.000060000 USD|
|sandboxer|pause-resume|ms|10|0|0|0|1553.1 [1550.1, 1555.3]|1559.3|1559.3|1553.6 [1551.9, 1555.4]|1549.4|1559.3|2.8886|100.0% [0.72247, 1.0000]|0.00020000 USD|
|sandboxer|tool-replay|ms|3|0|0|0|43968 [43947, 44048]|44048|44048|43988 [43947, 44048]|43947|44048|43.753|100.0% [0.43850, 1.0000]|0.0013300 USD|
|sandboxer|files-1kb|ms|10|0|0|0|824.77 [821.67, 856.15]|864.70|864.70|838.50 [828.81, 849.22]|819.30|864.70|16.993|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|git-clone|ms|3|0|0|0|1789.2 [1787.8, 1789.4]|1789.4|1789.4|1788.8 [1787.8, 1789.4]|1787.8|1789.4|0.71400|100.0% [0.43850, 1.0000]|0.000060000 USD|
|sandboxer|pip-install|ms|3|0|0|0|2786.9 [2786.9, 2788.7]|2788.7|2788.7|2787.5 [2786.9, 2788.7]|2786.9|2788.7|0.85935|100.0% [0.43850, 1.0000]|0.000090000 USD|
|sandboxer|reconnect|ms|10|0|0|0|694.43 [692.33, 725.37]|730.68|730.68|706.45 [696.04, 717.03]|687.21|730.68|16.998|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|files-10mb|ms|10|0|0|0|6909.9 [6842.6, 7124.1]|7224.7|7224.7|6970.5 [6831.2, 7087.6]|6455.7|7224.7|210.70|100.0% [0.72247, 1.0000]|0.00075000 USD|
|sandboxer|destroy|ms|10|0|0|0|533.97 [533.67, 534.81]|535.34|535.34|534.20 [533.81, 534.61]|533.16|535.34|0.62047|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|reconnect-cleanup|ms|10|0|0|0|0.36566 [0.26594, 0.46621]|0.84512|0.84512|0.41942 [0.32152, 0.53512]|0.26057|0.84512|0.17390|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|sandbox-lifetime|ms|10|0|0|0|14552 [14373, 74602]|78392|78392|33247 [14546, 52023]|14345|78392|28621|100.0% [0.72247, 1.0000]|0.0033700 USD|
|sandboxer|tool-replay-prepare|ms|2|0|0|0|4029.8 [4029.8, 4050.9]|4050.9|4050.9|4040.3 [4029.8, 4050.9]|4029.8|4050.9|10.560|100.0% [0.34238, 1.0000]|0.00010000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux open-shiny-osprey 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux indigo-vernal-lime 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux sleek-focal-canyon 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux minty-radiant-pepper 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux shiny-rocky-lemon 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux tiny-woody-lynx 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux daring-apt-shore 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux lofty-curious-cherry 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux pearly-zealous-jasper 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux major-zany-delta 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|0.0033700|0.33700|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|unknown|0.017700|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|2/219|0.057459|0.22500|1.0573e+5|1.3750e+5|

Flagged samples:
- sandboxer/reconnect-cleanup iteration 0 at 2026-10-28T19:10:21.436Z: high host load
- sandboxer/reconnect-cleanup iteration 1 at 2026-10-28T19:11:40.056Z: high host load

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 10 sandbox attempts, estimated budget USD 0.0033700; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. Starts are admitted against live minute/hour/day limits before scenario deadlines; quota-waits.ndjson records admission wait separately from measured phases. The comp account supports 25 active sandboxes.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
