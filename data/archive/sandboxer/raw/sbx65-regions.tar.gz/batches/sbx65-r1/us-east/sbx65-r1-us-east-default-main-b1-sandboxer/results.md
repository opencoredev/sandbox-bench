# Sandbox provider benchmark sbx65-r1-us-east-default-main-b1-sandboxer

Schema v2 · 2026-10-26T16:49:50.770Z · seed 45 · track default
Allocation sandboxer: requested null; template default
Collection: 2026-10-26T16:49:50.770Z through 2026-10-26T17:03:30.368Z
Host: AMD Ryzen 9 9955HX 16-Core Processor; linux; v26.3.0
Metadata: {"repositoryCommit":"a718f99545beb68bbae1b721724d18ed9dfaf927","harnessCommit":"a718f99545beb68bbae1b721724d18ed9dfaf927","sdkCommit":"9ad2ee18e38b63ab56ae078b84c9ca44b2906374","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"runnerRegion":"us-east","runner":{"region":"us-east","label":"us-east-ms-a2","transport":"local","host":null,"datacenter":{"provider":"home","location":"Boca Raton, FL (ms-a2)"},"batchId":"sbx65-r1"},"clientLocation":{"ip":"redacted","city":"Boca Raton","region":"Florida","country":"US","org":"AS7018 AT&T Enterprises, LLC"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: eu-central

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|cold|ms|10|0|0|0|3474.7 [2026.0, 4388.0]|5798.4|5798.4|3538.5 [2758.9, 4340.5]|1882.9|5798.4|1279.0|100.0% [0.72247, 1.0000]|0.00041000 USD|
|sandboxer|fingerprint|ms|10|0|0|0|1662.0 [1464.2, 1665.3]|1872.3|1872.3|1625.2 [1545.0, 1705.8]|1463.4|1872.3|121.35|100.0% [0.72247, 1.0000]|0.00020000 USD|
|sandboxer|perf|ms|9|0|1|0|5066.3 [1866.1, 42664]|43263|43263|12222 [2957.0, 25110]|1273.1|43263|16519|100.0% [0.70085, 1.0000]|0.0011700 USD|
|sandboxer|cpu-single|iterations/s|9|0|1|0|1.8831e+7 [1.4071e+7, 1.9438e+7]|1.9904e+7|1.9904e+7|1.7116e+7 [1.4201e+7, 1.9023e+7]|7.8541e+6|1.9904e+7|3.6489e+6|100.0% [0.70085, 1.0000]|0.0011700 USD|
|sandboxer|cpu-all|iterations/s|9|0|1|0|5.3410e+7 [2.5346e+7, 5.5047e+7]|5.5685e+7|5.5685e+7|4.4746e+7 [3.4511e+7, 5.3943e+7]|1.6929e+7|5.5685e+7|1.4121e+7|100.0% [0.70085, 1.0000]|0.0011700 USD|
|sandboxer|memory-mbps|MB/s|9|0|1|0|28422 [9943.6, 39508]|41034|41034|25982 [17527, 33608]|6836.0|41034|11970|100.0% [0.70085, 1.0000]|0.0011700 USD|
|sandboxer|disk-write-mbps|MB/s|9|0|1|0|262.91 [215.81, 812.78]|960.15|960.15|446.55 [248.08, 660.16]|1.9184|960.15|308.24|100.0% [0.70085, 1.0000]|0.0011700 USD|
|sandboxer|disk-read-mbps|MB/s|9|0|1|0|10230 [3040.7, 11778]|13277|13277|8126.1 [5356.4, 10717]|2027.7|13277|4111.3|100.0% [0.70085, 1.0000]|0.0011700 USD|
|sandboxer|disk-4k-write-iops|IOPS|9|0|1|0|60.410 [36.683, 203.68]|605.05|605.05|152.04 [56.058, 281.75]|6.0137|605.05|173.82|100.0% [0.70085, 1.0000]|0.0011700 USD|
|sandboxer|disk-4k-read-iops|IOPS|9|0|1|0|3.8660e+5 [2.2351e+5, 7.6818e+5]|8.1641e+5|8.1641e+5|4.4501e+5 [3.1295e+5, 5.8829e+5]|1.8327e+5|8.1641e+5|2.1143e+5|100.0% [0.70085, 1.0000]|0.0011700 USD|
|sandboxer|tcp-ms|ms|9|0|1|0|1.9224 [1.5355, 2.2143]|2.3844|2.3844|1.9423 [1.7421, 2.1450]|1.4935|2.3844|0.30779|100.0% [0.70085, 1.0000]|0.0011700 USD|
|sandboxer|command|ms|9|0|1|0|262.14 [260.57, 265.08]|276.79|276.79|263.66 [261.12, 267.30]|258.70|276.79|4.9655|100.0% [0.70085, 1.0000]|0.00010000 USD|
|sandboxer|npm-install-prepare|ms|3|0|0|0|3473.9 [3021.9, 4536.4]|4536.4|4536.4|3677.4 [3021.9, 4536.4]|3021.9|4536.4|634.85|100.0% [0.43850, 1.0000]|0.00013000 USD|
|sandboxer|npm-install|ms|3|0|0|0|1463.1 [1064.9, 2079.3]|2079.3|2079.3|1535.8 [1064.9, 2079.3]|1064.9|2079.3|417.28|100.0% [0.43850, 1.0000]|0.000070000 USD|
|sandboxer|preview-provisioning|ms|3|0|0|0|133.27 [130.85, 197.32]|197.32|197.32|153.81 [130.85, 197.32]|130.85|197.32|30.777|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|dev-server|ms|3|0|0|0|3162.0 [3114.9, 3364.6]|3364.6|3364.6|3213.8 [3114.9, 3364.6]|3114.9|3364.6|108.33|100.0% [0.43850, 1.0000]|0.00012000 USD|
|sandboxer|preview-first-byte|ms|3|0|0|0|364.17 [256.86, 408.04]|408.04|408.04|343.02 [256.86, 408.04]|256.86|408.04|63.503|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|edit-loop|ms|3|0|0|0|902.64 [895.73, 996.08]|996.08|996.08|931.48 [895.73, 996.08]|895.73|996.08|45.763|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|pause-resume|ms|7|3|0|0|15978 [12032, 20648]|21891|21891|15769 [11414, 19641]|4431.1|21891|5701.5|70.0% [0.39678, 0.89221]|0.0039200 USD|
|sandboxer|tool-replay|ms|3|0|0|0|41626 [38308, 57371]|57371|57371|45768 [38308, 57371]|38308|57371|8315.3|100.0% [0.43850, 1.0000]|0.0013900 USD|
|sandboxer|files-1kb|ms|10|0|0|0|617.74 [590.77, 685.97]|838.84|838.84|654.65 [613.53, 705.97]|585.59|838.84|74.737|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|git-clone|ms|3|0|0|0|2058.8 [1866.7, 2068.2]|2068.2|2068.2|1997.9 [1866.7, 2068.2]|1866.7|2068.2|92.856|100.0% [0.43850, 1.0000]|0.000080000 USD|
|sandboxer|pip-install|ms|3|0|0|0|6273.8 [4267.6, 6862.1]|6862.1|6862.1|5801.2 [4267.6, 6862.1]|4267.6|6862.1|1110.7|100.0% [0.43850, 1.0000]|0.00019000 USD|
|sandboxer|reconnect|ms|9|0|1|0|484.98 [464.35, 535.83]|557.53|557.53|496.68 [474.73, 520.28]|451.62|557.53|34.827|100.0% [0.70085, 1.0000]|0.00010000 USD|
|sandboxer|files-10mb|ms|7|0|3|0|5783.3 [5231.2, 9942.1]|12999|12999|7195.2 [5400.3, 9598.0]|5049.9|12999|2837.4|100.0% [0.64567, 1.0000]|0.00056000 USD|
|sandboxer|destroy|ms|10|0|0|0|623.72 [344.37, 631.39]|2026.9|2026.9|709.82 [484.97, 1019.3]|343.78|2026.9|470.09|100.0% [0.72247, 1.0000]|0.00012000 USD|
|sandboxer|reconnect-cleanup|ms|9|0|0|0|0.69157 [0.65033, 0.71649]|0.83477|0.83477|0.69598 [0.65914, 0.73845]|0.60653|0.83477|0.059356|100.0% [0.70085, 1.0000]|0.000090000 USD|
|sandboxer|sandbox-lifetime|ms|10|0|0|0|87516 [30981, 1.0848e+5]|1.4490e+5|1.4490e+5|81835 [56893, 1.0385e+5]|28432|1.4490e+5|37292|100.0% [0.72247, 1.0000]|0.0082400 USD|
|sandboxer|tool-replay-prepare|ms|2|0|0|0|3124.1 [3124.1, 3439.7]|3439.7|3439.7|3281.9 [3124.1, 3439.7]|3124.1|3439.7|157.79|100.0% [0.34238, 1.0000]|0.000080000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux minty-epic-thrush 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux bubbly-ardent-puffin 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux slick-regal-echo 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux hidden-exact-delta 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux even-silent-dingo 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux royal-sandy-sierra 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux savvy-north-dove 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux giant-firm-prairie 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux carefree-minty-teal 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux lazy-swift-cabin 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|0.0082400|0.82400|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|unknown|0.018900|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|0/218|0.022171|0.032813|2.2470e+5|5.9040e+5|

Flagged samples:

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 10 sandbox attempts, estimated budget USD 0.0082400; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.
- sandboxer/pause-resume failure: Sandboxer request failed. The provider reported timeout. Check the sandbox and Sandboxer service before retrying.
- sandboxer/command blocked: Blocked by pause-resume
- sandboxer/files-10mb blocked: Blocked by pause-resume
- sandboxer/pause-resume failure: Sandboxer operation did not finish before its deadline. Check the Sandboxer provider configuration and retry.
- sandboxer/perf blocked: Blocked by pause-resume
- sandboxer/cpu-single blocked: Blocked by pause-resume
- sandboxer/cpu-all blocked: Blocked by pause-resume
- sandboxer/memory-mbps blocked: Blocked by pause-resume
- sandboxer/disk-write-mbps blocked: Blocked by pause-resume
- sandboxer/disk-read-mbps blocked: Blocked by pause-resume
- sandboxer/disk-4k-write-iops blocked: Blocked by pause-resume
- sandboxer/disk-4k-read-iops blocked: Blocked by pause-resume
- sandboxer/tcp-ms blocked: Blocked by pause-resume
- sandboxer/files-10mb blocked: Blocked by pause-resume
- sandboxer/pause-resume failure: Sandboxer operation did not finish before its deadline. Check the Sandboxer provider configuration and retry.
- sandboxer/reconnect blocked: Blocked by pause-resume
- sandboxer/files-10mb blocked: Blocked by pause-resume

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. Starts are admitted against live minute/hour/day limits before scenario deadlines; quota-waits.ndjson records admission wait separately from measured phases. The comp account supports 25 active sandboxes.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
