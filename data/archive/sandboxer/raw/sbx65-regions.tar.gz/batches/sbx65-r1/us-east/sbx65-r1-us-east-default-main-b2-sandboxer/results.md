# Sandbox provider benchmark sbx65-r1-us-east-default-main-b2-sandboxer

Schema v2 · 2026-10-26T17:03:31.833Z · seed 45 · track default
Allocation sandboxer: requested null; template default
Collection: 2026-10-26T17:03:31.833Z through 2026-10-26T17:12:58.162Z
Host: AMD Ryzen 9 9955HX 16-Core Processor; linux; v26.3.0
Metadata: {"repositoryCommit":"a718f99545beb68bbae1b721724d18ed9dfaf927","harnessCommit":"a718f99545beb68bbae1b721724d18ed9dfaf927","sdkCommit":"9ad2ee18e38b63ab56ae078b84c9ca44b2906374","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"runnerRegion":"us-east","runner":{"region":"us-east","label":"us-east-ms-a2","transport":"local","host":null,"datacenter":{"provider":"home","location":"Boca Raton, FL (ms-a2)"},"batchId":"sbx65-r1"},"clientLocation":{"ip":"redacted","city":"Boca Raton","region":"Florida","country":"US","org":"AS7018 AT&T Enterprises, LLC"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: eu-central

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|cold|ms|10|0|0|0|2898.1 [1885.5, 4072.7]|35097|35097|6277.6 [2648.1, 12929]|1870.2|35097|9652.5|100.0% [0.72247, 1.0000]|0.00067000 USD|
|sandboxer|fingerprint|ms|10|0|0|0|1671.8 [1662.6, 1681.3]|2064.7|2064.7|1709.4 [1628.9, 1807.5]|1470.7|2064.7|147.61|100.0% [0.72247, 1.0000]|0.00021000 USD|
|sandboxer|perf|ms|10|0|0|0|2264.7 [1867.9, 8063.3]|11670|11670|4467.1 [2367.9, 6908.9]|1467.2|11670|3567.9|100.0% [0.72247, 1.0000]|0.00051000 USD|
|sandboxer|cpu-single|iterations/s|10|0|0|0|1.3109e+7 [8.1972e+6, 1.9838e+7]|2.0073e+7|2.0073e+7|1.4758e+7 [1.1451e+7, 1.7946e+7]|6.0114e+6|2.0073e+7|5.2227e+6|100.0% [0.72247, 1.0000]|0.00051000 USD|
|sandboxer|cpu-all|iterations/s|10|0|0|0|2.9774e+7 [1.8737e+7, 6.1800e+7]|6.4670e+7|6.4670e+7|4.1148e+7 [2.9610e+7, 5.2486e+7]|1.2751e+7|6.4670e+7|1.8612e+7|100.0% [0.72247, 1.0000]|0.00051000 USD|
|sandboxer|memory-mbps|MB/s|10|0|0|0|27755 [7448.6, 39985]|44561|44561|27571 [18305, 36249]|2477.2|44561|14260|100.0% [0.72247, 1.0000]|0.00051000 USD|
|sandboxer|disk-write-mbps|MB/s|10|0|0|0|602.83 [186.82, 786.28]|853.17|853.17|543.19 [376.67, 706.57]|137.29|853.17|267.94|100.0% [0.72247, 1.0000]|0.00051000 USD|
|sandboxer|disk-read-mbps|MB/s|10|0|0|0|7517.7 [5644.6, 10212]|14793|14793|8647.0 [6871.2, 10598]|3923.7|14793|3040.3|100.0% [0.72247, 1.0000]|0.00051000 USD|
|sandboxer|disk-4k-write-iops|IOPS|10|0|0|0|160.85 [28.997, 179.78]|612.25|612.25|201.79 [92.997, 334.30]|23.611|612.25|192.45|100.0% [0.72247, 1.0000]|0.00051000 USD|
|sandboxer|disk-4k-read-iops|IOPS|10|0|0|0|2.8727e+5 [1.8379e+5, 6.1318e+5]|8.2882e+5|8.2882e+5|4.1952e+5 [2.9558e+5, 5.5490e+5]|1.7973e+5|8.2882e+5|2.1266e+5|100.0% [0.72247, 1.0000]|0.00051000 USD|
|sandboxer|tcp-ms|ms|10|0|0|0|1.7208 [1.6024, 2.7074]|4.6562|4.6562|2.3771 [1.8451, 3.0208]|1.5544|4.6562|0.96155|100.0% [0.72247, 1.0000]|0.00051000 USD|
|sandboxer|command|ms|10|0|0|0|263.07 [261.48, 268.98]|284.63|284.63|267.49 [262.69, 273.47]|257.29|284.63|8.7661|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|npm-install-prepare|ms|3|0|0|0|3007.7 [2989.5, 3014.3]|3014.3|3014.3|3003.9 [2989.5, 3014.3]|2989.5|3014.3|10.497|100.0% [0.43850, 1.0000]|0.00011000 USD|
|sandboxer|npm-install|ms|3|0|0|0|1262.6 [864.50, 1863.1]|1863.1|1863.1|1330.1 [864.50, 1863.1]|864.50|1863.1|410.47|100.0% [0.43850, 1.0000]|0.000050000 USD|
|sandboxer|preview-provisioning|ms|3|0|0|0|132.13 [129.96, 134.42]|134.42|134.42|132.17 [129.96, 134.42]|129.96|134.42|1.8229|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|dev-server|ms|3|0|0|0|3121.0 [3120.7, 3300.1]|3300.1|3300.1|3180.6 [3120.7, 3300.1]|3120.7|3300.1|84.502|100.0% [0.43850, 1.0000]|0.00012000 USD|
|sandboxer|preview-first-byte|ms|3|0|0|0|343.64 [270.04, 360.23]|360.23|360.23|324.64 [270.04, 360.23]|270.04|360.23|39.195|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|edit-loop|ms|3|0|0|0|883.14 [881.13, 886.23]|886.23|886.23|883.50 [881.13, 886.23]|881.13|886.23|2.0971|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|pause-resume|ms|10|0|0|0|19729 [5267.7, 22278]|36287|36287|19368 [14070, 24564]|4905.1|36287|8593.1|100.0% [0.72247, 1.0000]|0.0019800 USD|
|sandboxer|tool-replay|ms|3|0|0|0|33138 [32691, 33785]|33785|33785|33205 [32691, 33785]|32691|33785|448.93|100.0% [0.43850, 1.0000]|0.0010100 USD|
|sandboxer|files-1kb|ms|10|0|0|0|637.19 [610.07, 716.44]|3633.8|3633.8|951.39 [631.05, 1560.4]|592.15|3633.8|895.31|100.0% [0.72247, 1.0000]|0.00013000 USD|
|sandboxer|git-clone|ms|3|0|0|0|1867.2 [1860.8, 2062.5]|2062.5|2062.5|1930.2 [1860.8, 2062.5]|1860.8|2062.5|93.603|100.0% [0.43850, 1.0000]|0.000070000 USD|
|sandboxer|pip-install|ms|3|0|0|0|6263.8 [3864.2, 6658.5]|6658.5|6658.5|5595.5 [3864.2, 6658.5]|3864.2|6658.5|1234.8|100.0% [0.43850, 1.0000]|0.00018000 USD|
|sandboxer|reconnect|ms|10|0|0|0|481.22 [460.00, 606.38]|3890.4|3890.4|860.27 [491.55, 1554.9]|450.94|3890.4|1012.7|100.0% [0.72247, 1.0000]|0.00013000 USD|
|sandboxer|files-10mb|ms|10|0|0|0|5909.9 [5381.0, 6200.3]|9048.7|9048.7|6125.2 [5609.3, 6882.2]|4997.7|9048.7|1059.1|100.0% [0.72247, 1.0000]|0.00067000 USD|
|sandboxer|destroy|ms|10|0|0|0|626.76 [623.49, 631.48]|2317.2|2317.2|880.71 [626.04, 1303.5]|622.13|2317.2|541.99|100.0% [0.72247, 1.0000]|0.00013000 USD|
|sandboxer|reconnect-cleanup|ms|10|0|0|0|0.59264 [0.54203, 0.78787]|1.4224|1.4224|0.72368 [0.59602, 0.89511]|0.49974|1.4224|0.25546|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|sandbox-lifetime|ms|10|0|0|0|39440 [29180, 81890]|1.0737e+5|1.0737e+5|56509 [38931, 74315]|24121|1.0737e+5|28246|100.0% [0.72247, 1.0000]|0.0057100 USD|
|sandboxer|tool-replay-prepare|ms|2|0|0|0|2944.1 [2944.1, 3028.0]|3028.0|3028.0|2986.1 [2944.1, 3028.0]|2944.1|3028.0|41.961|100.0% [0.34238, 1.0000]|0.000070000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux electric-tranquil-panda 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux vital-muted-anchor 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux lavish-open-lily 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux plain-joyful-linden 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux minty-woody-heron 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux nimble-fern-finch 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux ivory-hazel-echo 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux happy-wise-glade 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux zany-open-trout 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux local-cloudy-compass 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|0.0057100|0.57100|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|unknown|0.015300|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|0/219|0.096931|0.23906|1.9942e+5|1.7969e+6|

Flagged samples:

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 10 sandbox attempts, estimated budget USD 0.0057100; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. Starts are admitted against live minute/hour/day limits before scenario deadlines; quota-waits.ndjson records admission wait separately from measured phases. The comp account supports 25 active sandboxes.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
