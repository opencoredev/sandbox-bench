# Sandbox provider benchmark sbx65-r1-eu-default-main-b2-sandboxer

Schema v2 · 2026-10-26T17:13:15.053Z · seed 45 · track default
Allocation sandboxer: requested null; template default
Collection: 2026-10-26T17:13:15.053Z through 2026-10-26T17:21:38.445Z
Host: Intel Core Processor (Haswell, no TSX); linux; v26.3.0
Metadata: {"repositoryCommit":"a718f99545beb68bbae1b721724d18ed9dfaf927","harnessCommit":"a718f99545beb68bbae1b721724d18ed9dfaf927","sdkCommit":"9ad2ee18e38b63ab56ae078b84c9ca44b2906374","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"runnerRegion":"eu","runner":{"region":"eu","label":"eu-ovh-frankfurt","transport":"ssh","host":"redacted","datacenter":{"provider":"ovh","location":"Frankfurt, DE (vps-41a131f1)","serverType":"VPS 2 vCore / 4 GB"},"batchId":"sbx65-r1"},"clientLocation":{"ip":"redacted","city":"Frankfurt am Main","region":"Hesse","country":"DE","org":"AS16276 OVH SAS"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: eu-central

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|cold|ms|10|0|0|0|3926.8 [3340.6, 4082.9]|4278.7|4278.7|3766.5 [3390.5, 4040.8]|2358.0|4278.7|533.86|100.0% [0.72247, 1.0000]|0.00043000 USD|
|sandboxer|fingerprint|ms|10|0|0|0|1794.2 [1593.5, 1798.0]|1999.5|1999.5|1736.6 [1655.9, 1817.4]|1592.7|1999.5|129.27|100.0% [0.72247, 1.0000]|0.00020000 USD|
|sandboxer|perf|ms|10|0|0|0|1803.1 [1401.2, 3614.3]|5412.8|5412.8|2441.1 [1712.3, 3347.6]|1187.1|5412.8|1301.8|100.0% [0.72247, 1.0000]|0.00028000 USD|
|sandboxer|cpu-single|iterations/s|10|0|0|0|1.1934e+7 [1.1241e+7, 1.3799e+7]|1.9984e+7|1.9984e+7|1.2979e+7 [1.1544e+7, 1.4826e+7]|9.8927e+6|1.9984e+7|2.7087e+6|100.0% [0.72247, 1.0000]|0.00028000 USD|
|sandboxer|cpu-all|iterations/s|10|0|0|0|1.7659e+7 [9.5817e+6, 2.0848e+7]|3.4930e+7|3.4930e+7|1.7475e+7 [1.3294e+7, 2.2302e+7]|7.3219e+6|3.4930e+7|7.3172e+6|100.0% [0.72247, 1.0000]|0.00028000 USD|
|sandboxer|memory-mbps|MB/s|10|0|0|0|3136.8 [1779.2, 10353]|30477|30477|7518.2 [3249.8, 13463]|1663.3|30477|8424.3|100.0% [0.72247, 1.0000]|0.00028000 USD|
|sandboxer|disk-write-mbps|MB/s|10|0|0|0|757.81 [52.951, 842.08]|869.83|869.83|588.00 [354.43, 805.02]|42.484|869.83|352.79|100.0% [0.72247, 1.0000]|0.00028000 USD|
|sandboxer|disk-read-mbps|MB/s|10|0|0|0|3733.2 [2547.9, 4522.7]|10898|10898|4463.2 [3148.9, 6213.4]|1586.2|10898|2480.1|100.0% [0.72247, 1.0000]|0.00028000 USD|
|sandboxer|disk-4k-write-iops|IOPS|10|0|0|0|833.00 [472.18, 918.84]|3427.4|3427.4|978.13 [600.47, 1578.6]|204.78|3427.4|847.09|100.0% [0.72247, 1.0000]|0.00028000 USD|
|sandboxer|disk-4k-read-iops|IOPS|10|0|0|0|2.7434e+5 [2.3776e+5, 3.0953e+5]|7.7473e+5|7.7473e+5|3.0948e+5 [2.2730e+5, 4.2633e+5]|97216|7.7473e+5|1.6566e+5|100.0% [0.72247, 1.0000]|0.00028000 USD|
|sandboxer|tcp-ms|ms|10|0|0|0|3.2059 [2.4076, 4.7370]|7.5951|7.5951|3.7839 [2.7569, 4.9393]|1.9371|7.5951|1.7664|100.0% [0.72247, 1.0000]|0.00028000 USD|
|sandboxer|command|ms|10|0|0|0|396.12 [386.85, 408.47]|595.39|595.39|417.16 [393.02, 458.39]|383.49|595.39|60.098|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|npm-install-prepare|ms|3|0|0|0|4567.9 [4142.5, 4605.9]|4605.9|4605.9|4438.8 [4142.5, 4605.9]|4142.5|4605.9|210.07|100.0% [0.43850, 1.0000]|0.00015000 USD|
|sandboxer|npm-install|ms|3|0|0|0|2389.5 [786.54, 2393.9]|2393.9|2393.9|1856.7 [786.54, 2393.9]|786.54|2393.9|756.69|100.0% [0.43850, 1.0000]|0.000070000 USD|
|sandboxer|preview-provisioning|ms|3|0|0|0|191.80 [190.13, 197.84]|197.84|197.84|193.26 [190.13, 197.84]|190.13|197.84|3.3092|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|dev-server|ms|3|0|0|0|4713.7 [4419.2, 4871.6]|4871.6|4871.6|4668.1 [4419.2, 4871.6]|4419.2|4871.6|187.45|100.0% [0.43850, 1.0000]|0.00015000 USD|
|sandboxer|preview-first-byte|ms|3|0|0|0|714.08 [534.85, 749.83]|749.83|749.83|666.25 [534.85, 749.83]|534.85|749.83|94.053|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|edit-loop|ms|3|0|0|0|1314.5 [1237.1, 1317.6]|1317.6|1317.6|1289.8 [1237.1, 1317.6]|1237.1|1317.6|37.227|100.0% [0.43850, 1.0000]|0.000060000 USD|
|sandboxer|pause-resume|ms|10|0|0|0|4965.1 [4624.0, 6731.0]|17453|17453|6706.4 [4936.0, 9290.2]|4616.1|17453|3782.1|100.0% [0.72247, 1.0000]|0.00071000 USD|
|sandboxer|tool-replay|ms|3|0|0|0|48641 [44960, 50344]|50344|50344|47981 [44960, 50344]|44960|50344|2247.0|100.0% [0.43850, 1.0000]|0.0014500 USD|
|sandboxer|files-1kb|ms|10|0|0|0|984.93 [899.79, 1058.9]|2700.3|2700.3|1156.9 [949.06, 1518.8]|827.65|2700.3|519.72|100.0% [0.72247, 1.0000]|0.00016000 USD|
|sandboxer|git-clone|ms|3|0|0|0|1798.0 [1590.7, 2023.4]|2023.4|2023.4|1804.0 [1590.7, 2023.4]|1590.7|2023.4|176.73|100.0% [0.43850, 1.0000]|0.000070000 USD|
|sandboxer|pip-install|ms|3|0|0|0|7794.1 [3787.6, 8991.9]|8991.9|8991.9|6857.9 [3787.6, 8991.9]|3787.6|8991.9|2225.4|100.0% [0.43850, 1.0000]|0.00021000 USD|
|sandboxer|reconnect|ms|10|0|0|0|884.21 [755.76, 1387.9]|1580.9|1580.9|1066.0 [885.81, 1249.8]|696.40|1580.9|300.17|100.0% [0.72247, 1.0000]|0.00015000 USD|
|sandboxer|files-10mb|ms|10|0|0|0|8388.2 [7305.2, 9557.0]|10785|10785|8597.4 [7918.7, 9338.2]|7200.0|10785|1130.7|100.0% [0.72247, 1.0000]|0.00092000 USD|
|sandboxer|destroy|ms|10|0|0|0|1903.4 [1884.3, 2243.5]|2562.4|2562.4|1968.7 [1696.8, 2200.6]|885.82|2562.4|421.89|100.0% [0.72247, 1.0000]|0.00023000 USD|
|sandboxer|reconnect-cleanup|ms|10|0|0|0|0.45643 [0.38023, 0.60869]|1.0094|1.0094|0.53802 [0.43858, 0.66267]|0.33533|1.0094|0.18303|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|sandbox-lifetime|ms|10|0|0|0|27574 [26338, 96140]|1.0908e+5|1.0908e+5|50018 [27419, 73052]|26297|1.0908e+5|34911|100.0% [0.72247, 1.0000]|0.0050800 USD|
|sandboxer|tool-replay-prepare|ms|2|0|0|0|4558.3 [4558.3, 4586.1]|4586.1|4586.1|4572.2 [4558.3, 4586.1]|4558.3|4586.1|13.880|100.0% [0.34238, 1.0000]|0.00010000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux frank-cool-moss 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux quiet-plush-wolf 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux mellow-lively-cello 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux cozy-sleek-fjord 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux rich-zany-ocelot 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux calm-misty-hickory 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux neat-bold-violet 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux neat-joyful-iris 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux giant-plush-squid 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux handy-arctic-canoe 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|0.0050800|0.50800|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|unknown|0.020400|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|0/219|0.017372|0.25000|76258|99128|

Flagged samples:

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 10 sandbox attempts, estimated budget USD 0.0050800; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. Starts are admitted against live minute/hour/day limits before scenario deadlines; quota-waits.ndjson records admission wait separately from measured phases. The comp account supports 25 active sandboxes.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
