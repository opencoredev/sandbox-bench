# Sandbox provider benchmark sbx65-r1-eu-default-main-b1-sandboxer

Schema v2 · 2026-10-26T16:38:07.529Z · seed 45 · track default
Allocation sandboxer: requested null; template default
Collection: 2026-10-26T16:38:07.529Z through 2026-10-26T16:49:25.438Z
Host: Intel Core Processor (Haswell, no TSX); linux; v26.3.0
Metadata: {"repositoryCommit":"a718f99545beb68bbae1b721724d18ed9dfaf927","harnessCommit":"a718f99545beb68bbae1b721724d18ed9dfaf927","sdkCommit":"9ad2ee18e38b63ab56ae078b84c9ca44b2906374","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"runnerRegion":"eu","runner":{"region":"eu","label":"eu-ovh-frankfurt","transport":"ssh","host":"redacted","datacenter":{"provider":"ovh","location":"Frankfurt, DE (vps-41a131f1)","serverType":"VPS 2 vCore / 4 GB"},"batchId":"sbx65-r1"},"clientLocation":{"ip":"redacted","city":"Frankfurt am Main","region":"Hesse","country":"DE","org":"AS16276 OVH SAS"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: eu-central

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|cold|ms|10|0|0|0|3305.6 [2479.3, 4601.3]|5171.9|5171.9|3642.8 [3091.6, 4224.9]|2360.9|5171.9|923.31|100.0% [0.72247, 1.0000]|0.00041000 USD|
|sandboxer|fingerprint|ms|10|0|0|0|1595.9 [1590.0, 1787.4]|1998.5|1998.5|1675.2 [1599.0, 1758.2]|1589.9|1998.5|131.57|100.0% [0.72247, 1.0000]|0.00020000 USD|
|sandboxer|perf|ms|10|0|0|0|3189.4 [2195.8, 11592]|47395|47395|9672.0 [3773.2, 19133]|2190.2|47395|13062|100.0% [0.72247, 1.0000]|0.0010200 USD|
|sandboxer|cpu-single|iterations/s|10|0|0|0|1.8988e+7 [9.1307e+6, 1.9395e+7]|2.0082e+7|2.0082e+7|1.6822e+7 [1.4008e+7, 1.9229e+7]|8.2099e+6|2.0082e+7|4.2547e+6|100.0% [0.72247, 1.0000]|0.0010200 USD|
|sandboxer|cpu-all|iterations/s|10|0|0|0|4.6244e+7 [2.9847e+7, 5.1649e+7]|5.5813e+7|5.5813e+7|4.3675e+7 [3.7396e+7, 4.9668e+7]|2.8378e+7|5.5813e+7|1.0028e+7|100.0% [0.72247, 1.0000]|0.0010200 USD|
|sandboxer|memory-mbps|MB/s|10|0|0|0|29841 [13909, 35010]|40271|40271|27488 [21361, 33559]|13464|40271|9872.3|100.0% [0.72247, 1.0000]|0.0010200 USD|
|sandboxer|disk-write-mbps|MB/s|10|0|0|0|265.28 [206.77, 727.31]|827.58|827.58|398.22 [243.45, 556.63]|13.792|827.58|258.19|100.0% [0.72247, 1.0000]|0.0010200 USD|
|sandboxer|disk-read-mbps|MB/s|10|0|0|0|7731.0 [4998.1, 10111]|14634|14634|8355.2 [6617.9, 10287]|3798.2|14634|3046.3|100.0% [0.72247, 1.0000]|0.0010200 USD|
|sandboxer|disk-4k-write-iops|IOPS|10|0|0|0|109.46 [23.324, 163.88]|196.56|196.56|106.15 [60.403, 148.36]|5.4931|196.56|70.323|100.0% [0.72247, 1.0000]|0.0010200 USD|
|sandboxer|disk-4k-read-iops|IOPS|10|0|0|0|3.0144e+5 [1.6659e+5, 4.8306e+5]|6.4153e+5|6.4153e+5|3.4642e+5 [2.4438e+5, 4.4865e+5]|1.6121e+5|6.4153e+5|1.6865e+5|100.0% [0.72247, 1.0000]|0.0010200 USD|
|sandboxer|tcp-ms|ms|10|0|0|0|1.8636 [1.8019, 2.5559]|6.1948|6.1948|2.4301 [1.8658, 3.3708]|1.6803|6.1948|1.2939|100.0% [0.72247, 1.0000]|0.0010200 USD|
|sandboxer|command|ms|10|0|0|0|386.98 [386.26, 391.72]|394.87|394.87|388.95 [387.14, 390.91]|385.63|394.87|3.0157|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|npm-install-prepare|ms|3|0|0|0|4228.3 [4138.6, 4419.3]|4419.3|4419.3|4262.1 [4138.6, 4419.3]|4138.6|4419.3|117.07|100.0% [0.43850, 1.0000]|0.00015000 USD|
|sandboxer|npm-install|ms|3|0|0|0|1586.8 [790.19, 1588.7]|1588.7|1588.7|1321.9 [790.19, 1588.7]|790.19|1588.7|375.97|100.0% [0.43850, 1.0000]|0.000050000 USD|
|sandboxer|preview-provisioning|ms|3|0|0|0|196.75 [195.01, 197.32]|197.32|197.32|196.36 [195.01, 197.32]|195.01|197.32|0.98363|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|dev-server|ms|3|0|0|0|4530.8 [4527.5, 4610.9]|4610.9|4610.9|4556.4 [4527.5, 4610.9]|4527.5|4610.9|38.538|100.0% [0.43850, 1.0000]|0.00015000 USD|
|sandboxer|preview-first-byte|ms|3|0|0|0|606.97 [532.94, 673.85]|673.85|673.85|604.59 [532.94, 673.85]|532.94|673.85|57.550|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|edit-loop|ms|3|0|0|0|1266.2 [1238.6, 1267.9]|1267.9|1267.9|1257.6 [1238.6, 1267.9]|1238.6|1267.9|13.435|100.0% [0.43850, 1.0000]|0.000060000 USD|
|sandboxer|pause-resume|ms|10|0|0|0|17791 [12634, 23692]|31638|31638|19750 [16290, 23381]|12612|31638|5661.6|100.0% [0.72247, 1.0000]|0.0020300 USD|
|sandboxer|tool-replay|ms|3|0|0|0|45918 [45398, 49446]|49446|49446|46921 [45398, 49446]|45398|49446|1798.3|100.0% [0.43850, 1.0000]|0.0014200 USD|
|sandboxer|files-1kb|ms|10|0|0|0|880.93 [847.78, 966.40]|1008.0|1008.0|907.31 [874.78, 943.93]|836.90|1008.0|55.156|100.0% [0.72247, 1.0000]|0.00011000 USD|
|sandboxer|git-clone|ms|3|0|0|0|1987.4 [1789.8, 2192.3]|2192.3|2192.3|1989.8 [1789.8, 2192.3]|1789.8|2192.3|164.35|100.0% [0.43850, 1.0000]|0.000070000 USD|
|sandboxer|pip-install|ms|3|0|0|0|5387.7 [5190.1, 5388.6]|5388.6|5388.6|5322.1 [5190.1, 5388.6]|5190.1|5388.6|93.343|100.0% [0.43850, 1.0000]|0.00018000 USD|
|sandboxer|reconnect|ms|10|0|0|0|730.78 [711.26, 845.39]|1040.7|1040.7|793.80 [739.96, 866.88]|708.59|1040.7|103.68|100.0% [0.72247, 1.0000]|0.00011000 USD|
|sandboxer|files-10mb|ms|10|0|0|0|6884.8 [6476.3, 7277.3]|26880|26880|8881.2 [6718.2, 12970]|6376.5|26880|6010.6|100.0% [0.72247, 1.0000]|0.00093000 USD|
|sandboxer|destroy|ms|10|0|0|0|536.60 [535.37, 880.08]|884.86|884.86|640.77 [537.43, 744.67]|534.76|884.86|158.40|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|reconnect-cleanup|ms|10|0|0|0|0.53471 [0.38492, 0.62083]|0.97154|0.97154|0.56021 [0.47075, 0.66577]|0.35594|0.97154|0.16311|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|sandbox-lifetime|ms|10|0|0|0|55225 [42469, 98098]|1.0341e+5|1.0341e+5|67476 [52172, 82594]|35285|1.0341e+5|25315|100.0% [0.72247, 1.0000]|0.0068100 USD|
|sandboxer|tool-replay-prepare|ms|2|0|0|0|4282.1 [4282.1, 4330.0]|4330.0|4330.0|4306.0 [4282.1, 4330.0]|4282.1|4330.0|23.990|100.0% [0.34238, 1.0000]|0.00010000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux jolly-sturdy-birch 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux solid-electric-banjo 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux spare-pacific-sparrow 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux jaunty-hazel-fox 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux silent-cozy-valley 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux fast-polar-owl 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux radiant-grand-marsh 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux swift-active-ember 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux still-apt-puffin 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux dawn-glad-compass 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|0.0068100|0.68100|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|unknown|0.019800|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|0/219|0.013529|0.82000|78018|1.0130e+5|

Flagged samples:

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 10 sandbox attempts, estimated budget USD 0.0068100; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. Starts are admitted against live minute/hour/day limits before scenario deadlines; quota-waits.ndjson records admission wait separately from measured phases. The comp account supports 25 active sandboxes.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
