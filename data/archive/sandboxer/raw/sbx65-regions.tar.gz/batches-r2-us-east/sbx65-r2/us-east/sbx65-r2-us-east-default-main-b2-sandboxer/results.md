# Sandbox provider benchmark sbx65-r2-us-east-default-main-b2-sandboxer

Schema v2 · 2026-10-28T18:57:47.314Z · seed 45 · track default
Allocation sandboxer: requested null; template default
Collection: 2026-10-28T18:57:47.314Z through 2026-10-28T19:00:24.054Z
Host: AMD Ryzen 9 9955HX 16-Core Processor; linux; v26.3.0
Metadata: {"repositoryCommit":"a89eb27916660b995e632ee91e2691058b37f907","harnessCommit":"a89eb27916660b995e632ee91e2691058b37f907","sdkCommit":"dfbd85047ebe9687da6865799dbdde01507b87fb","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"runnerRegion":"us-east","runner":{"region":"us-east","label":"us-east-ms-a2","transport":"local","host":null,"datacenter":{"provider":"home","location":"Boca Raton, FL (ms-a2)"},"batchId":"sbx65-r2"},"clientLocation":{"ip":"redacted","city":"Boca Raton","region":"Florida","country":"US","org":"AS7018 AT&T Enterprises, LLC"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: nearest

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|cold|ms|6|4|0|0|352.50 [328.52, 361.33]|363.63|363.63|350.70 [339.72, 360.06]|328.52|363.63|13.043|60.0% [0.31267, 0.83182]|0.00010000 USD|
|sandboxer|fingerprint|ms|6|0|0|0|1471.6 [1269.1, 1472.1]|1475.7|1475.7|1405.9 [1337.7, 1473.2]|1269.1|1475.7|94.733|100.0% [0.60967, 1.0000]|0.00012000 USD|
|sandboxer|perf|ms|5|1|0|0|871.14 [868.86, 872.07]|872.07|872.07|870.82 [869.77, 871.64]|868.86|872.07|1.0941|83.3% [0.43650, 0.96995]|0.000060000 USD|
|sandboxer|cpu-single|iterations/s|5|1|0|0|1.3815e+7 [1.3671e+7, 1.4177e+7]|1.4177e+7|1.4177e+7|1.3872e+7 [1.3735e+7, 1.4035e+7]|1.3671e+7|1.4177e+7|1.7537e+5|83.3% [0.43650, 0.96995]|0.000060000 USD|
|sandboxer|cpu-all|iterations/s|5|1|0|0|3.1366e+7 [2.8629e+7, 3.6219e+7]|3.6219e+7|3.6219e+7|3.1967e+7 [2.9513e+7, 3.4814e+7]|2.8629e+7|3.6219e+7|2.9451e+6|83.3% [0.43650, 0.96995]|0.000060000 USD|
|sandboxer|memory-mbps|MB/s|5|1|0|0|36743 [33145, 37936]|37936|37936|36082 [34542, 37459]|33145|37936|1698.1|83.3% [0.43650, 0.96995]|0.000060000 USD|
|sandboxer|disk-write-mbps|MB/s|5|1|0|0|1697.1 [1521.9, 2039.0]|2039.0|2039.0|1713.9 [1563.0, 1879.6]|1521.9|2039.0|184.94|83.3% [0.43650, 0.96995]|0.000060000 USD|
|sandboxer|disk-read-mbps|MB/s|5|1|0|0|9996.6 [8779.4, 21687]|21687|21687|14130 [9117.6, 19175]|8779.4|21687|6008.2|83.3% [0.43650, 0.96995]|0.000060000 USD|
|sandboxer|disk-4k-write-iops|IOPS|5|1|0|0|683.79 [671.55, 746.04]|746.04|746.04|697.79 [675.51, 725.14]|671.55|746.04|28.018|83.3% [0.43650, 0.96995]|0.000060000 USD|
|sandboxer|disk-4k-read-iops|IOPS|5|1|0|0|2.3545e+5 [2.2255e+5, 2.3826e+5]|2.3826e+5|2.3826e+5|2.3317e+5 [2.2771e+5, 2.3687e+5]|2.2255e+5|2.3826e+5|5503.0|83.3% [0.43650, 0.96995]|0.000060000 USD|
|sandboxer|tcp-ms|ms|5|1|0|0|1.3918 [1.3217, 1.4264]|1.4264|1.4264|1.3814 [1.3465, 1.4116]|1.3217|1.4264|0.036798|83.3% [0.43650, 0.96995]|0.000060000 USD|
|sandboxer|command|ms|5|0|1|0|70.484 [67.832, 71.945]|71.945|71.945|70.116 [68.763, 71.242]|67.832|71.945|1.4035|100.0% [0.56552, 1.0000]|0.000060000 USD|
|sandboxer|npm-install-prepare|ms|2|1|0|0|1280.1 [1280.1, 1351.1]|1351.1|1351.1|1315.6 [1280.1, 1351.1]|1280.1|1351.1|35.508|66.7% [0.20766, 0.93851]|0.000050000 USD|
|sandboxer|npm-install|ms|2|0|1|0|1269.1 [1269.1, 1270.5]|1270.5|1270.5|1269.8 [1269.1, 1270.5]|1269.1|1270.5|0.68509|100.0% [0.34238, 1.0000]|0.000050000 USD|
|sandboxer|preview-provisioning|ms|2|0|1|0|133.35 [133.35, 133.74]|133.74|133.74|133.54 [133.35, 133.74]|133.35|133.74|0.19258|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|dev-server|ms|2|0|1|0|1102.0 [1102.0, 1137.0]|1137.0|1137.0|1119.5 [1102.0, 1137.0]|1102.0|1137.0|17.484|100.0% [0.34238, 1.0000]|0.000050000 USD|
|sandboxer|preview-first-byte|ms|2|0|1|0|372.90 [372.90, 375.30]|375.30|375.30|374.10 [372.90, 375.30]|372.90|375.30|1.2007|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|edit-loop|ms|2|0|1|0|643.11 [643.11, 655.02]|655.02|655.02|649.06 [643.11, 655.02]|643.11|655.02|5.9562|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|pause-resume|ms|5|1|0|0|794.95 [788.78, 800.81]|800.81|800.81|794.60 [790.96, 798.01]|788.78|800.81|3.9420|83.3% [0.43650, 0.96995]|0.000060000 USD|
|sandboxer|tool-replay|ms|2|1|0|0|16309 [16309, 16628]|16628|16628|16468 [16309, 16628]|16309|16628|159.33|66.7% [0.20766, 0.93851]|0.00038000 USD|
|sandboxer|files-1kb|ms|5|1|0|0|298.96 [275.69, 367.62]|367.62|367.62|312.14 [288.38, 340.24]|275.69|367.62|31.492|83.3% [0.43650, 0.96995]|0.000060000 USD|
|sandboxer|git-clone|ms|2|1|0|0|1273.3 [1273.3, 1273.3]|1273.3|1273.3|1273.3 [1273.3, 1273.3]|1273.3|1273.3|0.018559|66.7% [0.20766, 0.93851]|0.000050000 USD|
|sandboxer|pip-install|ms|2|1|0|0|4270.0 [4270.0, 4473.9]|4473.9|4473.9|4372.0 [4270.0, 4473.9]|4270.0|4473.9|101.94|66.7% [0.20766, 0.93851]|0.00011000 USD|
|sandboxer|reconnect|ms|5|0|1|0|194.67 [188.38, 255.37]|255.37|255.37|216.36 [190.80, 241.92]|188.38|255.37|30.598|100.0% [0.56552, 1.0000]|0.000060000 USD|
|sandboxer|files-10mb|ms|5|0|1|0|1824.2 [1745.6, 2286.5]|2286.5|2286.5|1907.4 [1772.5, 2108.1]|1745.6|2286.5|197.36|100.0% [0.56552, 1.0000]|0.00012000 USD|
|sandboxer|destroy|ms|5|2|0|0|343.51 [343.11, 347.54]|347.54|347.54|344.28 [343.31, 345.92]|343.11|347.54|1.6434|71.4% [0.35893, 0.91778]|0.000070000 USD|
|sandboxer|reconnect-cleanup|ms|5|0|0|0|0.56955 [0.51580, 0.78892]|0.78892|0.78892|0.62298 [0.53337, 0.71807]|0.51580|0.78892|0.10695|100.0% [0.56552, 1.0000]|0.000050000 USD|
|sandboxer|sandbox-lifetime|ms|6|0|0|4|6826.8 [6266.7, 33323]|34638|34638|15850 [6621.8, 25297]|6266.7|34638|12835|100.0% [0.60967, 1.0000]|0.0010200 USD|
|sandboxer|tool-replay-prepare|ms|2|0|0|0|1263.0 [1263.0, 1282.5]|1282.5|1282.5|1272.7 [1263.0, 1282.5]|1263.0|1282.5|9.7159|100.0% [0.34238, 1.0000]|0.000040000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux spare-sandy-ibis 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux joyful-velvet-apricot 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux crisp-still-swan 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux funny-sterling-ivy 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux cheery-curious-lily 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux apt-local-dahlia 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|0.0010200|0.10200|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|unknown|0.0072000|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|0/151|0.049632|0.088750|2.8143e+5|9.8199e+5|

Flagged samples:

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 10 sandbox attempts, estimated budget USD 0.0010200; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.
- sandboxer/tool-replay failure: Sandboxer request failed (HTTP 429). The provider reported quota. Check the sandbox and Sandboxer service before retrying.
- sandboxer/npm-install-prepare failure: Sandboxer request failed (HTTP 429). The provider reported quota. Check the sandbox and Sandboxer service before retrying.
- sandboxer/npm-install blocked: Blocked by npm-install-prepare
- sandboxer/preview-provisioning blocked: Blocked by npm-install-prepare
- sandboxer/dev-server blocked: Blocked by npm-install-prepare
- sandboxer/preview-first-byte blocked: Blocked by npm-install-prepare
- sandboxer/edit-loop blocked: Blocked by npm-install-prepare
- sandboxer/files-1kb failure: Sandboxer request failed (HTTP 429). The provider reported quota. Check the sandbox and Sandboxer service before retrying.
- sandboxer/pip-install failure: Sandboxer request failed (HTTP 429). The provider reported quota. Check the sandbox and Sandboxer service before retrying.
- sandboxer/git-clone failure: Remote cancellation could not be confirmed; destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/perf failure: Remote cancellation could not be confirmed; destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/cpu-single failure: Remote cancellation could not be confirmed; destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/cpu-all failure: Remote cancellation could not be confirmed; destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/memory-mbps failure: Remote cancellation could not be confirmed; destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/disk-write-mbps failure: Remote cancellation could not be confirmed; destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/disk-read-mbps failure: Remote cancellation could not be confirmed; destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/disk-4k-write-iops failure: Remote cancellation could not be confirmed; destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/disk-4k-read-iops failure: Remote cancellation could not be confirmed; destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/tcp-ms failure: Remote cancellation could not be confirmed; destroy the sandbox before retrying. Check the Sandboxer provider configuration and retry.
- sandboxer/pause-resume failure: Sandboxer request failed (HTTP 429 rate_limited). The provider reported quota. Check the sandbox and Sandboxer service before retrying.
- sandboxer/reconnect blocked: Blocked by pause-resume
- sandboxer/command blocked: Blocked by pause-resume
- sandboxer/files-10mb blocked: Blocked by pause-resume
- sandboxer/destroy failure: Sandboxer request failed (HTTP 429). The provider reported quota. Check the sandbox and Sandboxer service before retrying.
- sandboxer/destroy failure: Sandboxer request failed (HTTP 429). The provider reported quota. Check the sandbox and Sandboxer service before retrying.
- sandboxer/cold failure: Sandboxer request failed (HTTP 429). The provider reported quota. Check the sandbox and Sandboxer service before retrying.
- sandboxer/sandbox-lifetime skipped: Creation failed; billed lifetime unknown
- sandboxer/cold failure: Sandboxer request failed (HTTP 429). The provider reported quota. Check the sandbox and Sandboxer service before retrying.
- sandboxer/sandbox-lifetime skipped: Creation failed; billed lifetime unknown
- sandboxer/cold failure: Sandboxer request failed (HTTP 429). The provider reported quota. Check the sandbox and Sandboxer service before retrying.
- sandboxer/sandbox-lifetime skipped: Creation failed; billed lifetime unknown
- sandboxer/cold failure: Sandboxer request failed (HTTP 429). The provider reported quota. Check the sandbox and Sandboxer service before retrying.
- sandboxer/sandbox-lifetime skipped: Creation failed; billed lifetime unknown

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. Starts are admitted against live minute/hour/day limits before scenario deadlines; quota-waits.ndjson records admission wait separately from measured phases. The comp account supports 25 active sandboxes.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
