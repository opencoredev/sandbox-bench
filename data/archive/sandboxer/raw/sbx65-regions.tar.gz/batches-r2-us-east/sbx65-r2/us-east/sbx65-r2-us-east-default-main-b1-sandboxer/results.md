# Sandbox provider benchmark sbx65-r2-us-east-default-main-b1-sandboxer

Schema v2 · 2026-10-28T18:55:07.106Z · seed 45 · track default
Allocation sandboxer: requested null; template default
Collection: 2026-10-28T18:55:07.106Z through 2026-10-28T18:57:34.027Z
Host: AMD Ryzen 9 9955HX 16-Core Processor; linux; v26.3.0
Metadata: {"repositoryCommit":"a89eb27916660b995e632ee91e2691058b37f907","harnessCommit":"a89eb27916660b995e632ee91e2691058b37f907","sdkCommit":"dfbd85047ebe9687da6865799dbdde01507b87fb","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"runnerRegion":"us-east","runner":{"region":"us-east","label":"us-east-ms-a2","transport":"local","host":null,"datacenter":{"provider":"home","location":"Boca Raton, FL (ms-a2)"},"batchId":"sbx65-r2"},"clientLocation":{"ip":"redacted","city":"Boca Raton","region":"Florida","country":"US","org":"AS7018 AT&T Enterprises, LLC"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: nearest

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|cold|ms|10|0|0|0|351.50 [336.92, 359.01]|375.93|375.93|351.07 [341.89, 359.71]|320.96|375.93|14.361|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|fingerprint|ms|10|0|0|0|1468.5 [1278.2, 1471.0]|1473.0|1473.0|1430.7 [1371.9, 1470.4]|1269.7|1473.0|78.455|100.0% [0.72247, 1.0000]|0.00020000 USD|
|sandboxer|perf|ms|10|0|0|0|871.15 [868.44, 873.43]|873.91|873.91|871.46 [870.16, 872.71]|867.88|873.91|2.0003|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|cpu-single|iterations/s|10|0|0|0|1.3913e+7 [1.3584e+7, 1.4071e+7]|1.4158e+7|1.4158e+7|1.3746e+7 [1.3315e+7, 1.4024e+7]|1.1977e+7|1.4158e+7|6.1377e+5|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|cpu-all|iterations/s|10|0|0|0|3.0594e+7 [3.0310e+7, 3.3941e+7]|3.5780e+7|3.5780e+7|3.2012e+7 [3.0789e+7, 3.3397e+7]|2.9369e+7|3.5780e+7|2.1294e+6|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|memory-mbps|MB/s|10|0|0|0|37377 [35949, 38915]|40025|40025|37883 [36994, 38786]|35734|40025|1464.4|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-write-mbps|MB/s|10|0|0|0|1658.4 [1577.4, 1736.2]|1780.2|1780.2|1660.7 [1605.8, 1710.2]|1513.8|1780.2|81.194|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-read-mbps|MB/s|10|0|0|0|20222 [9845.0, 21637]|22732|22732|17809 [14148, 21188]|8315.1|22732|5561.6|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-4k-write-iops|IOPS|10|0|0|0|706.07 [702.91, 725.80]|791.84|791.84|717.97 [700.18, 739.68]|670.31|791.84|30.765|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|disk-4k-read-iops|IOPS|10|0|0|0|2.3623e+5 [2.3496e+5, 2.3833e+5]|2.6695e+5|2.6695e+5|2.4179e+5 [2.3511e+5, 2.5059e+5]|2.3029e+5|2.6695e+5|12531|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|tcp-ms|ms|10|0|0|0|1.3715 [1.3038, 1.4011]|1.4956|1.4956|1.3737 [1.3416, 1.4093]|1.3023|1.4956|0.054167|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|command|ms|10|0|0|0|69.060 [64.018, 70.759]|72.827|72.827|68.413 [66.423, 70.288]|63.309|72.827|3.0825|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|npm-install-prepare|ms|3|0|0|0|1266.1 [1144.9, 1322.3]|1322.3|1322.3|1244.4 [1144.9, 1322.3]|1144.9|1322.3|74.025|100.0% [0.43850, 1.0000]|0.000060000 USD|
|sandboxer|npm-install|ms|3|0|0|0|1271.1 [1270.2, 1465.9]|1465.9|1465.9|1335.7 [1270.2, 1465.9]|1270.2|1465.9|92.036|100.0% [0.43850, 1.0000]|0.000060000 USD|
|sandboxer|preview-provisioning|ms|3|0|0|0|132.90 [131.71, 136.97]|136.97|136.97|133.86 [131.71, 136.97]|131.71|136.97|2.2517|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|dev-server|ms|3|0|0|0|1125.9 [1114.4, 1132.4]|1132.4|1132.4|1124.3 [1114.4, 1132.4]|1114.4|1132.4|7.4385|100.0% [0.43850, 1.0000]|0.000060000 USD|
|sandboxer|preview-first-byte|ms|3|0|0|0|366.59 [364.67, 1726.8]|1726.8|1726.8|819.34 [364.67, 1726.8]|364.67|1726.8|641.65|100.0% [0.43850, 1.0000]|0.000040000 USD|
|sandboxer|edit-loop|ms|3|0|0|0|632.52 [631.60, 652.00]|652.00|652.00|638.71 [631.60, 652.00]|631.60|652.00|9.4055|100.0% [0.43850, 1.0000]|0.000030000 USD|
|sandboxer|pause-resume|ms|10|0|0|0|793.14 [792.45, 796.85]|812.98|812.98|795.79 [792.71, 800.19]|789.55|812.98|6.1470|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|tool-replay|ms|3|0|0|0|16379 [16357, 16388]|16388|16388|16375 [16357, 16388]|16357|16388|13.129|100.0% [0.43850, 1.0000]|0.00051000 USD|
|sandboxer|files-1kb|ms|10|0|0|0|289.96 [264.15, 368.27]|375.13|375.13|316.38 [288.07, 344.40]|258.44|375.13|45.062|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|git-clone|ms|3|0|0|0|670.53 [669.38, 1270.7]|1270.7|1270.7|870.19 [669.38, 1270.7]|669.38|1270.7|283.19|100.0% [0.43850, 1.0000]|0.000040000 USD|
|sandboxer|pip-install|ms|3|0|0|0|4068.0 [3669.9, 4472.4]|4472.4|4472.4|4070.1 [3669.9, 4472.4]|3669.9|4472.4|327.61|100.0% [0.43850, 1.0000]|0.00014000 USD|
|sandboxer|reconnect|ms|10|0|0|0|190.58 [183.03, 261.30]|338.00|338.00|222.00 [194.01, 254.69]|176.51|338.00|50.157|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|files-10mb|ms|10|0|0|0|1714.9 [1681.8, 1773.8]|2358.1|2358.1|1799.6 [1708.8, 1937.6]|1660.7|2358.1|196.95|100.0% [0.72247, 1.0000]|0.00021000 USD|
|sandboxer|destroy|ms|10|0|0|0|344.06 [342.86, 346.87]|347.68|347.68|344.67 [343.54, 345.85]|341.83|347.68|1.9195|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|reconnect-cleanup|ms|10|0|0|0|0.61723 [0.54169, 0.70252]|0.84417|0.84417|0.65225 [0.58907, 0.71972]|0.50908|0.84417|0.10233|100.0% [0.72247, 1.0000]|0.00010000 USD|
|sandboxer|sandbox-lifetime|ms|10|0|0|0|6332.3 [6239.7, 33166]|34092|34092|14565 [6400.4, 22814]|6081.0|34092|12574|100.0% [0.72247, 1.0000]|0.0015300 USD|
|sandboxer|tool-replay-prepare|ms|2|0|0|0|1200.0 [1200.0, 1302.3]|1302.3|1302.3|1251.1 [1200.0, 1302.3]|1200.0|1302.3|51.129|100.0% [0.34238, 1.0000]|0.000040000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux quiet-broad-walrus 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux wavy-cozy-bamboo 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux upbeat-ivory-pelican 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux perky-polar-walrus 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux perky-snug-oak 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux solar-smart-tapir 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux north-pacific-fox 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux sterling-tidy-beacon 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux hardy-candid-marsh 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux handy-clever-lily 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|0.0015300|0.15300|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|unknown|0.0090000|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|0/219|0.048811|0.098437|6.1264e+6|1.4227e+6|

Flagged samples:

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 10 sandbox attempts, estimated budget USD 0.0015300; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. Starts are admitted against live minute/hour/day limits before scenario deadlines; quota-waits.ndjson records admission wait separately from measured phases. The comp account supports 25 active sandboxes.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
