# Sandbox provider benchmark sbx61-sandboxer-pilot-003

Schema v2 · 2026-10-23T18:30:46.798Z · seed 45 · track default
Allocation sandboxer: requested null; template default
Collection: 2026-10-23T18:30:46.798Z through 2026-10-23T18:32:11.496Z
Host: AMD Ryzen 9 9955HX 16-Core Processor; linux; v26.3.0
Metadata: {"repositoryCommit":"f9a310d9b249d213193ddc0c5ca40cdc6ee1c845","harnessCommit":"f9a310d9b249d213193ddc0c5ca40cdc6ee1c845","sdkCommit":"9d94d345681b95fc558a780e34534e79263979f4","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"clientLocation":{"ip":"redacted","city":"Boca Raton","region":"Florida","country":"US","org":"AS7018 AT&T Enterprises, LLC"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: eu-central

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|cold|ms|2|0|0|0|1798.7 [1798.7, 2578.0]|2578.0|2578.0|2188.3 [1798.7, 2578.0]|1798.7|2578.0|389.66|100.0% [0.34238, 1.0000]|0.000050000 USD|
|sandboxer|fingerprint|ms|2|0|0|0|1458.3 [1458.3, 1465.0]|1465.0|1465.0|1461.7 [1458.3, 1465.0]|1458.3|1465.0|3.3261|100.0% [0.34238, 1.0000]|0.000040000 USD|
|sandboxer|perf|ms|2|0|0|0|464.96 [464.96, 661.12]|661.12|661.12|563.04 [464.96, 661.12]|464.96|661.12|98.082|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|cpu-single|iterations/s|2|0|0|0|1.6742e+7 [1.6742e+7, 1.6915e+7]|1.6915e+7|1.6915e+7|1.6829e+7 [1.6742e+7, 1.6915e+7]|1.6742e+7|1.6915e+7|86521|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|cpu-all|iterations/s|2|0|0|0|3.5255e+7 [3.5255e+7, 5.8197e+7]|5.8197e+7|5.8197e+7|4.6726e+7 [3.5255e+7, 5.8197e+7]|3.5255e+7|5.8197e+7|1.1471e+7|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|memory-mbps|MB/s|2|0|0|0|32409 [32409, 38262]|38262|38262|35336 [32409, 38262]|32409|38262|2926.8|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|disk-write-mbps|MB/s|2|0|0|0|1781.9 [1781.9, 1787.4]|1787.4|1787.4|1784.6 [1781.9, 1787.4]|1781.9|1787.4|2.7680|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|disk-read-mbps|MB/s|2|0|0|0|18480 [18480, 22335]|22335|22335|20407 [18480, 22335]|18480|22335|1927.5|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|disk-4k-write-iops|IOPS|2|0|0|0|9661.1 [9661.1, 10955]|10955|10955|10308 [9661.1, 10955]|9661.1|10955|647.12|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|disk-4k-read-iops|IOPS|2|0|0|0|5.9559e+5 [5.9559e+5, 6.0909e+5]|6.0909e+5|6.0909e+5|6.0234e+5 [5.9559e+5, 6.0909e+5]|5.9559e+5|6.0909e+5|6750.8|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|tcp-ms|ms|2|0|0|0|1.4729 [1.4729, 3.2000]|3.2000|3.2000|2.3365 [1.4729, 3.2000]|1.4729|3.2000|0.86358|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|command|ms|2|0|0|0|256.60 [256.60, 264.19]|264.19|264.19|260.39 [256.60, 264.19]|256.60|264.19|3.7985|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|npm-install-prepare|ms|1|0|0|0|2829.9 [2829.9, 2829.9]|2829.9|2829.9|2829.9 [2829.9, 2829.9]|2829.9|2829.9|0.0000|100.0% [0.20655, 1.0000]|0.000030000 USD|
|sandboxer|npm-install|ms|1|0|0|0|861.10 [861.10, 861.10]|861.10|861.10|861.10 [861.10, 861.10]|861.10|861.10|0.0000|100.0% [0.20655, 1.0000]|0.000010000 USD|
|sandboxer|preview-provisioning|ms|1|0|0|0|483.02 [483.02, 483.02]|483.02|483.02|483.02 [483.02, 483.02]|483.02|483.02|0.0000|100.0% [0.20655, 1.0000]|0.000010000 USD|
|sandboxer|dev-server|ms|1|0|0|0|2998.1 [2998.1, 2998.1]|2998.1|2998.1|2998.1 [2998.1, 2998.1]|2998.1|2998.1|0.0000|100.0% [0.20655, 1.0000]|0.000030000 USD|
|sandboxer|preview-first-byte|ms|1|0|0|0|343.81 [343.81, 343.81]|343.81|343.81|343.81 [343.81, 343.81]|343.81|343.81|0.0000|100.0% [0.20655, 1.0000]|0.000010000 USD|
|sandboxer|edit-loop|ms|1|0|0|0|1163.0 [1163.0, 1163.0]|1163.0|1163.0|1163.0 [1163.0, 1163.0]|1163.0|1163.0|0.0000|100.0% [0.20655, 1.0000]|0.000020000 USD|
|sandboxer|pause-resume|ms|2|0|0|0|2164.3 [2164.3, 2514.4]|2514.4|2514.4|2339.3 [2164.3, 2514.4]|2164.3|2514.4|175.07|100.0% [0.34238, 1.0000]|0.000060000 USD|
|sandboxer|tool-replay|ms|1|0|0|0|31489 [31489, 31489]|31489|31489|31489 [31489, 31489]|31489|31489|0.0000|100.0% [0.20655, 1.0000]|0.00032000 USD|
|sandboxer|files-1kb|ms|2|0|0|0|573.85 [573.85, 609.58]|609.58|609.58|591.72 [573.85, 609.58]|573.85|609.58|17.869|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|git-clone|ms|1|0|0|0|1458.4 [1458.4, 1458.4]|1458.4|1458.4|1458.4 [1458.4, 1458.4]|1458.4|1458.4|0.0000|100.0% [0.20655, 1.0000]|0.000020000 USD|
|sandboxer|pip-install|ms|1|0|0|0|3262.5 [3262.5, 3262.5]|3262.5|3262.5|3262.5 [3262.5, 3262.5]|3262.5|3262.5|0.0000|100.0% [0.20655, 1.0000]|0.000040000 USD|
|sandboxer|snapshot-setup|ms|2|0|0|0|35.635 [35.635, 39.938]|39.938|39.938|37.787 [35.635, 39.938]|35.635|39.938|2.1514|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|snapshot|ms|2|0|0|0|345.89 [345.89, 348.12]|348.12|348.12|347.00 [345.89, 348.12]|345.89|348.12|1.1167|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|snapshot-total|ms|2|0|0|0|420.38 [420.38, 456.86]|456.86|456.86|438.62 [420.38, 456.86]|420.38|456.86|18.242|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|create-from-snapshot|ms|2|0|0|0|1734.4 [1734.4, 2604.6]|2604.6|2604.6|2169.5 [1734.4, 2604.6]|1734.4|2604.6|435.09|100.0% [0.34238, 1.0000]|0.000050000 USD|
|sandboxer|restore-fingerprint|ms|2|0|0|0|1459.5 [1459.5, 1463.3]|1463.3|1463.3|1461.4 [1459.5, 1463.3]|1459.5|1463.3|1.8922|100.0% [0.34238, 1.0000]|0.000040000 USD|
|sandboxer|restore-destroy|ms|2|0|0|0|341.48 [341.48, 343.59]|343.59|343.59|342.53 [341.48, 343.59]|341.48|343.59|1.0517|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|snapshot-cleanup|ms|2|0|0|0|69.006 [69.006, 74.697]|74.697|74.697|71.851 [69.006, 74.697]|69.006|74.697|2.8459|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|reconnect|ms|2|0|0|0|441.99 [441.99, 470.28]|470.28|470.28|456.13 [441.99, 470.28]|441.99|470.28|14.147|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|files-10mb|ms|2|0|0|0|5589.1 [5589.1, 5761.9]|5761.9|5761.9|5675.5 [5589.1, 5761.9]|5589.1|5761.9|86.410|100.0% [0.34238, 1.0000]|0.00012000 USD|
|sandboxer|destroy|ms|2|0|0|0|906.60 [906.60, 908.00]|908.00|908.00|907.30 [906.60, 908.00]|906.60|908.00|0.70083|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|reconnect-cleanup|ms|2|0|0|0|0.57379 [0.57379, 0.89923]|0.89923|0.89923|0.73651 [0.57379, 0.89923]|0.57379|0.89923|0.16272|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|sandbox-lifetime|ms|2|0|0|0|19531 [19531, 64663]|64663|64663|42097 [19531, 64663]|19531|64663|22566|100.0% [0.34238, 1.0000]|0.00094000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux stormy-first-anvil 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux woody-golden-kettle 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|0.00094000|0.47000|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|0.030980|0.013800|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|0/61|0.32710|0.47906|3.1940e+5|1.5701e+6|

Flagged samples:

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 4 sandbox attempts, estimated budget USD 0.00094000; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. Starts are admitted against live minute/hour/day limits before scenario deadlines; quota-waits.ndjson records admission wait separately from measured phases. The comp account supports 25 active sandboxes.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
