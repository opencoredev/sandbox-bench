# Sandbox provider benchmark sbx61-default-sandboxer-r4-snapshot

Schema v2 · 2026-10-28T19:37:06.447Z · seed 45 · track default
Allocation sandboxer: requested null; template default
Collection: 2026-10-28T19:37:06.447Z through 2026-10-28T19:39:09.025Z
Host: AMD Ryzen 9 9955HX 16-Core Processor; linux; v26.3.0
Metadata: {"repositoryCommit":"ee79701b47e2757f891510ebd05c096f78f1695b","harnessCommit":"ee79701b47e2757f891510ebd05c096f78f1695b","sdkCommit":"965130b65b472f4383d1112947ff45bbcb264b95","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"clientLocation":{"ip":"redacted","city":"Boca Raton","region":"Florida","country":"US","org":"AS7018 AT&T Enterprises, LLC"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: us-east

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|cold|ms|20|0|0|0|338.81 [335.56, 344.24]|353.84|356.56|340.09 [335.92, 344.15]|318.62|356.56|9.4124|100.0% [0.83887, 1.0000]|0.00020000 USD|
|sandboxer|fingerprint|ms|20|0|0|0|1468.6 [1274.5, 1470.4]|1474.2|1492.0|1402.2 [1361.2, 1442.5]|1266.5|1492.0|95.479|100.0% [0.83887, 1.0000]|0.00040000 USD|
|sandboxer|snapshot-setup|ms|20|0|0|0|36.208 [34.911, 37.382]|39.315|39.874|36.474 [35.692, 37.321]|33.740|39.874|1.8469|100.0% [0.83887, 1.0000]|0.00020000 USD|
|sandboxer|snapshot|ms|20|0|0|0|345.66 [345.39, 346.96]|349.71|349.97|346.28 [345.14, 347.24]|340.83|349.97|2.3575|100.0% [0.83887, 1.0000]|0.00020000 USD|
|sandboxer|snapshot-total|ms|20|0|0|0|423.02 [421.53, 424.50]|431.15|431.49|423.72 [421.86, 425.53]|414.56|431.49|4.0832|100.0% [0.83887, 1.0000]|0.00020000 USD|
|sandboxer|create-from-snapshot|ms|20|0|0|0|1202.6 [1179.7, 1222.2]|1266.8|1304.2|1202.6 [1182.5, 1221.5]|1121.5|1304.2|42.559|100.0% [0.83887, 1.0000]|0.00040000 USD|
|sandboxer|restore-fingerprint|ms|20|0|0|0|1471.4 [1470.6, 1471.9]|1475.6|1476.1|1471.6 [1470.7, 1472.6]|1467.5|1476.1|2.1196|100.0% [0.83887, 1.0000]|0.00040000 USD|
|sandboxer|restore-destroy|ms|20|0|0|0|347.51 [344.38, 347.88]|349.99|350.79|346.77 [345.83, 347.69]|343.27|350.79|2.1369|100.0% [0.83887, 1.0000]|0.00020000 USD|
|sandboxer|snapshot-cleanup|ms|20|0|0|0|67.194 [66.564, 68.181]|69.720|69.790|67.532 [66.989, 68.094]|65.471|69.790|1.2672|100.0% [0.83887, 1.0000]|0.00020000 USD|
|sandboxer|destroy|ms|20|0|0|0|345.78 [344.07, 347.73]|349.33|350.21|346.24 [345.28, 347.19]|343.38|350.21|2.2010|100.0% [0.83887, 1.0000]|0.00020000 USD|
|sandboxer|sandbox-lifetime|ms|20|0|0|0|6051.5 [5917.2, 6085.5]|6148.3|6219.6|6017.4 [5969.5, 6066.2]|5825.9|6219.6|109.55|100.0% [0.83887, 1.0000]|0.0021300 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux dizzy-gleaming-raven 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux muted-rocky-zinnia 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux airy-maple-brook 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux plucky-level-cinder 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux earnest-level-bamboo 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux simple-easy-canal 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux honest-violet-alder 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux modest-silent-juniper 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux dizzy-scarlet-lily 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux ardent-zealous-pelican 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux violet-fresh-cargo 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux lazy-urban-dahlia 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux outer-formal-bloom 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux dawn-fresh-lily 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux busy-dawn-daisy 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux mighty-global-heron 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux maple-open-salmon 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux super-formal-harbor 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux arctic-stellar-honey 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux mighty-limber-lynx 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|0.0021300|0.10650|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|unknown|unknown|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|0/220|0.012038|0.011250|40610|21873|

Flagged samples:

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 40 sandbox attempts, estimated budget USD 0.0021300; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. Starts are admitted against live minute/hour/day limits before scenario deadlines; quota-waits.ndjson records admission wait separately from measured phases. The comp account supports 25 active sandboxes.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
