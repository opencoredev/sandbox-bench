# Sandbox provider benchmark sbx61-same-spec-sandboxer-r4-burst

Schema v2 · 2026-10-28T20:00:19.399Z · seed 45 · track same-spec
Allocation sandboxer: requested null; template default
Collection: 2026-10-28T20:00:19.399Z through 2026-10-28T20:02:28.433Z
Host: AMD Ryzen 9 9955HX 16-Core Processor; linux; v26.3.0
Metadata: {"repositoryCommit":"ee79701b47e2757f891510ebd05c096f78f1695b","harnessCommit":"ee79701b47e2757f891510ebd05c096f78f1695b","sdkCommit":"965130b65b472f4383d1112947ff45bbcb264b95","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"clientLocation":{"ip":"redacted","city":"Boca Raton","region":"Florida","country":"US","org":"AS7018 AT&T Enterprises, LLC"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: us-east

cleanupReview: []
cleanupReleased: []
cleanupResolved: [{"provider":"sandboxer","id":"sb_mp1o2iffw8","kind":"sandbox","reason":"Exact native lookup confirmed absence","resolution":"absent","evidence":{"result":"not-found","method":"sandboxer:native-exact-get","checkedAt":"2026-10-28T20:02:25.331Z","httpStatus":404}},{"provider":"sandboxer","id":"sb_07415zyeod","kind":"sandbox","reason":"Exact native lookup confirmed absence","resolution":"absent","evidence":{"result":"not-found","method":"sandboxer:native-exact-get","checkedAt":"2026-10-28T20:02:25.331Z","httpStatus":404}},{"provider":"sandboxer","id":"sb_osjuziuf4p","kind":"sandbox","reason":"Exact native lookup confirmed absence","resolution":"absent","evidence":{"result":"not-found","method":"sandboxer:native-exact-get","checkedAt":"2026-10-28T20:02:25.332Z","httpStatus":404}}]

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|burst-10/cold|ms|30|0|0|0|469.33 [452.69, 482.46]|519.47|525.61|467.69 [455.32, 478.57]|405.15|525.61|32.018|100.0% [0.88649, 1.0000]|0.00030000 USD|
|sandboxer|burst-10/fingerprint|ms|30|0|0|0|1470.1 [1467.0, 1471.2]|1477.2|1480.6|1438.1 [1411.0, 1463.1]|1271.0|1480.6|73.108|100.0% [0.88649, 1.0000]|0.00060000 USD|
|sandboxer|burst-10/destroy|ms|30|0|0|0|626.94 [623.91, 642.12]|657.62|661.49|596.09 [557.36, 626.86]|342.94|661.49|99.430|100.0% [0.88649, 1.0000]|0.00030000 USD|
|sandboxer|burst-10/sandbox-lifetime|ms|30|0|0|0|2760.3 [2741.5, 2786.2]|1.2281e+5|1.2283e+5|14736 [2727.2, 30716]|2438.0|1.2283e+5|36025|100.0% [0.88649, 1.0000]|0.0045000 USD|
|sandboxer|burst-10/all-ready|ms|3|0|0|0|527.43 [509.42, 537.79]|537.79|537.79|524.88 [509.42, 537.79]|509.42|537.79|11.725|100.0% [0.43850, 1.0000]|unknown USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|unknown|unknown|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|unknown|unknown|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|0/123|0.039245|0.035625|1.1477e+6|2.4982e+5|

Flagged samples:

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 30 sandbox attempts, estimated budget USD 0.0045000; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. Starts are admitted against live minute/hour/day limits before scenario deadlines; quota-waits.ndjson records admission wait separately from measured phases. The comp account supports 25 active sandboxes.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
