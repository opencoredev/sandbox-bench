# Sandbox provider benchmark sbx61-sandboxer-pilot-002

Schema v2 · 2026-10-23T18:18:32.817Z · seed 45 · track default
Allocation sandboxer: requested null; template default
Collection: 2026-10-23T18:18:32.817Z through 2026-10-23T18:21:11.651Z
Host: AMD Ryzen 9 9955HX 16-Core Processor; linux; v26.3.0
Metadata: {"repositoryCommit":"9d94d345681b95fc558a780e34534e79263979f4","harnessCommit":"9d94d345681b95fc558a780e34534e79263979f4","sdkCommit":"9d94d345681b95fc558a780e34534e79263979f4","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"clientLocation":{"ip":"redacted","city":"Boca Raton","region":"Florida","country":"US","org":"AS7018 AT&T Enterprises, LLC"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: eu-central

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|cold|ms|2|0|0|0|2194.1 [2194.1, 2225.8]|2225.8|2225.8|2209.9 [2194.1, 2225.8]|2194.1|2225.8|15.825|100.0% [0.34238, 1.0000]|0.000060000 USD|
|sandboxer|fingerprint|ms|2|0|0|0|1463.1 [1463.1, 1467.2]|1467.2|1467.2|1465.1 [1463.1, 1467.2]|1463.1|1467.2|2.0611|100.0% [0.34238, 1.0000]|0.000040000 USD|
|sandboxer|perf|ms|2|0|0|0|665.43 [665.43, 1479.0]|1479.0|1479.0|1072.2 [665.43, 1479.0]|665.43|1479.0|406.76|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|cpu-single|iterations/s|2|0|0|0|1.4976e+7 [1.4976e+7, 1.6521e+7]|1.6521e+7|1.6521e+7|1.5748e+7 [1.4976e+7, 1.6521e+7]|1.4976e+7|1.6521e+7|7.7278e+5|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|cpu-all|iterations/s|2|0|0|0|2.6069e+7 [2.6069e+7, 4.4182e+7]|4.4182e+7|4.4182e+7|3.5126e+7 [2.6069e+7, 4.4182e+7]|2.6069e+7|4.4182e+7|9.0564e+6|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|memory-mbps|MB/s|2|0|0|0|10995 [10995, 21940]|21940|21940|16468 [10995, 21940]|10995|21940|5472.2|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|disk-write-mbps|MB/s|2|0|0|0|173.51 [173.51, 1758.9]|1758.9|1758.9|966.21 [173.51, 1758.9]|173.51|1758.9|792.69|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|disk-read-mbps|MB/s|2|0|0|0|7281.5 [7281.5, 18183]|18183|18183|12732 [7281.5, 18183]|7281.5|18183|5450.7|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|disk-4k-write-iops|IOPS|2|0|0|0|8619.3 [8619.3, 9487.8]|9487.8|9487.8|9053.5 [8619.3, 9487.8]|8619.3|9487.8|434.27|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|disk-4k-read-iops|IOPS|2|0|0|0|5.1697e+5 [5.1697e+5, 5.8258e+5]|5.8258e+5|5.8258e+5|5.4977e+5 [5.1697e+5, 5.8258e+5]|5.1697e+5|5.8258e+5|32803|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|tcp-ms|ms|2|0|0|0|1.5307 [1.5307, 2.7932]|2.7932|2.7932|2.1620 [1.5307, 2.7932]|1.5307|2.7932|0.63124|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|command|ms|2|0|0|0|259.07 [259.07, 261.50]|261.50|261.50|260.29 [259.07, 261.50]|259.07|261.50|1.2175|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|npm-install-prepare|ms|1|0|0|0|2829.2 [2829.2, 2829.2]|2829.2|2829.2|2829.2 [2829.2, 2829.2]|2829.2|2829.2|0.0000|100.0% [0.20655, 1.0000]|0.000030000 USD|
|sandboxer|npm-install|ms|1|0|0|0|1060.2 [1060.2, 1060.2]|1060.2|1060.2|1060.2 [1060.2, 1060.2]|1060.2|1060.2|0.0000|100.0% [0.20655, 1.0000]|0.000020000 USD|
|sandboxer|preview-provisioning|ms|1|0|0|0|562.69 [562.69, 562.69]|562.69|562.69|562.69 [562.69, 562.69]|562.69|562.69|0.0000|100.0% [0.20655, 1.0000]|0.000010000 USD|
|sandboxer|dev-server|ms|1|0|0|0|2983.8 [2983.8, 2983.8]|2983.8|2983.8|2983.8 [2983.8, 2983.8]|2983.8|2983.8|0.0000|100.0% [0.20655, 1.0000]|0.000030000 USD|
|sandboxer|preview-first-byte|ms|1|0|0|0|342.45 [342.45, 342.45]|342.45|342.45|342.45 [342.45, 342.45]|342.45|342.45|0.0000|100.0% [0.20655, 1.0000]|0.000010000 USD|
|sandboxer|edit-loop|ms|1|0|0|0|1173.1 [1173.1, 1173.1]|1173.1|1173.1|1173.1 [1173.1, 1173.1]|1173.1|1173.1|0.0000|100.0% [0.20655, 1.0000]|0.000020000 USD|
|sandboxer|pause-resume|ms|2|0|0|0|2144.1 [2144.1, 8338.5]|8338.5|8338.5|5241.3 [2144.1, 8338.5]|2144.1|8338.5|3097.2|100.0% [0.34238, 1.0000]|0.00012000 USD|
|sandboxer|tool-replay|ms|1|0|0|0|31140 [31140, 31140]|31140|31140|31140 [31140, 31140]|31140|31140|0.0000|100.0% [0.20655, 1.0000]|0.00032000 USD|
|sandboxer|files-1kb|ms|2|0|0|0|574.68 [574.68, 618.52]|618.52|618.52|596.60 [574.68, 618.52]|574.68|618.52|21.916|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|git-clone|ms|1|0|0|0|1664.5 [1664.5, 1664.5]|1664.5|1664.5|1664.5 [1664.5, 1664.5]|1664.5|1664.5|0.0000|100.0% [0.20655, 1.0000]|0.000020000 USD|
|sandboxer|pip-install|ms|1|0|0|0|3266.3 [3266.3, 3266.3]|3266.3|3266.3|3266.3 [3266.3, 3266.3]|3266.3|3266.3|0.0000|100.0% [0.20655, 1.0000]|0.000040000 USD|
|sandboxer|snapshot-setup|ms|2|0|0|0|42.832 [42.832, 50.127]|50.127|50.127|46.480 [42.832, 50.127]|42.832|50.127|3.6473|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|snapshot|ms|2|0|0|0|342.36 [342.36, 346.06]|346.06|346.06|344.21 [342.36, 346.06]|342.36|346.06|1.8509|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|snapshot-total|ms|2|0|0|0|440.58 [440.58, 459.44]|459.44|459.44|450.01 [440.58, 459.44]|440.58|459.44|9.4300|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|snapshot-source-pause|ms|2|0|0|0|1189.4 [1189.4, 1757.1]|1757.1|1757.1|1473.2 [1189.4, 1757.1]|1189.4|1757.1|283.87|100.0% [0.34238, 1.0000]|0.000040000 USD|
|sandboxer|create-from-snapshot|ms|2|0|0|0|1771.8 [1771.8, 2329.8]|2329.8|2329.8|2050.8 [1771.8, 2329.8]|1771.8|2329.8|279.02|100.0% [0.34238, 1.0000]|0.000050000 USD|
|sandboxer|restore-fingerprint|ms|2|0|0|0|1461.6 [1461.6, 1462.5]|1462.5|1462.5|1462.1 [1461.6, 1462.5]|1461.6|1462.5|0.45080|100.0% [0.34238, 1.0000]|0.000040000 USD|
|sandboxer|restore-destroy|ms|2|0|0|0|343.10 [343.10, 344.55]|344.55|344.55|343.82 [343.10, 344.55]|343.10|344.55|0.72546|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|snapshot-cleanup|ms|2|0|0|0|71.145 [71.145, 85.544]|85.544|85.544|78.344 [71.145, 85.544]|71.145|85.544|7.1994|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|snapshot-source-resume|ms|2|0|0|0|657.68 [657.68, 659.51]|659.51|659.51|658.60 [657.68, 659.51]|657.68|659.51|0.91467|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|reconnect|ms|2|0|0|0|438.27 [438.27, 775.52]|775.52|775.52|606.89 [438.27, 775.52]|438.27|775.52|168.62|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|files-10mb|ms|2|0|0|0|6624.4 [6624.4, 7250.6]|7250.6|7250.6|6937.5 [6624.4, 7250.6]|6624.4|7250.6|313.10|100.0% [0.34238, 1.0000]|0.00015000 USD|
|sandboxer|destroy|ms|2|0|0|0|901.10 [901.10, 1186.5]|1186.5|1186.5|1043.8 [901.10, 1186.5]|901.10|1186.5|142.68|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|reconnect-cleanup|ms|2|0|0|0|0.60052 [0.60052, 0.81605]|0.81605|0.81605|0.70829 [0.60052, 0.81605]|0.60052|0.81605|0.10777|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|sandbox-lifetime|ms|2|0|0|0|29806 [29806, 68303]|68303|68303|49054 [29806, 68303]|29806|68303|19249|100.0% [0.34238, 1.0000]|0.0011200 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux serene-focal-apple 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux sure-tulip-clam 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|0.0011200|0.56000|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|0.036860|0.014100|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|0/65|0.19804|0.27375|4.9534e+5|1.1513e+6|

Flagged samples:

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 4 sandbox attempts, estimated budget USD 0.0011200; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. The source is paused before restore and resumed after restored-VM cleanup to keep within the TRIAL account active limit; these phases are separate from native snapshot and restore timings. Serial Sandboxer iterations have a 60.5-second cooldown outside scenario timers to clear the 5-starts/minute TRIAL window.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
