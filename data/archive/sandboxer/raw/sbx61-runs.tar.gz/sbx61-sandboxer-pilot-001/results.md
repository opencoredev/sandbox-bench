# Sandbox provider benchmark sbx61-sandboxer-pilot-001

Schema v2 · 2026-10-23T18:14:04.843Z · seed 45 · track default
Allocation sandboxer: requested null; template default
Collection: 2026-10-23T18:14:04.843Z through 2026-10-23T18:15:33.708Z
Host: AMD Ryzen 9 9955HX 16-Core Processor; linux; v26.3.0
Metadata: {"repositoryCommit":"5443abb59badfbc300ff55bc42859f4d32b4f384","harnessCommit":"5443abb59badfbc300ff55bc42859f4d32b4f384","sdkCommit":"462978e630d6ec18a8e76fcd87b0e1dbec331c77","dirty":true,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"clientLocation":{"ip":"redacted","city":"Boca Raton","region":"Florida","country":"US","org":"AS7018 AT&T Enterprises, LLC"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: eu-central

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|cold|ms|2|0|0|0|1882.8 [1882.8, 2729.0]|2729.0|2729.0|2305.9 [1882.8, 2729.0]|1882.8|2729.0|423.12|100.0% [0.34238, 1.0000]|0.000050000 USD|
|sandboxer|fingerprint|ms|2|0|0|0|1462.3 [1462.3, 1465.1]|1465.1|1465.1|1463.7 [1462.3, 1465.1]|1462.3|1465.1|1.4102|100.0% [0.34238, 1.0000]|0.000040000 USD|
|sandboxer|perf|ms|2|0|0|0|658.24 [658.24, 1489.9]|1489.9|1489.9|1074.1 [658.24, 1489.9]|658.24|1489.9|415.82|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|cpu-single|iterations/s|2|0|0|0|1.3936e+7 [1.3936e+7, 1.6880e+7]|1.6880e+7|1.6880e+7|1.5408e+7 [1.3936e+7, 1.6880e+7]|1.3936e+7|1.6880e+7|1.4720e+6|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|cpu-all|iterations/s|2|0|0|0|2.6188e+7 [2.6188e+7, 4.0581e+7]|4.0581e+7|4.0581e+7|3.3384e+7 [2.6188e+7, 4.0581e+7]|2.6188e+7|4.0581e+7|7.1966e+6|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|memory-mbps|MB/s|2|0|0|0|22799 [22799, 28619]|28619|28619|25709 [22799, 28619]|22799|28619|2910.2|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|disk-write-mbps|MB/s|2|0|0|0|196.04 [196.04, 1726.6]|1726.6|1726.6|961.33 [196.04, 1726.6]|196.04|1726.6|765.30|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|disk-read-mbps|MB/s|2|0|0|0|4059.7 [4059.7, 12181]|12181|12181|8120.5 [4059.7, 12181]|4059.7|12181|4060.9|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|disk-4k-write-iops|IOPS|2|0|0|0|8865.0 [8865.0, 11133]|11133|11133|9998.8 [8865.0, 11133]|8865.0|11133|1133.8|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|disk-4k-read-iops|IOPS|2|0|0|0|4.8083e+5 [4.8083e+5, 5.8601e+5]|5.8601e+5|5.8601e+5|5.3342e+5 [4.8083e+5, 5.8601e+5]|4.8083e+5|5.8601e+5|52590|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|tcp-ms|ms|2|0|0|0|1.5864 [1.5864, 7.7010]|7.7010|7.7010|4.6437 [1.5864, 7.7010]|1.5864|7.7010|3.0573|100.0% [0.34238, 1.0000]|0.000030000 USD|
|sandboxer|command|ms|2|0|0|0|256.36 [256.36, 273.75]|273.75|273.75|265.05 [256.36, 273.75]|256.36|273.75|8.6981|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|npm-install-prepare|ms|1|0|0|0|2844.7 [2844.7, 2844.7]|2844.7|2844.7|2844.7 [2844.7, 2844.7]|2844.7|2844.7|0.0000|100.0% [0.20655, 1.0000]|0.000030000 USD|
|sandboxer|npm-install|ms|1|0|0|0|856.71 [856.71, 856.71]|856.71|856.71|856.71 [856.71, 856.71]|856.71|856.71|0.0000|100.0% [0.20655, 1.0000]|0.000010000 USD|
|sandboxer|preview-provisioning|ms|1|0|0|0|466.96 [466.96, 466.96]|466.96|466.96|466.96 [466.96, 466.96]|466.96|466.96|0.0000|100.0% [0.20655, 1.0000]|0.000010000 USD|
|sandboxer|dev-server|ms|1|0|0|0|2995.3 [2995.3, 2995.3]|2995.3|2995.3|2995.3 [2995.3, 2995.3]|2995.3|2995.3|0.0000|100.0% [0.20655, 1.0000]|0.000030000 USD|
|sandboxer|preview-first-byte|ms|1|0|0|0|348.96 [348.96, 348.96]|348.96|348.96|348.96 [348.96, 348.96]|348.96|348.96|0.0000|100.0% [0.20655, 1.0000]|0.000010000 USD|
|sandboxer|edit-loop|ms|1|0|0|0|1159.2 [1159.2, 1159.2]|1159.2|1159.2|1159.2 [1159.2, 1159.2]|1159.2|1159.2|0.0000|100.0% [0.20655, 1.0000]|0.000020000 USD|
|sandboxer|pause-resume|ms|1|1|0|0|2134.3 [2134.3, 2134.3]|2134.3|2134.3|2134.3 [2134.3, 2134.3]|2134.3|2134.3|0.0000|50.0% [0.094531, 0.90547]|0.00011000 USD|
|sandboxer|tool-replay|ms|1|0|0|0|31149 [31149, 31149]|31149|31149|31149 [31149, 31149]|31149|31149|0.0000|100.0% [0.20655, 1.0000]|0.00032000 USD|
|sandboxer|files-1kb|ms|2|0|0|0|572.91 [572.91, 621.50]|621.50|621.50|597.21 [572.91, 621.50]|572.91|621.50|24.294|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|git-clone|ms|1|0|0|0|1860.1 [1860.1, 1860.1]|1860.1|1860.1|1860.1 [1860.1, 1860.1]|1860.1|1860.1|0.0000|100.0% [0.20655, 1.0000]|0.000020000 USD|
|sandboxer|pip-install|ms|1|0|0|0|3260.9 [3260.9, 3260.9]|3260.9|3260.9|3260.9 [3260.9, 3260.9]|3260.9|3260.9|0.0000|100.0% [0.20655, 1.0000]|0.000040000 USD|
|sandboxer|snapshot-setup|ms|2|0|0|0|36.992 [36.992, 46.262]|46.262|46.262|41.627 [36.992, 46.262]|36.992|46.262|4.6346|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|snapshot|ms|2|0|0|0|343.13 [343.13, 346.91]|346.91|346.91|345.02 [343.13, 346.91]|343.13|346.91|1.8892|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|snapshot-total|ms|2|0|0|0|432.37 [432.37, 467.06]|467.06|467.06|449.71 [432.37, 467.06]|432.37|467.06|17.342|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|snapshot-source-pause|ms|2|0|0|0|1193.3 [1193.3, 1753.5]|1753.5|1753.5|1473.4 [1193.3, 1753.5]|1193.3|1753.5|280.09|100.0% [0.34238, 1.0000]|0.000040000 USD|
|sandboxer|create-from-snapshot|ms|2|0|0|0|1824.0 [1824.0, 2295.7]|2295.7|2295.7|2059.9 [1824.0, 2295.7]|1824.0|2295.7|235.89|100.0% [0.34238, 1.0000]|0.000050000 USD|
|sandboxer|restore-fingerprint|ms|2|0|0|0|1461.6 [1461.6, 1469.2]|1469.2|1469.2|1465.4 [1461.6, 1469.2]|1461.6|1469.2|3.7813|100.0% [0.34238, 1.0000]|0.000040000 USD|
|sandboxer|restore-destroy|ms|2|0|0|0|343.67 [343.67, 344.10]|344.10|344.10|343.89 [343.67, 344.10]|343.67|344.10|0.21471|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|snapshot-cleanup|ms|2|0|0|0|66.063 [66.063, 68.628]|68.628|68.628|67.345 [66.063, 68.628]|66.063|68.628|1.2824|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|snapshot-source-resume|ms|2|0|0|0|664.49 [664.49, 933.53]|933.53|933.53|799.01 [664.49, 933.53]|664.49|933.53|134.52|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|reconnect|ms|2|0|0|0|438.25 [438.25, 764.81]|764.81|764.81|601.53 [438.25, 764.81]|438.25|764.81|163.28|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|files-10mb|ms|1|0|1|0|5407.8 [5407.8, 5407.8]|5407.8|5407.8|5407.8 [5407.8, 5407.8]|5407.8|5407.8|0.0000|100.0% [0.20655, 1.0000]|0.000070000 USD|
|sandboxer|destroy|ms|2|0|0|0|342.42 [342.42, 901.58]|901.58|901.58|622.00 [342.42, 901.58]|342.42|901.58|279.58|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|reconnect-cleanup|ms|2|0|0|0|0.55514 [0.55514, 0.79087]|0.79087|0.79087|0.67300 [0.55514, 0.79087]|0.55514|0.79087|0.11786|100.0% [0.34238, 1.0000]|0.000020000 USD|
|sandboxer|sandbox-lifetime|ms|2|0|0|0|21969 [21969, 66646]|66646|66646|44307 [21969, 66646]|21969|66646|22339|100.0% [0.34238, 1.0000]|0.0010200 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux cheery-witty-orchid 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD Ryzen 9 7950X3D 16-Core Processor|4|unlimited|7.7537|55.771|Linux trusty-mossy-reef 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"62.238.91.250","hostname":"static.250.91.238.62.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|0.0010200|0.51000|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|0.033870|0.013800|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|0/65|0.19769|0.25625|3.2703e+5|8.3781e+5|

Flagged samples:

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 4 sandbox attempts, estimated budget USD 0.0010200; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.
- sandboxer/pause-resume failure: Sandboxer request failed. The provider reported quota. Check the sandbox and Sandboxer service before retrying.
- sandboxer/files-10mb blocked: Blocked by pause-resume

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. The source is paused before restore and resumed after restored-VM cleanup to keep within the TRIAL account active limit; these phases are separate from native snapshot and restore timings.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
