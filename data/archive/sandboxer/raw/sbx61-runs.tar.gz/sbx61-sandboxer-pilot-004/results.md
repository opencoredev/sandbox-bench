# Sandbox provider benchmark sbx61-sandboxer-pilot-004

Schema v2 · 2026-10-23T18:34:21.351Z · seed 45 · track default
Allocation sandboxer: requested null; template default
Collection: 2026-10-23T18:34:21.351Z through 2026-10-23T18:35:17.523Z
Host: AMD Ryzen 9 9955HX 16-Core Processor; linux; v26.3.0
Metadata: {"repositoryCommit":"867f594c8ba29d70e8da0cb9f0f71211ff5396f8","harnessCommit":"867f594c8ba29d70e8da0cb9f0f71211ff5396f8","sdkCommit":"9d94d345681b95fc558a780e34534e79263979f4","dirty":true,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"clientLocation":{"ip":"redacted","city":"Boca Raton","region":"Florida","country":"US","org":"AS7018 AT&T Enterprises, LLC"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: eu-central

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|cold|ms|1|0|0|0|17073 [17073, 17073]|17073|17073|17073 [17073, 17073]|17073|17073|0.0000|100.0% [0.20655, 1.0000]|0.00018000 USD|
|sandboxer|fingerprint|ms|1|0|0|0|1866.6 [1866.6, 1866.6]|1866.6|1866.6|1866.6 [1866.6, 1866.6]|1866.6|1866.6|0.0000|100.0% [0.20655, 1.0000]|0.000020000 USD|
|sandboxer|pause-resume|ms|1|0|0|0|29927 [29927, 29927]|29927|29927|29927 [29927, 29927]|29927|29927|0.0000|100.0% [0.20655, 1.0000]|0.00030000 USD|
|sandboxer|snapshot-setup|ms|1|0|0|0|34.636 [34.636, 34.636]|34.636|34.636|34.636 [34.636, 34.636]|34.636|34.636|0.0000|100.0% [0.20655, 1.0000]|0.000010000 USD|
|sandboxer|snapshot|ms|1|0|0|0|631.76 [631.76, 631.76]|631.76|631.76|631.76 [631.76, 631.76]|631.76|631.76|0.0000|100.0% [0.20655, 1.0000]|0.000010000 USD|
|sandboxer|snapshot-total|ms|1|0|0|0|727.42 [727.42, 727.42]|727.42|727.42|727.42 [727.42, 727.42]|727.42|727.42|0.0000|100.0% [0.20655, 1.0000]|0.000010000 USD|
|sandboxer|create-from-snapshot|ms|1|0|0|0|2866.7 [2866.7, 2866.7]|2866.7|2866.7|2866.7 [2866.7, 2866.7]|2866.7|2866.7|0.0000|100.0% [0.20655, 1.0000]|0.000030000 USD|
|sandboxer|restore-fingerprint|ms|1|0|0|0|1666.4 [1666.4, 1666.4]|1666.4|1666.4|1666.4 [1666.4, 1666.4]|1666.4|1666.4|0.0000|100.0% [0.20655, 1.0000]|0.000020000 USD|
|sandboxer|restore-destroy|ms|1|0|0|0|351.49 [351.49, 351.49]|351.49|351.49|351.49 [351.49, 351.49]|351.49|351.49|0.0000|100.0% [0.20655, 1.0000]|0.000010000 USD|
|sandboxer|snapshot-cleanup|ms|1|0|0|0|83.303 [83.303, 83.303]|83.303|83.303|83.303 [83.303, 83.303]|83.303|83.303|0.0000|100.0% [0.20655, 1.0000]|0.000010000 USD|
|sandboxer|destroy|ms|1|0|0|0|627.88 [627.88, 627.88]|627.88|627.88|627.88 [627.88, 627.88]|627.88|627.88|0.0000|100.0% [0.20655, 1.0000]|0.000010000 USD|
|sandboxer|sandbox-lifetime|ms|1|0|0|0|55805 [55805, 55805]|55805|55805|55805 [55805, 55805]|55805|55805|0.0000|100.0% [0.20655, 1.0000]|0.00062000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|sandboxer|13th Gen Intel(R) Core(TM) i5-13500|4|unlimited|7.7537|55.771|Linux humble-frosty-bamboo 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.62.184.254","hostname":"static.254.184.62.46.clients.your-server.de","city":"Helsinki","region":"Uusimaa","country":"FI","loc":"60.1695,24.9354","org":"AS24940 Hetzner Online GmbH","postal":"00100","timezone":"Europe/Helsinki","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|0.00062000|0.62000|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|unknown|unknown|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|0/12|0.30821|0.66031|3.4050e+5|4.3488e+5|

Flagged samples:

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 2 sandbox attempts, estimated budget USD 0.00062000; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. Starts are admitted against live minute/hour/day limits before scenario deadlines; quota-waits.ndjson records admission wait separately from measured phases. The comp account supports 25 active sandboxes.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
