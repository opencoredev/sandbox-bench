# Sandbox provider benchmark sbx61-same-spec-sandboxer-r4-main

Schema v2 · 2026-10-28T19:44:37.246Z · seed 45 · track same-spec
Allocation sandboxer: requested null; template default
Collection: 2026-10-28T19:44:37.246Z through 2026-10-28T19:54:46.933Z
Host: AMD Ryzen 9 9955HX 16-Core Processor; linux; v26.3.0
Metadata: {"repositoryCommit":"ee79701b47e2757f891510ebd05c096f78f1695b","harnessCommit":"ee79701b47e2757f891510ebd05c096f78f1695b","sdkCommit":"965130b65b472f4383d1112947ff45bbcb264b95","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"clientLocation":{"ip":"redacted","city":"Boca Raton","region":"Florida","country":"US","org":"AS7018 AT&T Enterprises, LLC"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region sandboxer: us-east

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|sandboxer|cold|ms|30|0|0|0|338.83 [328.80, 348.00]|362.17|383.68|338.48 [332.25, 344.79]|307.15|383.68|17.335|100.0% [0.88649, 1.0000]|0.00030000 USD|
|sandboxer|fingerprint|ms|30|0|0|0|1468.6 [1302.2, 1471.5]|1480.8|1488.3|1408.6 [1375.4, 1441.0]|1268.4|1488.3|92.216|100.0% [0.88649, 1.0000]|0.00060000 USD|
|sandboxer|perf|ms|30|0|0|0|871.19 [870.87, 872.49]|875.30|1072.2|878.15 [870.90, 891.78]|866.57|1072.2|36.077|100.0% [0.88649, 1.0000]|0.00031000 USD|
|sandboxer|cpu-single|iterations/s|30|0|0|0|1.3978e+7 [1.3841e+7, 1.4092e+7]|1.4217e+7|1.4300e+7|1.3828e+7 [1.3573e+7, 1.4014e+7]|1.0950e+7|1.4300e+7|6.2600e+5|100.0% [0.88649, 1.0000]|0.00031000 USD|
|sandboxer|cpu-all|iterations/s|30|0|0|0|3.1882e+7 [2.9925e+7, 3.4908e+7]|3.6174e+7|3.6279e+7|3.2335e+7 [3.1251e+7, 3.3386e+7]|2.7019e+7|3.6279e+7|2.9723e+6|100.0% [0.88649, 1.0000]|0.00031000 USD|
|sandboxer|memory-mbps|MB/s|30|0|0|0|37440 [35312, 38086]|39178|39400|36338 [34647, 37500]|16607|39400|4049.6|100.0% [0.88649, 1.0000]|0.00031000 USD|
|sandboxer|disk-write-mbps|MB/s|30|0|0|0|1633.0 [1617.0, 1641.7]|2049.0|2106.3|1661.8 [1621.7, 1711.3]|1457.1|2106.3|126.14|100.0% [0.88649, 1.0000]|0.00031000 USD|
|sandboxer|disk-read-mbps|MB/s|30|0|0|0|20901 [20072, 21388]|22919|23170|18549 [16612, 20308]|8895.2|23170|4990.5|100.0% [0.88649, 1.0000]|0.00031000 USD|
|sandboxer|disk-4k-write-iops|IOPS|30|0|0|0|678.43 [673.06, 700.19]|768.89|777.60|691.51 [679.13, 704.56]|605.51|777.60|35.856|100.0% [0.88649, 1.0000]|0.00031000 USD|
|sandboxer|disk-4k-read-iops|IOPS|30|0|0|0|2.3706e+5 [2.3625e+5, 2.3743e+5]|2.6422e+5|2.6828e+5|2.3989e+5 [2.3664e+5, 2.4369e+5]|2.2498e+5|2.6828e+5|10021|100.0% [0.88649, 1.0000]|0.00031000 USD|
|sandboxer|tcp-ms|ms|30|0|0|0|1.3773 [1.3428, 1.4160]|1.5549|1.5679|1.3851 [1.3570, 1.4129]|1.2505|1.5679|0.078871|100.0% [0.88649, 1.0000]|0.00031000 USD|
|sandboxer|command|ms|30|0|0|0|70.654 [68.886, 71.824]|80.496|81.672|70.756 [69.372, 72.103]|63.521|81.672|3.8555|100.0% [0.88649, 1.0000]|0.00030000 USD|
|sandboxer|npm-install-prepare|ms|15|0|0|0|1294.8 [1276.3, 1331.5]|1389.8|1389.8|1300.9 [1280.8, 1322.1]|1232.2|1389.8|40.011|100.0% [0.79612, 1.0000]|0.00030000 USD|
|sandboxer|npm-install|ms|15|0|0|0|1072.4 [1067.7, 1271.4]|1875.0|1875.0|1192.2 [1070.1, 1339.2]|870.58|1875.0|261.49|100.0% [0.79612, 1.0000]|0.00028000 USD|
|sandboxer|preview-provisioning|ms|15|0|0|0|133.59 [132.53, 134.43]|137.87|137.87|133.94 [133.06, 134.88]|131.43|137.87|1.7942|100.0% [0.79612, 1.0000]|0.00015000 USD|
|sandboxer|dev-server|ms|15|0|0|0|1137.0 [1119.7, 1155.6]|1229.1|1229.1|1142.7 [1123.6, 1161.6]|1068.2|1229.1|37.436|100.0% [0.79612, 1.0000]|0.00030000 USD|
|sandboxer|preview-first-byte|ms|15|0|0|0|373.40 [362.97, 387.26]|1115.7|1115.7|444.17 [373.15, 552.15]|357.25|1115.7|188.63|100.0% [0.79612, 1.0000]|0.00016000 USD|
|sandboxer|edit-loop|ms|15|0|0|0|660.84 [655.59, 664.69]|678.84|678.84|655.44 [647.59, 662.89]|626.07|678.84|15.227|100.0% [0.79612, 1.0000]|0.00015000 USD|
|sandboxer|pause-resume|ms|30|0|0|0|796.19 [793.46, 798.37]|806.23|808.60|797.17 [795.72, 798.76]|791.85|808.60|4.2340|100.0% [0.88649, 1.0000]|0.00030000 USD|
|sandboxer|tool-replay|ms|15|0|0|0|16585 [16392, 16708]|17192|17192|16601 [16468, 16742]|16194|17192|270.92|100.0% [0.79612, 1.0000]|0.0025600 USD|
|sandboxer|files-1kb|ms|30|0|0|0|293.44 [285.09, 303.32]|387.56|391.13|312.21 [296.85, 329.77]|258.86|391.13|43.212|100.0% [0.88649, 1.0000]|0.00030000 USD|
|sandboxer|git-clone|ms|15|0|0|0|1070.8 [871.11, 1471.1]|3070.8|3070.8|1284.6 [1004.7, 1616.9]|470.41|3070.8|612.96|100.0% [0.79612, 1.0000]|0.00029000 USD|
|sandboxer|pip-install|ms|15|0|0|0|4071.5 [3873.2, 4678.5]|5078.2|5078.2|4285.3 [4071.1, 4526.0]|3869.5|5078.2|442.01|100.0% [0.79612, 1.0000]|0.00072000 USD|
|sandboxer|reconnect|ms|30|0|0|0|192.38 [190.59, 248.45]|305.60|306.35|221.73 [207.03, 236.92]|179.66|306.35|40.927|100.0% [0.88649, 1.0000]|0.00030000 USD|
|sandboxer|files-10mb|ms|30|0|0|0|1727.6 [1713.2, 1772.1]|2758.4|2941.3|1865.4 [1762.3, 1989.2]|1636.7|2941.3|327.63|100.0% [0.88649, 1.0000]|0.00064000 USD|
|sandboxer|destroy|ms|30|0|0|0|344.58 [343.86, 345.65]|354.57|355.34|346.03 [344.97, 347.23]|342.44|355.34|3.2204|100.0% [0.88649, 1.0000]|0.00030000 USD|
|sandboxer|reconnect-cleanup|ms|30|0|0|0|0.62024 [0.59410, 0.66893]|0.84183|1.0913|0.65206 [0.61548, 0.69515]|0.49950|1.0913|0.10799|100.0% [0.88649, 1.0000]|0.00030000 USD|
|sandboxer|sandbox-lifetime|ms|30|0|0|0|6324.2 [6283.4, 33012]|35953|36454|20158 [15296, 25073]|6059.0|36454|13955|100.0% [0.88649, 1.0000]|0.0062300 USD|
|sandboxer|tool-replay-prepare|ms|6|0|0|0|1276.2 [1252.0, 1282.8]|1669.6|1669.6|1336.3 [1262.7, 1471.3]|1252.0|1669.6|149.42|100.0% [0.60967, 1.0000]|0.00012000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux lavish-frosty-comet 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux regal-nimble-turtle 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux cheery-sturdy-hare 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux cheery-fleet-bugle 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux amber-clean-tundra 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux slick-alert-timber 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux formal-gleaming-clam 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux nimble-prompt-quarry 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux epic-focal-rowan 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux happy-busy-squid 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux misty-sure-easel 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux lively-serene-falcon 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux basic-stellar-dove 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux pearly-light-onyx 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux hasty-ready-cello 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux magic-first-beacon 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux patient-easy-banjo 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux ideal-slick-eagle 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux witty-clean-alder 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux polar-pearly-marble 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux still-frugal-hickory 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux direct-slick-cape 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux funny-firm-bamboo 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux frugal-direct-linden 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux fancy-elated-hare 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux light-fuzzy-papaya 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux elated-fluent-wren 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux placid-free-juniper 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux light-peachy-walrus 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|
|sandboxer|AMD EPYC 9254 24-Core Processor|4|unlimited|7.7537|55.771|Linux happy-proud-bluff 6.18.56-sandboxer #2 SMP PREEMPT_DYNAMIC Tue Oct 13 02:50:06 CEST 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"177.54.159.107","city":"Ashburn","region":"Virginia","country":"US","loc":"39.0437,-77.4875","org":"AS396356 Latitude.sh","postal":"20147","timezone":"America/New_York","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|sandboxer|USD|0.0062300|0.20767|https://sandboxer.com/docs/billing.md; https://sandboxer.com/docs/machines.md (2026-10-23)|Per-second metering; $1 = 100,000 default-seconds. Small 0.5x, default 1x, large 2x, xlarge 50/9x. Plan payments and credits excluded; stopped VMs incur no machine time.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|sandboxer|USD|unknown|0.0093000|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|sandboxer|0/711|0.018426|0.033438|3.4600e+5|4.4225e+5|

Flagged samples:

## Run notes

- sandboxer: Provider default image and allocation
- sandboxer: 30 sandbox attempts, estimated budget USD 0.0062300; budget not hit.
- Cleanup sandboxer: 0 remaining; label listing verified.

## Methodology

- Sandboxer snapshots journal a run-owned name before submission. Starts are admitted against live minute/hour/day limits before scenario deadlines; quota-waits.ndjson records admission wait separately from measured phases. The comp account supports 25 active sandboxes.
- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
