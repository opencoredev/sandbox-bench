# Regional comparison

Runs: eu 18, us-east 18

p50 (p95 for durations, p5 for throughput) and samples per runner region. Best is by the metric's direction; spread is worst p50 / best p50. Samples flagged for high runner load are counted, not dropped.

## Track default

| Scenario | Provider | eu | us-east | Best | Spread |
|---|---|---:|---:|---|---:|
| cold | boat | 780 ms (1.53 s) n=20 | 1.15 s (1.73 s) n=20 | eu | 1.47× |
| cold | boxd | 1.62 s (1.70 s) n=20 | 1.02 s (1.90 s) n=20 ⚠4 | us-east | 1.58× |
| cold | daytona | 1.46 s (5.72 s) n=20 | 986 ms (1.58 s) n=20 | us-east | 1.48× |
| cold | e2b | 667 ms (1.09 s) n=20 | 479 ms (847 ms) n=20 | us-east | 1.39× |
| cold | freestyle | 1.07 s (1.53 s) n=20 | 815 ms (1.44 s) n=20 ⚠2 | us-east | 1.31× |
| cold | sandboxer | 3.85 s (4.85 s) n=20 | 3.49 s (7.26 s) n=20 | us-east | 1.10× |
| cold | superserve | 712 ms (1.01 s) n=20 | 486 ms (783 ms) n=20 | us-east | 1.47× |
| cold | tenki | 1.10 s (2.01 s) n=20 | 913 ms (1.52 s) n=20 | us-east | 1.20× |
| cold | upstash | 3.02 s (16.25 s) n=20 | 2.46 s (2.93 s) n=20 | us-east | 1.23× |
| command | boat | 114 ms (185 ms) n=20 | 333 ms (361 ms) n=20 | eu | 2.92× |
| command | boxd | 171 ms (174 ms) n=19 | 287 ms (291 ms) n=20 ⚠2 | eu | 1.68× |
| command | daytona | 168 ms (342 ms) n=20 | 105 ms (279 ms) n=20 | us-east | 1.60× |
| command | e2b | 176 ms (195 ms) n=20 | 117 ms (128 ms) n=20 | us-east | 1.50× |
| command | freestyle | 245 ms (270 ms) n=20 | 157 ms (206 ms) n=20 | us-east | 1.56× |
| command | sandboxer | 391 ms (420 ms) n=20 | 263 ms (284 ms) n=19 | us-east | 1.49× |
| command | superserve | 241 ms (292 ms) n=20 | 153 ms (182 ms) n=20 | us-east | 1.58× |
| command | tenki | 240 ms (260 ms) n=20 | 166 ms (196 ms) n=19 | us-east | 1.45× |
| command | upstash | 537 ms (625 ms) n=20 | 218 ms (238 ms) n=20 | us-east | 2.47× |
| files-1kb | boat | 428 ms (816 ms) n=20 | 818 ms (941 ms) n=20 | eu | 1.91× |
| files-1kb | boxd | 238 ms (244 ms) n=20 | 465 ms (477 ms) n=20 ⚠2 | eu | 1.96× |
| files-1kb | daytona | 245 ms (579 ms) n=20 | 117 ms (453 ms) n=20 ⚠1 | us-east | 2.09× |
| files-1kb | e2b | 328 ms (351 ms) n=20 | 200 ms (280 ms) n=20 | us-east | 1.63× |
| files-1kb | freestyle | 367 ms (476 ms) n=20 | 193 ms (229 ms) n=20 ⚠1 | us-east | 1.90× |
| files-1kb | sandboxer | 967 ms (1.18 s) n=20 | 634 ms (979 ms) n=20 | us-east | 1.52× |
| files-1kb | superserve | 217 ms (239 ms) n=20 | 79 ms (90 ms) n=20 | us-east | 2.74× |
| files-1kb | tenki | 329 ms (444 ms) n=20 | 192 ms (295 ms) n=19 | us-east | 1.72× |
| files-1kb | upstash | 449 ms (466 ms) n=20 | 314 ms (328 ms) n=20 ⚠1 | us-east | 1.43× |
| files-10mb | boat | 3.45 s (11.23 s) n=20 | 7.03 s (25.83 s) n=19 ✗1 | eu | 2.04× |
| files-10mb | boxd | 738 ms (880 ms) n=19 | 2.85 s (3.18 s) n=19 ✗1 ⚠4 | eu | 3.86× |
| files-10mb | daytona | 1.97 s (2.35 s) n=20 | 1.79 s (2.69 s) n=20 | us-east | 1.10× |
| files-10mb | e2b | 2.73 s (3.02 s) n=20 | 1.28 s (1.42 s) n=20 | us-east | 2.13× |
| files-10mb | freestyle | 4.92 s (8.82 s) n=20 | 2.11 s (3.93 s) n=20 ⚠2 | us-east | 2.34× |
| files-10mb | sandboxer | 7.45 s (11.59 s) n=20 | 5.88 s (10.55 s) n=17 | us-east | 1.27× |
| files-10mb | superserve | 2.21 s (2.92 s) n=20 | 610 ms (848 ms) n=20 | us-east | 3.62× |
| files-10mb | tenki | 3.02 s (12.35 s) n=20 | 2.04 s (6.53 s) n=19 | us-east | 1.48× |
| files-10mb | upstash | 4.00 s (16.44 s) n=20 | 2.11 s (6.96 s) n=20 | us-east | 1.90× |
| tool-replay | boat | 23.34 s (25.88 s) n=5 ✗1 | 42.71 s (43.17 s) n=6 | eu | 1.83× |
| tool-replay | boxd | 17.38 s (17.53 s) n=6 | 30.67 s (30.89 s) n=6 | eu | 1.76× |
| tool-replay | daytona | 21.41 s (35.74 s) n=6 | 16.57 s (27.28 s) n=6 | us-east | 1.29× |
| tool-replay | e2b | 21.46 s (22.06 s) n=6 | 13.64 s (14.06 s) n=6 | us-east | 1.57× |
| tool-replay | freestyle | 33.29 s (34.84 s) n=6 | 19.22 s (19.71 s) n=6 | us-east | 1.73× |
| tool-replay | sandboxer | 47.28 s (50.12 s) n=6 | 36.05 s (53.43 s) n=6 | us-east | 1.31× |
| tool-replay | superserve | 23.24 s (23.51 s) n=6 | 11.37 s (11.51 s) n=6 | us-east | 2.04× |
| tool-replay | tenki | 23.10 s (28.14 s) n=6 | 14.63 s (19.63 s) n=6 | us-east | 1.58× |
| tool-replay | upstash | 36.98 s (37.50 s) n=6 | 21.08 s (21.86 s) n=6 | us-east | 1.75× |
| reconnect | boat | 252 ms (439 ms) n=20 | 701 ms (977 ms) n=20 | eu | 2.78× |
| reconnect | boxd | 415 ms (428 ms) n=20 | 877 ms (898 ms) n=20 ⚠3 | eu | 2.11× |
| reconnect | daytona | 566 ms (776 ms) n=20 | 242 ms (577 ms) n=20 ⚠1 | us-east | 2.34× |
| reconnect | e2b | 657 ms (1.12 s) n=20 | 408 ms (452 ms) n=20 | us-east | 1.61× |
| reconnect | freestyle | 799 ms (1.04 s) n=20 | 466 ms (617 ms) n=20 ⚠1 | us-east | 1.71× |
| reconnect | sandboxer | 822 ms (1.43 s) n=20 | 485 ms (1.01 s) n=19 | us-east | 1.70× |
| reconnect | superserve | 497 ms (737 ms) n=20 | 280 ms (339 ms) n=20 | us-east | 1.78× |
| reconnect | tenki | 967 ms (997 ms) n=20 | 654 ms (712 ms) n=19 | us-east | 1.48× |
| reconnect | upstash | 926 ms (1.19 s) n=20 | 410 ms (499 ms) n=20 | us-east | 2.26× |
| preview-first-byte | boat | 131 ms (202 ms) n=6 | 989 ms (1.23 s) n=6 | eu | 7.57× |
| preview-first-byte | boxd | 70 ms (82 ms) n=6 | 858 ms (960 ms) n=6 | eu | 12.27× |
| preview-first-byte | daytona | 429 ms (655 ms) n=6 | 205 ms (352 ms) n=6 | us-east | 2.10× |
| preview-first-byte | e2b | 290 ms (738 ms) n=6 | 219 ms (248 ms) n=6 | us-east | 1.32× |
| preview-first-byte | freestyle | 774 ms (1.15 s) n=6 | 456 ms (504 ms) n=6 | us-east | 1.70× |
| preview-first-byte | sandboxer | 640 ms (741 ms) n=6 | 352 ms (397 ms) n=6 | us-east | 1.82× |
| preview-first-byte | superserve | 167 ms (369 ms) n=6 | 158 ms (216 ms) n=6 | us-east | 1.06× |
| preview-first-byte | tenki | 582 ms (596 ms) n=6 | 383 ms (458 ms) n=6 | us-east | 1.52× |
| preview-first-byte | upstash | 530 ms (579 ms) n=6 | 224 ms (267 ms) n=6 | us-east | 2.36× |
| tcp-ms | boat | 6.3 ms (211 ms) n=20 | 6.4 ms (12 ms) n=20 | eu | 1.02× |
| tcp-ms | boxd | 1.7 ms (2.1 ms) n=20 | 1.6 ms (2.0 ms) n=20 ⚠4 | us-east | 1.05× |
| tcp-ms | daytona | 0.4 ms (0.5 ms) n=20 | 0.4 ms (0.5 ms) n=20 | us-east | 1.03× |
| tcp-ms | e2b | 0.6 ms (0.8 ms) n=20 | 0.6 ms (0.8 ms) n=20 | us-east | 1.02× |
| tcp-ms | freestyle | 10 ms (36 ms) n=20 | 6.5 ms (18 ms) n=20 | us-east | 1.58× |
| tcp-ms | sandboxer | 2.5 ms (6.4 ms) n=20 | 1.9 ms (3.6 ms) n=19 | us-east | 1.31× |
| tcp-ms | superserve | 0.4 ms (0.7 ms) n=20 | 0.5 ms (0.7 ms) n=20 | eu | 1.01× |
| tcp-ms | tenki | 1.9 ms (2.8 ms) n=20 | 2.1 ms (3.0 ms) n=19 | eu | 1.11× |
| tcp-ms | upstash | 0.4 ms (0.6 ms) n=20 | 0.4 ms (0.6 ms) n=20 | us-east | 1.03× |
| destroy | boat | 73 ms (150 ms) n=20 | 176 ms (331 ms) n=20 | eu | 2.40× |
| destroy | boxd | 27 ms (32 ms) n=20 | 139 ms (155 ms) n=20 ⚠4 | eu | 5.13× |
| destroy | daytona | 970 ms (5.48 s) n=20 | 789 ms (3.20 s) n=20 | us-east | 1.23× |
| destroy | e2b | 170 ms (202 ms) n=20 | 114 ms (119 ms) n=20 | us-east | 1.49× |
| destroy | freestyle | 461 ms (1.09 s) n=20 | 376 ms (505 ms) n=20 ⚠1 | us-east | 1.23× |
| destroy | sandboxer | 885 ms (2.28 s) n=20 | 627 ms (2.04 s) n=20 | us-east | 1.41× |
| destroy | superserve | 265 ms (407 ms) n=20 | 207 ms (338 ms) n=20 | us-east | 1.28× |
| destroy | tenki | 191 ms (239 ms) n=20 | 142 ms (165 ms) n=20 | us-east | 1.35× |
| destroy | upstash | 904 ms (4.44 s) n=20 | 586 ms (1.15 s) n=20 | us-east | 1.54× |
| cpu-all | boat | 5.358e+7 iterations/s (3.371e+7 iterations/s) n=20 | 4.930e+7 iterations/s (3.808e+7 iterations/s) n=20 | eu | 1.09× |
| cpu-all | boxd | 1.584e+7 iterations/s (1.483e+7 iterations/s) n=20 | 1.570e+7 iterations/s (1.466e+7 iterations/s) n=20 ⚠4 | eu | 1.01× |
| cpu-all | daytona | 7.175e+6 iterations/s (6.592e+6 iterations/s) n=20 | 7.123e+6 iterations/s (6.379e+6 iterations/s) n=20 | eu | 1.01× |
| cpu-all | e2b | 1.442e+7 iterations/s (8.582e+6 iterations/s) n=20 | 1.354e+7 iterations/s (1.038e+7 iterations/s) n=20 | eu | 1.07× |
| cpu-all | freestyle | 2.862e+7 iterations/s (2.546e+7 iterations/s) n=20 | 2.858e+7 iterations/s (2.512e+7 iterations/s) n=20 | eu | 1.00× |
| cpu-all | sandboxer | 2.911e+7 iterations/s (9.469e+6 iterations/s) n=20 | 5.334e+7 iterations/s (1.651e+7 iterations/s) n=19 | us-east | 1.83× |
| cpu-all | superserve | 1.218e+7 iterations/s (1.139e+7 iterations/s) n=20 | 1.234e+7 iterations/s (1.121e+7 iterations/s) n=20 | us-east | 1.01× |
| cpu-all | tenki | 1.738e+7 iterations/s (1.362e+7 iterations/s) n=20 | 1.789e+7 iterations/s (1.394e+7 iterations/s) n=19 | us-east | 1.03× |
| cpu-all | upstash | 2.503e+7 iterations/s (2.400e+7 iterations/s) n=20 | 2.552e+7 iterations/s (2.383e+7 iterations/s) n=20 | us-east | 1.02× |
| cpu-single | boat | 1.900e+7 iterations/s (1.578e+7 iterations/s) n=20 | 1.827e+7 iterations/s (1.567e+7 iterations/s) n=20 | eu | 1.04× |
| cpu-single | boxd | 1.258e+7 iterations/s (1.157e+7 iterations/s) n=20 | 1.251e+7 iterations/s (8.771e+6 iterations/s) n=20 ⚠4 | eu | 1.01× |
| cpu-single | daytona | 9.096e+6 iterations/s (7.733e+6 iterations/s) n=20 | 9.111e+6 iterations/s (8.481e+6 iterations/s) n=20 | us-east | 1.00× |
| cpu-single | e2b | 1.024e+7 iterations/s (7.907e+6 iterations/s) n=20 | 9.629e+6 iterations/s (8.665e+6 iterations/s) n=20 | eu | 1.06× |
| cpu-single | freestyle | 1.007e+7 iterations/s (9.435e+6 iterations/s) n=20 | 9.869e+6 iterations/s (8.537e+6 iterations/s) n=20 | eu | 1.02× |
| cpu-single | sandboxer | 1.449e+7 iterations/s (9.085e+6 iterations/s) n=20 | 1.873e+7 iterations/s (7.670e+6 iterations/s) n=19 | us-east | 1.29× |
| cpu-single | superserve | 1.847e+7 iterations/s (1.771e+7 iterations/s) n=20 | 1.859e+7 iterations/s (1.826e+7 iterations/s) n=20 | us-east | 1.01× |
| cpu-single | tenki | 1.131e+7 iterations/s (1.001e+7 iterations/s) n=20 | 1.128e+7 iterations/s (1.015e+7 iterations/s) n=19 | eu | 1.00× |
| cpu-single | upstash | 1.372e+7 iterations/s (1.364e+7 iterations/s) n=20 | 1.374e+7 iterations/s (1.364e+7 iterations/s) n=20 | us-east | 1.00× |
| dev-server | boat | 1.58 s (2.41 s) n=6 | 4.06 s (4.44 s) n=6 | eu | 2.57× |
| dev-server | boxd | 1.97 s (2.04 s) n=6 | 3.71 s (3.77 s) n=6 | eu | 1.88× |
| dev-server | daytona | 4.68 s (7.40 s) n=6 | 3.01 s (5.50 s) n=6 | us-east | 1.56× |
| dev-server | e2b | 2.92 s (4.59 s) n=6 | 2.15 s (2.51 s) n=6 | us-east | 1.36× |
| dev-server | freestyle | 3.24 s (3.52 s) n=6 | 1.93 s (2.06 s) n=6 | us-east | 1.68× |
| dev-server | sandboxer | 4.57 s (4.83 s) n=6 | 3.14 s (3.35 s) n=6 | us-east | 1.45× |
| dev-server | superserve | 2.41 s (2.83 s) n=6 | 1.56 s (1.62 s) n=6 | us-east | 1.55× |
| dev-server | tenki | 2.90 s (2.96 s) n=6 | 1.77 s (1.85 s) n=6 | us-east | 1.64× |
| dev-server | upstash | 5.09 s (6.37 s) n=6 | 3.05 s (3.72 s) n=6 | us-east | 1.67× |
| disk-4k-read-iops | boat | 7.664e+5 IOPS (3.183e+5 IOPS) n=20 | 5.886e+5 IOPS (3.974e+5 IOPS) n=20 | eu | 1.30× |
| disk-4k-read-iops | boxd | 4.199e+5 IOPS (1.966e+5 IOPS) n=20 | 4.250e+5 IOPS (1.807e+5 IOPS) n=20 ⚠4 | us-east | 1.01× |
| disk-4k-read-iops | daytona | 3.653e+5 IOPS (2.716e+5 IOPS) n=20 | 3.652e+5 IOPS (2.993e+5 IOPS) n=20 | eu | 1.00× |
| disk-4k-read-iops | e2b | 4.560e+5 IOPS (2.951e+5 IOPS) n=20 | 4.413e+5 IOPS (3.742e+5 IOPS) n=20 | eu | 1.03× |
| disk-4k-read-iops | freestyle | 3.032e+5 IOPS (2.194e+5 IOPS) n=20 | 2.931e+5 IOPS (1.611e+5 IOPS) n=20 | eu | 1.03× |
| disk-4k-read-iops | sandboxer | 2.834e+5 IOPS (1.580e+5 IOPS) n=20 | 3.866e+5 IOPS (1.829e+5 IOPS) n=19 | us-east | 1.36× |
| disk-4k-read-iops | superserve | 7.162e+5 IOPS (6.341e+5 IOPS) n=20 | 6.784e+5 IOPS (6.199e+5 IOPS) n=20 | eu | 1.06× |
| disk-4k-read-iops | tenki | 2.158e+5 IOPS (1.826e+5 IOPS) n=20 | 2.157e+5 IOPS (1.879e+5 IOPS) n=19 | eu | 1.00× |
| disk-4k-read-iops | upstash | 5.129e+5 IOPS (4.876e+5 IOPS) n=20 | 5.153e+5 IOPS (4.969e+5 IOPS) n=20 | us-east | 1.00× |
| disk-4k-write-iops | boat | 6160 IOPS (1809 IOPS) n=20 | 5510 IOPS (693.8 IOPS) n=20 | eu | 1.12× |
| disk-4k-write-iops | boxd | 7026 IOPS (5448 IOPS) n=20 | 7847 IOPS (6021 IOPS) n=20 ⚠4 | us-east | 1.12× |
| disk-4k-write-iops | daytona | 1.993e+4 IOPS (1.392e+4 IOPS) n=20 | 2.187e+4 IOPS (6246 IOPS) n=20 | us-east | 1.10× |
| disk-4k-write-iops | e2b | 6817 IOPS (4569 IOPS) n=20 | 7002 IOPS (5426 IOPS) n=20 | us-east | 1.03× |
| disk-4k-write-iops | freestyle | 7195 IOPS (4482 IOPS) n=20 | 6380 IOPS (250.2 IOPS) n=20 | eu | 1.13× |
| disk-4k-write-iops | sandboxer | 200.7 IOPS (22.43 IOPS) n=20 | 160.8 IOPS (21.85 IOPS) n=19 | eu | 1.25× |
| disk-4k-write-iops | superserve | 1.898e+4 IOPS (1.711e+4 IOPS) n=20 | 1.775e+4 IOPS (1.545e+4 IOPS) n=20 | eu | 1.07× |
| disk-4k-write-iops | tenki | 301.6 IOPS (259.4 IOPS) n=20 | 298.4 IOPS (247.4 IOPS) n=19 | eu | 1.01× |
| disk-4k-write-iops | upstash | 514.4 IOPS (292.5 IOPS) n=20 | 531.9 IOPS (315.5 IOPS) n=20 | us-east | 1.03× |
| disk-read-mbps | boat | 1.575e+4 MB/s (7789 MB/s) n=20 | 1.189e+4 MB/s (4224 MB/s) n=20 | eu | 1.32× |
| disk-read-mbps | boxd | 9475 MB/s (7175 MB/s) n=20 | 7968 MB/s (7503 MB/s) n=20 ⚠4 | eu | 1.19× |
| disk-read-mbps | daytona | 1.647e+4 MB/s (1.474e+4 MB/s) n=20 | 1.677e+4 MB/s (1.467e+4 MB/s) n=20 | us-east | 1.02× |
| disk-read-mbps | e2b | 6056 MB/s (4056 MB/s) n=20 | 6177 MB/s (5600 MB/s) n=20 | us-east | 1.02× |
| disk-read-mbps | freestyle | 7912 MB/s (4281 MB/s) n=20 | 7008 MB/s (1810 MB/s) n=20 | eu | 1.13× |
| disk-read-mbps | sandboxer | 5753 MB/s (2500 MB/s) n=20 | 8344 MB/s (2939 MB/s) n=19 | us-east | 1.45× |
| disk-read-mbps | superserve | 4652 MB/s (3278 MB/s) n=20 | 4356 MB/s (3261 MB/s) n=20 | eu | 1.07× |
| disk-read-mbps | tenki | 8191 MB/s (5392 MB/s) n=20 | 9695 MB/s (5665 MB/s) n=19 | us-east | 1.18× |
| disk-read-mbps | upstash | 2.178e+4 MB/s (1.994e+4 MB/s) n=20 | 2.138e+4 MB/s (1.905e+4 MB/s) n=20 | eu | 1.02× |
| disk-write-mbps | boat | 343.9 MB/s (124.4 MB/s) n=20 | 354.1 MB/s (108.2 MB/s) n=20 | us-east | 1.03× |
| disk-write-mbps | boxd | 706.7 MB/s (659.4 MB/s) n=20 | 753.3 MB/s (716.8 MB/s) n=20 ⚠4 | us-east | 1.07× |
| disk-write-mbps | daytona | 3160 MB/s (875.5 MB/s) n=20 | 2599 MB/s (512.3 MB/s) n=20 | eu | 1.22× |
| disk-write-mbps | e2b | 904.1 MB/s (324.4 MB/s) n=20 | 982.1 MB/s (401.8 MB/s) n=20 | us-east | 1.09× |
| disk-write-mbps | freestyle | 233.2 MB/s (210.7 MB/s) n=20 | 237.7 MB/s (136.2 MB/s) n=20 | us-east | 1.02× |
| disk-write-mbps | sandboxer | 568.5 MB/s (41.05 MB/s) n=20 | 530.2 MB/s (123.8 MB/s) n=19 | eu | 1.07× |
| disk-write-mbps | superserve | 153.4 MB/s (126.3 MB/s) n=20 | 152.1 MB/s (125.5 MB/s) n=20 | eu | 1.01× |
| disk-write-mbps | tenki | 316.8 MB/s (148.2 MB/s) n=20 | 326.6 MB/s (247.4 MB/s) n=19 | us-east | 1.03× |
| disk-write-mbps | upstash | 1901 MB/s (855.6 MB/s) n=20 | 2062 MB/s (1657 MB/s) n=20 | us-east | 1.08× |
| edit-loop | boat | 471 ms (619 ms) n=6 | 1.16 s (1.97 s) n=6 | eu | 2.46× |
| edit-loop | boxd | 262 ms (271 ms) n=6 | 962 ms (972 ms) n=6 | eu | 3.68× |
| edit-loop | daytona | 675 ms (984 ms) n=6 | 417 ms (671 ms) n=6 | us-east | 1.62× |
| edit-loop | e2b | 513 ms (962 ms) n=6 | 333 ms (591 ms) n=6 | us-east | 1.54× |
| edit-loop | freestyle | 526 ms (569 ms) n=6 | 259 ms (293 ms) n=6 | us-east | 2.03× |
| edit-loop | sandboxer | 1.27 s (1.32 s) n=6 | 891 ms (973 ms) n=6 | us-east | 1.42× |
| edit-loop | superserve | 841 ms (1.14 s) n=6 | 472 ms (597 ms) n=6 | us-east | 1.78× |
| edit-loop | tenki | 774 ms (789 ms) n=6 | 512 ms (634 ms) n=6 | us-east | 1.51× |
| edit-loop | upstash | 557 ms (580 ms) n=6 | 366 ms (377 ms) n=6 | us-east | 1.52× |
| fingerprint | boat | 1.66 s (1.91 s) n=20 | 1.86 s (2.27 s) n=20 | eu | 1.12× |
| fingerprint | boxd | 1.50 s (1.51 s) n=20 | 1.62 s (1.67 s) n=20 ⚠3 | eu | 1.08× |
| fingerprint | daytona | 1.33 s (1.49 s) n=20 | 1.28 s (1.48 s) n=20 | us-east | 1.04× |
| fingerprint | e2b | 1.64 s (1.73 s) n=20 | 1.56 s (1.82 s) n=20 | us-east | 1.05× |
| fingerprint | freestyle | 1.64 s (1.73 s) n=20 | 1.52 s (1.70 s) n=20 ⚠1 | us-east | 1.08× |
| fingerprint | sandboxer | 1.61 s (2.00 s) n=20 | 1.67 s (1.88 s) n=20 | eu | 1.04× |
| fingerprint | superserve | 1.51 s (1.81 s) n=20 | 1.40 s (1.47 s) n=20 | us-east | 1.08× |
| fingerprint | tenki | 1.59 s (1.73 s) n=20 | 1.52 s (1.64 s) n=20 | us-east | 1.05× |
| fingerprint | upstash | 1.67 s (1.69 s) n=20 | 1.36 s (1.38 s) n=20 | us-east | 1.23× |
| git-clone | boat | 1.89 s (1.91 s) n=6 | 2.13 s (2.42 s) n=6 | eu | 1.12× |
| git-clone | boxd | 1.27 s (1.54 s) n=6 | 1.41 s (1.68 s) n=6 | eu | 1.11× |
| git-clone | daytona | 677 ms (921 ms) n=6 | 845 ms (1.49 s) n=6 | eu | 1.25× |
| git-clone | e2b | 1.11 s (1.40 s) n=6 | 1.03 s (1.32 s) n=6 | us-east | 1.08× |
| git-clone | freestyle | 1.33 s (1.54 s) n=6 | 1.29 s (1.80 s) n=6 | us-east | 1.03× |
| git-clone | sandboxer | 1.89 s (2.15 s) n=6 | 1.96 s (2.07 s) n=6 | eu | 1.04× |
| git-clone | superserve | 1.05 s (1.61 s) n=6 | 1.28 s (1.74 s) n=6 | eu | 1.21× |
| git-clone | tenki | 1.16 s (1.50 s) n=6 | 1.04 s (1.27 s) n=6 | us-east | 1.12× |
| git-clone | upstash | 851 ms (901 ms) n=6 | 536 ms (580 ms) n=6 | us-east | 1.59× |
| memory-mbps | boat | 3.305e+4 MB/s (1.541e+4 MB/s) n=20 | 2.943e+4 MB/s (1.522e+4 MB/s) n=20 | eu | 1.12× |
| memory-mbps | boxd | 2.349e+4 MB/s (2.170e+4 MB/s) n=20 | 2.311e+4 MB/s (2.166e+4 MB/s) n=20 ⚠4 | eu | 1.02× |
| memory-mbps | daytona | 3.084e+4 MB/s (2.682e+4 MB/s) n=20 | 3.219e+4 MB/s (2.098e+4 MB/s) n=20 | us-east | 1.04× |
| memory-mbps | e2b | 1.271e+4 MB/s (6365 MB/s) n=20 | 1.212e+4 MB/s (6583 MB/s) n=20 | eu | 1.05× |
| memory-mbps | freestyle | 1.643e+4 MB/s (7843 MB/s) n=20 | 1.795e+4 MB/s (8639 MB/s) n=20 | us-east | 1.09× |
| memory-mbps | sandboxer | 1.369e+4 MB/s (1773 MB/s) n=20 | 2.842e+4 MB/s (6400 MB/s) n=19 | us-east | 2.08× |
| memory-mbps | superserve | 1.674e+4 MB/s (1.385e+4 MB/s) n=20 | 1.664e+4 MB/s (1.377e+4 MB/s) n=20 | eu | 1.01× |
| memory-mbps | tenki | 2.456e+4 MB/s (2.127e+4 MB/s) n=20 | 2.405e+4 MB/s (2.072e+4 MB/s) n=19 | eu | 1.02× |
| memory-mbps | upstash | 3.894e+4 MB/s (3.249e+4 MB/s) n=20 | 3.684e+4 MB/s (3.323e+4 MB/s) n=20 | eu | 1.06× |
| npm-install | boat | 1.12 s (1.70 s) n=6 | 865 ms (1.85 s) n=6 | us-east | 1.30× |
| npm-install | boxd | 1.24 s (1.44 s) n=6 | 1.36 s (1.54 s) n=6 | eu | 1.09× |
| npm-install | daytona | 1.11 s (1.46 s) n=6 | 1.08 s (1.22 s) n=6 | us-east | 1.03× |
| npm-install | e2b | 2.02 s (2.45 s) n=6 | 1.79 s (2.34 s) n=6 | us-east | 1.13× |
| npm-install | freestyle | 1.67 s (2.02 s) n=6 | 1.46 s (1.60 s) n=6 | us-east | 1.14× |
| npm-install | sandboxer | 1.59 s (2.39 s) n=6 | 1.36 s (2.03 s) n=6 | us-east | 1.16× |
| npm-install | superserve | 1.44 s (1.60 s) n=6 | 1.36 s (1.45 s) n=6 | us-east | 1.06× |
| npm-install | tenki | 1.25 s (1.52 s) n=6 | 1.24 s (1.44 s) n=6 | us-east | 1.01× |
| npm-install | upstash | 1.28 s (1.31 s) n=6 | 959 ms (973 ms) n=6 | us-east | 1.34× |
| npm-install-prepare | boat | 1.50 s (1.63 s) n=6 | 3.74 s (3.79 s) n=6 | eu | 2.50× |
| npm-install-prepare | boxd | 709 ms (719 ms) n=6 | 1.50 s (1.53 s) n=6 | eu | 2.12× |
| npm-install-prepare | daytona | 1.11 s (1.85 s) n=6 | 748 ms (1.37 s) n=6 | us-east | 1.48× |
| npm-install-prepare | e2b | 988 ms (1.03 s) n=6 | 601 ms (611 ms) n=6 | us-east | 1.64× |
| npm-install-prepare | freestyle | 1.30 s (1.37 s) n=6 | 660 ms (702 ms) n=6 | us-east | 1.97× |
| npm-install-prepare | sandboxer | 4.32 s (4.60 s) n=6 | 3.02 s (4.27 s) n=6 | us-east | 1.43× |
| npm-install-prepare | superserve | 642 ms (899 ms) n=6 | 251 ms (263 ms) n=6 | us-east | 2.55× |
| npm-install-prepare | tenki | 1.14 s (1.15 s) n=6 | 663 ms (689 ms) n=6 | us-east | 1.73× |
| npm-install-prepare | upstash | 2.08 s (2.14 s) n=6 | 1.55 s (1.62 s) n=6 | us-east | 1.35× |
| pause-resume | boxd | 190 ms (195 ms) n=19 ✗1 | 543 ms (553 ms) n=20 ⚠4 | eu | 2.86× |
| pause-resume | e2b | 967 ms (1.50 s) n=20 | 731 ms (1.06 s) n=20 | us-east | 1.32× |
| pause-resume | freestyle | 1.17 s (1.84 s) n=20 | 827 ms (1.58 s) n=20 ⚠1 | us-east | 1.42× |
| pause-resume | sandboxer | 12.62 s (25.38 s) n=20 | 19.73 s (26.89 s) n=17 ✗3 | eu | 1.56× |
| pause-resume | superserve | 1.11 s (1.41 s) n=20 | 873 ms (1.00 s) n=20 | us-east | 1.27× |
| pause-resume | tenki | 60.44 s (68.72 s) n=20 | 62.81 s (79.92 s) n=19 ✗1 | eu | 1.04× |
| pause-resume | upstash | 1.89 s (5.54 s) n=20 | 1.19 s (2.53 s) n=20 | us-east | 1.58× |
| perf | boat | 1.36 s (1.95 s) n=20 | 868 ms (1.88 s) n=20 | us-east | 1.57× |
| perf | boxd | 683 ms (735 ms) n=20 | 800 ms (852 ms) n=20 ⚠4 | eu | 1.17× |
| perf | daytona | 644 ms (798 ms) n=20 | 573 ms (738 ms) n=20 | us-east | 1.12× |
| perf | e2b | 775 ms (1.11 s) n=20 | 736 ms (819 ms) n=20 | us-east | 1.05× |
| perf | freestyle | 1.13 s (1.70 s) n=20 | 1.05 s (2.34 s) n=20 | us-east | 1.07× |
| perf | sandboxer | 2.49 s (13.57 s) n=20 | 2.27 s (42.72 s) n=19 | us-east | 1.10× |
| perf | superserve | 1.19 s (1.45 s) n=20 | 1.11 s (1.34 s) n=20 | us-east | 1.08× |
| perf | tenki | 1.79 s (2.22 s) n=20 | 1.74 s (1.97 s) n=19 | us-east | 1.03× |
| perf | upstash | 1.33 s (2.24 s) n=20 | 984 ms (1.31 s) n=20 | us-east | 1.35× |
| pip-install | boat | 4.00 s (5.60 s) n=6 | 4.33 s (12.56 s) n=6 | eu | 1.08× |
| pip-install | boxd | 4.16 s (4.20 s) n=6 | 4.22 s (4.31 s) n=6 | eu | 1.02× |
| pip-install | daytona | 4.58 s (94.14 s) n=6 | 4.30 s (7.92 s) n=6 | us-east | 1.06× |
| pip-install | e2b | 5.16 s (6.40 s) n=6 | 4.43 s (5.22 s) n=6 | us-east | 1.16× |
| pip-install | freestyle | 18.88 s (26.72 s) n=6 | 11.89 s (30.27 s) n=6 | us-east | 1.59× |
| pip-install | sandboxer | 5.39 s (8.69 s) n=6 | 6.27 s (6.81 s) n=6 | eu | 1.16× |
| pip-install | superserve | 6.57 s (7.03 s) n=6 | 6.32 s (6.71 s) n=6 | us-east | 1.04× |
| pip-install | tenki | 4.68 s (4.92 s) n=6 | 3.80 s (4.68 s) n=6 | us-east | 1.23× |
| pip-install | upstash | 6.79 s (6.95 s) n=6 | 6.39 s (6.74 s) n=6 | us-east | 1.06× |
| preview-provisioning | boat | 165 ms (387 ms) n=6 | 300 ms (322 ms) n=6 | eu | 1.82× |
| preview-provisioning | boxd | 21 ms (31 ms) n=6 | 375 ms (376 ms) n=6 | eu | 18.01× |
| preview-provisioning | daytona | 134 ms (200 ms) n=6 | 48 ms (158 ms) n=6 | us-east | 2.79× |
| preview-provisioning | e2b | 0.7 ms (1.8 ms) n=6 ⚠2 | 0.7 ms (1.2 ms) n=6 | eu | 1.08× |
| preview-provisioning | freestyle | 240 ms (665 ms) n=6 | 132 ms (158 ms) n=6 | us-east | 1.82× |
| preview-provisioning | sandboxer | 196 ms (198 ms) n=6 | 133 ms (182 ms) n=6 | us-east | 1.48× |
| preview-provisioning | superserve | 511 ms (691 ms) n=6 | 363 ms (626 ms) n=6 | us-east | 1.41× |
| preview-provisioning | tenki | 189 ms (255 ms) n=6 | 138 ms (150 ms) n=6 | us-east | 1.37× |
| preview-provisioning | upstash | 115 ms (120 ms) n=6 | 52 ms (58 ms) n=6 | us-east | 2.21× |
| reconnect-cleanup | boat | 0.3 ms (0.6 ms) n=20 ⚠1 | 0.6 ms (1.0 ms) n=20 ⚠2 | eu | 1.82× |
| reconnect-cleanup | boxd | 0.4 ms (1.1 ms) n=20 ⚠1 | 0.8 ms (5.7 ms) n=20 ⚠5 | eu | 1.88× |
| reconnect-cleanup | daytona | 0.4 ms (0.9 ms) n=20 ⚠1 | 0.7 ms (0.9 ms) n=20 ⚠2 | eu | 1.77× |
| reconnect-cleanup | e2b | 0.4 ms (1.2 ms) n=20 ⚠1 | 0.5 ms (0.8 ms) n=20 ⚠2 | eu | 1.51× |
| reconnect-cleanup | freestyle | 0.4 ms (0.7 ms) n=20 ⚠3 | 0.6 ms (4.5 ms) n=20 ⚠3 | eu | 1.70× |
| reconnect-cleanup | sandboxer | 0.5 ms (1.0 ms) n=20 | 0.7 ms (0.9 ms) n=19 | eu | 1.28× |
| reconnect-cleanup | superserve | 0.4 ms (1.0 ms) n=20 | 0.6 ms (1.1 ms) n=20 ⚠1 | eu | 1.68× |
| reconnect-cleanup | tenki | 0.5 ms (1.2 ms) n=20 ⚠2 | 0.6 ms (0.8 ms) n=19 ⚠1 | eu | 1.39× |
| reconnect-cleanup | upstash | 0.5 ms (0.6 ms) n=20 ⚠1 | 0.7 ms (1.1 ms) n=20 ⚠1 | eu | 1.39× |
| sandbox-lifetime | boat | 9.05 s (47.27 s) n=20 | 17.62 s (92.69 s) n=20 | eu | 1.95× |
| sandbox-lifetime | boxd | 6.23 s (34.64 s) n=20 | 12.09 s (57.43 s) n=20 ⚠3 | eu | 1.94× |
| sandbox-lifetime | daytona | 7.79 s (71.27 s) n=20 | 7.79 s (46.81 s) n=20 | eu | 1.00× |
| sandbox-lifetime | e2b | 8.70 s (48.13 s) n=20 | 6.05 s (31.96 s) n=20 | us-east | 1.44× |
| sandbox-lifetime | freestyle | 14.56 s (82.01 s) n=20 | 8.89 s (61.25 s) n=20 | us-east | 1.64× |
| sandbox-lifetime | sandboxer | 47.43 s (104.47 s) n=20 | 78.37 s (113.11 s) n=20 | eu | 1.65× |
| sandbox-lifetime | superserve | 8.76 s (46.68 s) n=20 | 5.60 s (29.47 s) n=20 | us-east | 1.56× |
| sandbox-lifetime | tenki | 76.32 s (118.57 s) n=20 | 74.75 s (114.24 s) n=20 | us-east | 1.02× |
| sandbox-lifetime | upstash | 24.40 s (83.50 s) n=20 | 12.46 s (48.98 s) n=20 | us-east | 1.96× |
| tool-replay-prepare | boat | 1.76 s (1.80 s) n=4 | 4.43 s (4.83 s) n=4 | eu | 2.52× |
| tool-replay-prepare | boxd | 716 ms (726 ms) n=4 | 1.51 s (1.54 s) n=4 | eu | 2.11× |
| tool-replay-prepare | daytona | 943 ms (1.68 s) n=4 | 878 ms (1.39 s) n=4 | us-east | 1.07× |
| tool-replay-prepare | e2b | 992 ms (1.41 s) n=4 | 596 ms (603 ms) n=4 | us-east | 1.67× |
| tool-replay-prepare | freestyle | 1.34 s (1.48 s) n=4 | 733 ms (765 ms) n=4 | us-east | 1.83× |
| tool-replay-prepare | sandboxer | 4.44 s (4.58 s) n=4 | 3.08 s (3.39 s) n=4 | us-east | 1.44× |
| tool-replay-prepare | superserve | 666 ms (688 ms) n=4 | 252 ms (311 ms) n=4 | us-east | 2.65× |
| tool-replay-prepare | tenki | 1.14 s (1.15 s) n=4 | 661 ms (663 ms) n=4 | us-east | 1.73× |
| tool-replay-prepare | upstash | 2.12 s (3.80 s) n=4 | 1.61 s (1.99 s) n=4 | us-east | 1.32× |

