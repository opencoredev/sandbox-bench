# Sandbox provider benchmark sbx65-r1-us-east-default-main-b2-boat

Schema v2 · 2026-10-26T02:51:18.760Z · seed 45 · track default
Allocation boat: requested null; template default
Collection: 2026-10-26T02:51:18.760Z through 2026-10-26T02:57:19.382Z
Host: AMD Ryzen 9 9955HX 16-Core Processor; linux; v26.3.0
Metadata: {"repositoryCommit":"cc96da3e33334e609c435ddefd76b1e4a67df03b","harnessCommit":"cc96da3e33334e609c435ddefd76b1e4a67df03b","sdkCommit":"1185278f6f347ff6812ffb3bd4d17e7fd6c35f3b","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"runnerRegion":"us-east","runner":{"region":"us-east","label":"us-east-ms-a2","transport":"local","host":null,"datacenter":{"provider":"home","location":"Boca Raton, FL (ms-a2)"},"batchId":"sbx65-r1"},"clientLocation":{"ip":"99.20.193.62","city":"Boca Raton","region":"Florida","country":"US","org":"AS7018 AT&T Enterprises, LLC"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region boat: unspecified

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|boat|cold|ms|10|0|0|0|932.92 [910.65, 1188.0]|2610.5|2610.5|1163.3 [946.77, 1504.3]|899.27|2610.5|497.01|100.0% [0.72247, 1.0000]|0.00015000 USD|
|boat|fingerprint|ms|10|0|0|0|1860.8 [1854.1, 1875.4]|2259.2|2259.2|1920.0 [1859.1, 2003.2]|1846.1|2259.2|126.72|100.0% [0.72247, 1.0000]|0.00022000 USD|
|boat|perf|ms|10|0|0|0|858.02 [848.05, 1858.5]|1902.2|1902.2|1260.7 [955.47, 1570.5]|843.79|1902.2|496.89|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|cpu-single|iterations/s|10|0|0|0|1.8199e+7 [1.6038e+7, 1.9738e+7]|2.0833e+7|2.0833e+7|1.8082e+7 [1.6513e+7, 1.9404e+7]|1.2364e+7|2.0833e+7|2.3029e+6|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|cpu-all|iterations/s|10|0|0|0|4.8216e+7 [4.1083e+7, 5.1583e+7]|5.5699e+7|5.5699e+7|4.8045e+7 [4.4741e+7, 5.1452e+7]|3.9390e+7|5.5699e+7|5.4635e+6|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|memory-mbps|MB/s|10|0|0|0|27048 [18743, 39856]|41526|41526|30993 [25670, 36328]|18340|41526|8884.7|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|disk-write-mbps|MB/s|10|0|0|0|298.74 [147.72, 395.89]|508.48|508.48|311.34 [240.65, 379.88]|138.02|508.48|112.93|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|disk-read-mbps|MB/s|10|0|0|0|8002.0 [4227.1, 13486]|17886|17886|9716.0 [6942.3, 12569]|4173.5|17886|4601.7|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|disk-4k-write-iops|IOPS|10|0|0|0|4944.3 [905.45, 8786.5]|9205.6|9205.6|5578.7 [3547.8, 7485.0]|444.49|9205.6|3267.7|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|disk-4k-read-iops|IOPS|10|0|0|0|5.4186e+5 [4.5867e+5, 7.3257e+5]|8.1380e+5|8.1380e+5|5.7932e+5 [4.9934e+5, 6.6683e+5]|3.7242e+5|8.1380e+5|1.3877e+5|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|tcp-ms|ms|10|0|0|0|6.2609 [5.5805, 8.5002]|17.264|17.264|7.8114 [6.2156, 10.121]|5.5677|17.264|3.3387|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|command|ms|10|0|0|0|333.43 [325.71, 351.06]|362.24|362.24|339.28 [331.69, 347.09]|321.35|362.24|12.756|100.0% [0.72247, 1.0000]|0.00010000 USD|
|boat|npm-install-prepare|ms|3|0|0|0|3750.6 [3635.8, 3785.2]|3785.2|3785.2|3723.9 [3635.8, 3785.2]|3635.8|3785.2|63.892|100.0% [0.43850, 1.0000]|0.00012000 USD|
|boat|npm-install|ms|3|0|0|0|883.08 [838.72, 1854.3]|1854.3|1854.3|1192.0 [838.72, 1854.3]|838.72|1854.3|468.65|100.0% [0.43850, 1.0000]|0.000040000 USD|
|boat|preview-provisioning|ms|3|0|0|0|299.70 [270.22, 328.98]|328.98|328.98|299.63 [270.22, 328.98]|270.22|328.98|23.990|100.0% [0.43850, 1.0000]|0.000030000 USD|
|boat|dev-server|ms|3|0|0|0|4051.1 [3906.7, 4073.1]|4073.1|4073.1|4010.3 [3906.7, 4073.1]|3906.7|4073.1|73.769|100.0% [0.43850, 1.0000]|0.00014000 USD|
|boat|preview-first-byte|ms|3|0|0|0|1021.5 [780.60, 1217.6]|1217.6|1217.6|1006.6 [780.60, 1217.6]|780.60|1217.6|178.73|100.0% [0.43850, 1.0000]|0.000050000 USD|
|boat|edit-loop|ms|3|0|0|0|1140.3 [1132.6, 1148.4]|1148.4|1148.4|1140.4 [1132.6, 1148.4]|1132.6|1148.4|6.4700|100.0% [0.43850, 1.0000]|0.000060000 USD|
|boat|tool-replay|ms|3|0|0|0|42636 [41882, 43267]|43267|43267|42595 [41882, 43267]|41882|43267|566.04|100.0% [0.43850, 1.0000]|0.0012900 USD|
|boat|files-1kb|ms|10|0|0|0|813.51 [782.66, 819.43]|913.79|913.79|814.20 [793.76, 840.73]|767.61|913.79|37.620|100.0% [0.72247, 1.0000]|0.00010000 USD|
|boat|git-clone|ms|3|0|0|0|2124.3 [1353.2, 2133.2]|2133.2|2133.2|1870.2 [1353.2, 2133.2]|1353.2|2133.2|365.60|100.0% [0.43850, 1.0000]|0.000080000 USD|
|boat|pip-install|ms|3|0|0|0|4217.6 [3957.0, 4434.6]|4434.6|4434.6|4203.1 [3957.0, 4434.6]|3957.0|4434.6|195.23|100.0% [0.43850, 1.0000]|0.00014000 USD|
|boat|reconnect|ms|10|0|0|0|694.08 [674.30, 722.39]|957.14|957.14|726.20 [686.98, 783.36]|666.66|957.14|81.799|100.0% [0.72247, 1.0000]|0.00010000 USD|
|boat|files-10mb|ms|10|0|0|0|6946.7 [6294.5, 7570.3]|28111|28111|9508.7 [6586.3, 13964]|5787.8|28111|6508.8|100.0% [0.72247, 1.0000]|0.0010100 USD|
|boat|destroy|ms|10|0|0|0|176.24 [172.69, 179.25]|187.53|187.53|178.10 [174.75, 181.71]|168.29|187.53|5.6285|100.0% [0.72247, 1.0000]|0.00010000 USD|
|boat|reconnect-cleanup|ms|10|0|0|0|0.62873 [0.58819, 0.85060]|1.5190|1.5190|0.76631 [0.62777, 0.95362]|0.54334|1.5190|0.27485|100.0% [0.72247, 1.0000]|0.00010000 USD|
|boat|sandbox-lifetime|ms|10|0|0|0|15136 [13466, 75186]|78617|78617|35986 [19943, 54347]|13225|78617|27894|100.0% [0.72247, 1.0000]|0.0036600 USD|
|boat|tool-replay-prepare|ms|2|0|0|0|4011.3 [4011.3, 4041.8]|4041.8|4041.8|4026.5 [4011.3, 4041.8]|4011.3|4041.8|15.241|100.0% [0.34238, 1.0000]|0.00010000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-1026f9ca5973846d 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"178.33.122.213","hostname":"ns3088220.ip-178-33-122.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-64bee2761b52d5f2 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"5.135.139.7","hostname":"ns314531.ip-5-135-139.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-69d26aadd6279b1f 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"178.33.122.193","hostname":"ns371224.ip-178-33-122.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-93a7742f01b2901b 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"217.182.195.214","hostname":"ns3039302.ip-217-182-195.eu","city":"Gravelines","region":"Hauts-de-France","country":"FR","loc":"50.9865,2.1281","org":"AS16276 OVH SAS","postal":"59820","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-82eac0ea8de31dc7 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"5.39.65.94","hostname":"ns3186439.ip-5-39-65.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-01f01538777ecc9a 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"193.70.33.162","hostname":"ns3425149.ip-193-70-33.eu","city":"Gravelines","region":"Hauts-de-France","country":"FR","loc":"50.9865,2.1281","org":"AS16276 OVH SAS","postal":"59820","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-3558457d0d75c95f 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"193.70.33.162","hostname":"ns3425149.ip-193-70-33.eu","city":"Gravelines","region":"Hauts-de-France","country":"FR","loc":"50.9865,2.1281","org":"AS16276 OVH SAS","postal":"59820","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-89ee21eae08f9026 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"5.135.136.200","hostname":"ns371253.ip-5-135-136.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-38c8e0bfadfbe1a4 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"5.39.65.121","hostname":"ns3063878.ip-5-39-65.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-b87ece805af5487d 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"5.39.65.122","hostname":"ns3049415.ip-5-39-65.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|boat|USD|0.0036600|0.36600|https://docs.boat.dev/machines (2026-10-21)|Default VM $0.036/hour (4 vCPU, 8 GB, 50 GB). Flat rate for each size; Small, Large and Xlarge are also offered. $20 monthly minimum/packs excluded; billed per second.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|boat|USD|unknown|0.018600|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|boat|1/209|0.17691|0.57063|4.2934e+6|6.1734e+5|

Flagged samples:
- boat/reconnect-cleanup iteration 5 at 2026-10-26T02:55:51.415Z: high host load

## Run notes

- boat: Provider default image and allocation
- boat: 10 sandbox attempts, estimated budget USD 0.0036600; budget not hit.
- Cleanup boat: 0 remaining; label listing verified.

## Methodology

- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
