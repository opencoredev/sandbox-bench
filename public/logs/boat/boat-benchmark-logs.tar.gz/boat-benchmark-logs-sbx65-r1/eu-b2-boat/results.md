# Sandbox provider benchmark sbx65-r1-eu-default-main-b2-boat

Schema v2 · 2026-10-26T02:40:07.349Z · seed 45 · track default
Allocation boat: requested null; template default
Collection: 2026-10-26T02:40:07.349Z through 2026-10-26T02:43:24.363Z
Host: Intel Core Processor (Haswell, no TSX); linux; v26.3.0
Metadata: {"repositoryCommit":"cc96da3e33334e609c435ddefd76b1e4a67df03b","harnessCommit":"cc96da3e33334e609c435ddefd76b1e4a67df03b","sdkCommit":"1185278f6f347ff6812ffb3bd4d17e7fd6c35f3b","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"runnerRegion":"eu","runner":{"region":"eu","label":"eu-ovh-frankfurt","transport":"ssh","host":"135.125.152.92","datacenter":{"provider":"ovh","location":"Frankfurt, DE (vps-41a131f1)","serverType":"VPS 2 vCore / 4 GB"},"batchId":"sbx65-r1"},"clientLocation":{"ip":"135.125.152.92","city":"Frankfurt am Main","region":"Hesse","country":"DE","org":"AS16276 OVH SAS"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region boat: unspecified

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|boat|cold|ms|10|0|0|0|695.00 [607.36, 1201.9]|2157.4|2157.4|977.43 [710.10, 1297.8]|597.25|2157.4|480.49|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|fingerprint|ms|10|0|0|0|1664.4 [1646.7, 1688.3]|1906.0|1906.0|1694.9 [1657.8, 1748.5]|1641.4|1906.0|76.196|100.0% [0.72247, 1.0000]|0.00020000 USD|
|boat|perf|ms|10|0|0|0|679.52 [629.69, 1651.7]|2800.9|2800.9|1214.8 [836.77, 1699.7]|618.80|2800.9|696.74|100.0% [0.72247, 1.0000]|0.00016000 USD|
|boat|cpu-single|iterations/s|10|0|0|0|1.9395e+7 [1.5790e+7, 1.9788e+7]|2.1098e+7|2.1098e+7|1.8906e+7 [1.7692e+7, 1.9914e+7]|1.5654e+7|2.1098e+7|1.7563e+6|100.0% [0.72247, 1.0000]|0.00016000 USD|
|boat|cpu-all|iterations/s|10|0|0|0|5.5686e+7 [4.3482e+7, 6.2766e+7]|7.4087e+7|7.4087e+7|5.5325e+7 [4.8819e+7, 6.1478e+7]|3.5339e+7|7.4087e+7|1.0293e+7|100.0% [0.72247, 1.0000]|0.00016000 USD|
|boat|memory-mbps|MB/s|10|0|0|0|32111 [20123, 38104]|45572|45572|32415 [27378, 36831]|19391|45572|7682.4|100.0% [0.72247, 1.0000]|0.00016000 USD|
|boat|disk-write-mbps|MB/s|10|0|0|0|347.55 [124.45, 547.20]|593.62|593.62|377.48 [268.91, 477.10]|124.28|593.62|170.29|100.0% [0.72247, 1.0000]|0.00016000 USD|
|boat|disk-read-mbps|MB/s|10|0|0|0|16362 [8497.7, 18033]|19900|19900|15031 [12204, 17423]|7687.2|19900|4100.4|100.0% [0.72247, 1.0000]|0.00016000 USD|
|boat|disk-4k-write-iops|IOPS|10|0|0|0|7325.9 [3076.5, 9554.5]|10251|10251|6753.9 [4805.9, 8422.8]|586.91|10251|2967.3|100.0% [0.72247, 1.0000]|0.00016000 USD|
|boat|disk-4k-read-iops|IOPS|10|0|0|0|7.6776e+5 [4.8085e+5, 8.8707e+5]|9.4284e+5|9.4284e+5|7.3131e+5 [5.9320e+5, 8.3917e+5]|3.1864e+5|9.4284e+5|1.9409e+5|100.0% [0.72247, 1.0000]|0.00016000 USD|
|boat|tcp-ms|ms|10|0|0|0|6.1748 [5.7055, 17.736]|221.56|221.56|49.615 [6.9572, 111.60]|5.3884|221.56|83.356|100.0% [0.72247, 1.0000]|0.00016000 USD|
|boat|command|ms|10|0|0|0|112.92 [102.57, 143.65]|829.04|829.04|193.51 [114.90, 338.85]|99.625|829.04|212.58|100.0% [0.72247, 1.0000]|0.00010000 USD|
|boat|npm-install-prepare|ms|3|0|0|0|1469.0 [1403.2, 1574.1]|1574.1|1574.1|1482.1 [1403.2, 1574.1]|1403.2|1574.1|70.370|100.0% [0.43850, 1.0000]|0.000060000 USD|
|boat|npm-install|ms|3|0|0|0|620.91 [611.86, 623.73]|623.73|623.73|618.84 [611.86, 623.73]|611.86|623.73|5.0651|100.0% [0.43850, 1.0000]|0.000030000 USD|
|boat|preview-provisioning|ms|3|0|0|0|161.42 [156.25, 165.93]|165.93|165.93|161.20 [156.25, 165.93]|156.25|165.93|3.9554|100.0% [0.43850, 1.0000]|0.000030000 USD|
|boat|dev-server|ms|3|0|0|0|1514.7 [1508.2, 2548.8]|2548.8|2548.8|1857.2 [1508.2, 2548.8]|1508.2|2548.8|489.02|100.0% [0.43850, 1.0000]|0.000070000 USD|
|boat|preview-first-byte|ms|3|0|0|0|130.28 [127.45, 130.51]|130.51|130.51|129.41 [127.45, 130.51]|127.45|130.51|1.3903|100.0% [0.43850, 1.0000]|0.000030000 USD|
|boat|edit-loop|ms|3|0|0|0|438.58 [434.31, 554.26]|554.26|554.26|475.72 [434.31, 554.26]|434.31|554.26|55.564|100.0% [0.43850, 1.0000]|0.000030000 USD|
|boat|tool-replay|ms|3|0|0|0|21244 [19333, 25674]|25674|25674|22084 [19333, 25674]|19333|25674|2656.2|100.0% [0.43850, 1.0000]|0.00068000 USD|
|boat|files-1kb|ms|10|0|0|0|395.38 [373.00, 666.22]|860.44|860.44|510.73 [406.33, 634.10]|324.77|860.44|187.72|100.0% [0.72247, 1.0000]|0.00010000 USD|
|boat|git-clone|ms|3|0|0|0|1896.2 [1888.7, 1906.6]|1906.6|1906.6|1897.2 [1888.7, 1906.6]|1888.7|1906.6|7.3742|100.0% [0.43850, 1.0000]|0.000060000 USD|
|boat|pip-install|ms|3|0|0|0|3702.8 [3699.4, 4494.8]|4494.8|4494.8|3965.6 [3699.4, 4494.8]|3699.4|4494.8|374.14|100.0% [0.43850, 1.0000]|0.00013000 USD|
|boat|reconnect|ms|10|0|0|0|254.10 [236.22, 267.99]|351.31|351.31|267.45 [246.74, 291.17]|224.09|351.31|37.097|100.0% [0.72247, 1.0000]|0.00010000 USD|
|boat|files-10mb|ms|10|0|0|0|3345.5 [1868.1, 4518.6]|13361|13361|4374.3 [2780.5, 6626.0]|1858.2|13361|3233.2|100.0% [0.72247, 1.0000]|0.00049000 USD|
|boat|destroy|ms|10|0|0|0|79.235 [67.311, 90.205]|684.78|684.78|142.81 [75.910, 267.23]|64.832|684.78|181.28|100.0% [0.72247, 1.0000]|0.00010000 USD|
|boat|reconnect-cleanup|ms|10|0|0|0|0.31718 [0.25984, 0.47571]|0.85510|0.85510|0.40160 [0.30836, 0.51973]|0.24968|0.85510|0.17501|100.0% [0.72247, 1.0000]|0.00010000 USD|
|boat|sandbox-lifetime|ms|10|0|0|0|8066.6 [7367.3, 37987]|46742|46742|19641 [10992, 29152]|7263.9|46742|15161|100.0% [0.72247, 1.0000]|0.0020200 USD|
|boat|tool-replay-prepare|ms|2|0|0|0|1479.0 [1479.0, 1729.9]|1729.9|1729.9|1604.5 [1479.0, 1729.9]|1479.0|1729.9|125.46|100.0% [0.34238, 1.0000]|0.000040000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-6486a993d20cc8d7 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"37.59.33.135","hostname":"ns3172948.ip-37-59-33.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-2a4fa7bc5d19484b 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"37.59.33.135","hostname":"ns3172948.ip-37-59-33.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-3a38860289b2223d 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"37.59.33.135","hostname":"ns3172948.ip-37-59-33.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-abf8a9e830a97043 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"151.80.23.92","hostname":"ns3016933.ip-151-80-23.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-ecb6e509e5a18cc0 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"37.59.33.135","hostname":"ns3172948.ip-37-59-33.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-35a445f019963611 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"5.39.75.62","hostname":"ns3186448.ip-5-39-75.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-4fb87753fe031578 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"217.182.194.174","hostname":"ns3078849.ip-217-182-194.eu","city":"Gravelines","region":"Hauts-de-France","country":"FR","loc":"50.9865,2.1281","org":"AS16276 OVH SAS","postal":"59820","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-30bcf60e22dcced9 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"151.80.23.92","hostname":"ns3016933.ip-151-80-23.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-33e9e050314b63a4 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"5.39.65.82","hostname":"ns3185441.ip-5-39-65.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.578|Linux box-node-62a49e311a1489ea 6.8.0-117-generic #117-Ubuntu SMP PREEMPT_DYNAMIC Tue May  5 19:26:24 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"37.187.130.141","hostname":"ns326232.ip-37-187-130.eu","city":"Gravelines","region":"Hauts-de-France","country":"FR","loc":"50.9865,2.1281","org":"AS16276 OVH SAS","postal":"59820","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|boat|USD|0.0020200|0.20200|https://docs.boat.dev/machines (2026-10-21)|Default VM $0.036/hour (4 vCPU, 8 GB, 50 GB). Flat rate for each size; Small, Large and Xlarge are also offered. $20 monthly minimum/packs excluded; billed per second.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|boat|USD|unknown|0.010500|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|boat|1/209|0.027864|0.14000|2.1934e+5|2.8675e+5|

Flagged samples:
- boat/reconnect-cleanup iteration 1 at 2026-10-26T02:41:26.374Z: high host load

## Run notes

- boat: Provider default image and allocation
- boat: 10 sandbox attempts, estimated budget USD 0.0020200; budget not hit.
- Cleanup boat: 0 remaining; label listing verified.

## Methodology

- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
