# Sandbox provider benchmark sbx65-r1-eu-default-main-b1-boat

Schema v2 · 2026-10-26T02:36:23.250Z · seed 45 · track default
Allocation boat: requested null; template default
Collection: 2026-10-26T02:36:23.250Z through 2026-10-26T02:39:48.445Z
Host: Intel Core Processor (Haswell, no TSX); linux; v26.3.0
Metadata: {"repositoryCommit":"cc96da3e33334e609c435ddefd76b1e4a67df03b","harnessCommit":"cc96da3e33334e609c435ddefd76b1e4a67df03b","sdkCommit":"1185278f6f347ff6812ffb3bd4d17e7fd6c35f3b","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"runnerRegion":"eu","runner":{"region":"eu","label":"eu-ovh-frankfurt","transport":"ssh","host":"135.125.152.92","datacenter":{"provider":"ovh","location":"Frankfurt, DE (vps-41a131f1)","serverType":"VPS 2 vCore / 4 GB"},"batchId":"sbx65-r1"},"clientLocation":{"ip":"135.125.152.92","city":"Frankfurt am Main","region":"Hesse","country":"DE","org":"AS16276 OVH SAS"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region boat: unspecified

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|boat|cold|ms|10|0|0|0|785.82 [621.23, 939.75]|1280.2|1280.2|839.83 [713.04, 972.54]|607.69|1280.2|206.55|100.0% [0.72247, 1.0000]|0.00012000 USD|
|boat|fingerprint|ms|10|0|0|0|1658.9 [1640.3, 1673.5]|1979.8|1979.8|1692.3 [1650.0, 1759.9]|1630.2|1979.8|98.445|100.0% [0.72247, 1.0000]|0.00020000 USD|
|boat|perf|ms|10|0|0|0|1633.4 [627.73, 1657.7]|1905.5|1905.5|1268.6 [938.24, 1597.2]|624.66|1905.5|523.50|100.0% [0.72247, 1.0000]|0.00016000 USD|
|boat|cpu-single|iterations/s|10|0|0|0|1.7529e+7 [1.6367e+7, 1.9864e+7]|2.1499e+7|2.1499e+7|1.8266e+7 [1.7154e+7, 1.9532e+7]|1.5910e+7|2.1499e+7|1.8164e+6|100.0% [0.72247, 1.0000]|0.00016000 USD|
|boat|cpu-all|iterations/s|10|0|0|0|5.0102e+7 [3.3740e+7, 5.5251e+7]|6.3039e+7|6.3039e+7|4.9291e+7 [4.3480e+7, 5.4588e+7]|3.3088e+7|6.3039e+7|8.9205e+6|100.0% [0.72247, 1.0000]|0.00016000 USD|
|boat|memory-mbps|MB/s|10|0|0|0|25261 [15455, 36439]|38961|38961|27947 [22107, 33525]|14629|38961|9184.2|100.0% [0.72247, 1.0000]|0.00016000 USD|
|boat|disk-write-mbps|MB/s|10|0|0|0|232.04 [145.20, 525.93]|660.92|660.92|340.94 [225.52, 465.06]|137.08|660.92|188.63|100.0% [0.72247, 1.0000]|0.00016000 USD|
|boat|disk-read-mbps|MB/s|10|0|0|0|12945 [10026, 15992]|18705|18705|13247 [11271, 15398]|7794.3|18705|3288.6|100.0% [0.72247, 1.0000]|0.00016000 USD|
|boat|disk-4k-write-iops|IOPS|10|0|0|0|5663.7 [2741.9, 6538.8]|10134|10134|5535.8 [4159.7, 7024.2]|1872.9|10134|2264.2|100.0% [0.72247, 1.0000]|0.00016000 USD|
|boat|disk-4k-read-iops|IOPS|10|0|0|0|6.9000e+5 [6.3444e+5, 7.7167e+5]|8.1306e+5|8.1306e+5|6.8231e+5 [5.8585e+5, 7.5303e+5]|3.1090e+5|8.1306e+5|1.3625e+5|100.0% [0.72247, 1.0000]|0.00016000 USD|
|boat|tcp-ms|ms|10|0|0|0|6.2119 [5.8519, 6.7485]|18.143|18.143|8.0316 [6.0270, 10.621]|5.1747|18.143|3.9970|100.0% [0.72247, 1.0000]|0.00016000 USD|
|boat|command|ms|10|0|0|0|106.96 [104.73, 116.25]|135.79|135.79|113.15 [107.13, 120.06]|100.08|135.79|10.384|100.0% [0.72247, 1.0000]|0.00010000 USD|
|boat|npm-install-prepare|ms|3|0|0|0|1524.1 [1467.6, 1646.2]|1646.2|1646.2|1546.0 [1467.6, 1646.2]|1467.6|1646.2|74.540|100.0% [0.43850, 1.0000]|0.000060000 USD|
|boat|npm-install|ms|3|0|0|0|1647.1 [1625.3, 1716.9]|1716.9|1716.9|1663.1 [1625.3, 1716.9]|1625.3|1716.9|39.083|100.0% [0.43850, 1.0000]|0.000060000 USD|
|boat|preview-provisioning|ms|3|0|0|0|196.40 [163.66, 450.13]|450.13|450.13|270.06 [163.66, 450.13]|163.66|450.13|128.03|100.0% [0.43850, 1.0000]|0.000030000 USD|
|boat|dev-server|ms|3|0|0|0|1647.6 [1476.6, 1999.0]|1999.0|1999.0|1707.7 [1476.6, 1999.0]|1476.6|1999.0|217.48|100.0% [0.43850, 1.0000]|0.000060000 USD|
|boat|preview-first-byte|ms|3|0|0|0|136.05 [130.96, 223.50]|223.50|223.50|163.50 [130.96, 223.50]|130.96|223.50|42.472|100.0% [0.43850, 1.0000]|0.000030000 USD|
|boat|edit-loop|ms|3|0|0|0|502.82 [427.02, 640.23]|640.23|640.23|523.35 [427.02, 640.23]|427.02|640.23|88.248|100.0% [0.43850, 1.0000]|0.000030000 USD|
|boat|tool-replay|ms|2|1|0|0|23338 [23338, 25929]|25929|25929|24633 [23338, 25929]|23338|25929|1295.4|66.7% [0.20766, 0.93851]|0.00077000 USD|
|boat|files-1kb|ms|10|0|0|0|430.90 [345.35, 467.18]|621.53|621.53|448.46 [400.81, 499.52]|331.11|621.53|79.696|100.0% [0.72247, 1.0000]|0.00010000 USD|
|boat|git-clone|ms|3|0|0|0|1889.0 [1767.5, 1910.2]|1910.2|1910.2|1855.5 [1767.5, 1910.2]|1767.5|1910.2|62.881|100.0% [0.43850, 1.0000]|0.000060000 USD|
|boat|pip-install|ms|3|0|0|0|4065.4 [3931.9, 5975.0]|5975.0|5975.0|4657.4 [3931.9, 5975.0]|3931.9|5975.0|933.23|100.0% [0.43850, 1.0000]|0.00015000 USD|
|boat|reconnect|ms|10|0|0|0|237.87 [217.94, 298.75]|470.82|470.82|284.85 [235.63, 345.71]|216.20|470.82|87.880|100.0% [0.72247, 1.0000]|0.00010000 USD|
|boat|files-10mb|ms|10|0|0|0|3167.2 [2034.4, 4109.0]|11123|11123|3915.6 [2637.2, 5744.7]|1785.5|11123|2599.9|100.0% [0.72247, 1.0000]|0.00045000 USD|
|boat|destroy|ms|10|0|0|0|65.168 [62.676, 71.910]|86.088|86.088|67.788 [63.743, 72.851]|60.019|86.088|7.3916|100.0% [0.72247, 1.0000]|0.00010000 USD|
|boat|reconnect-cleanup|ms|10|0|0|0|0.30778 [0.26539, 0.40615]|0.58217|0.58217|0.35548 [0.29232, 0.42220]|0.21705|0.58217|0.10373|100.0% [0.72247, 1.0000]|0.00010000 USD|
|boat|sandbox-lifetime|ms|10|0|0|0|9046.4 [5832.9, 45615]|49124|49124|20457 [9737.7, 31916]|5536.9|49124|17811|100.0% [0.72247, 1.0000]|0.0021100 USD|
|boat|tool-replay-prepare|ms|2|0|0|0|1790.0 [1790.0, 1800.0]|1800.0|1800.0|1795.0 [1790.0, 1800.0]|1790.0|1800.0|4.9665|100.0% [0.34238, 1.0000]|0.000040000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-b0c1bac599313822 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"178.33.230.53","hostname":"ns3063200.ip-178-33-230.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-ab966dc0b36a2379 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"5.39.65.118","hostname":"ns3057077.ip-5-39-65.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-c16702c8b4c1ab16 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"5.39.74.209","hostname":"ns3118687.ip-5-39-74.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-101c76393e37f84a 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"5.39.65.111","hostname":"ns315638.ip-5-39-65.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-feb373b24a5a6d29 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.105.105.202","hostname":"ns394386.ip-46-105-105.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-0ae36ff6d7baaf31 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"213.32.26.231","hostname":"ns3058437.ip-213-32-26.eu","city":"Gravelines","region":"Hauts-de-France","country":"FR","loc":"50.9865,2.1281","org":"AS16276 OVH SAS","postal":"59820","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-dd1fab27abaa68a3 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"213.32.26.231","hostname":"ns3058437.ip-213-32-26.eu","city":"Gravelines","region":"Hauts-de-France","country":"FR","loc":"50.9865,2.1281","org":"AS16276 OVH SAS","postal":"59820","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-99e3007c7146c777 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"5.39.65.94","hostname":"ns3186439.ip-5-39-65.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-f032ed99caaf98f1 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"5.135.139.7","hostname":"ns314531.ip-5-135-139.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-f52841d77ca61dec 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"5.135.139.7","hostname":"ns314531.ip-5-135-139.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|boat|USD|0.0021100|0.21100|https://docs.boat.dev/machines (2026-10-21)|Default VM $0.036/hour (4 vCPU, 8 GB, 50 GB). Flat rate for each size; Small, Large and Xlarge are also offered. $20 monthly minimum/packs excluded; billed per second.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|boat|USD|unknown|0.012000|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|boat|0/209|0.017759|0.13000|2.3046e+5|3.0108e+5|

Flagged samples:

## Run notes

- boat: Provider default image and allocation
- boat: 10 sandbox attempts, estimated budget USD 0.0021100; budget not hit.
- Cleanup boat: 0 remaining; label listing verified.
- boat/tool-replay failure: Boat request failed. The provider reported unavailable. Check the sandbox and Boat service before retrying.

## Methodology

- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
