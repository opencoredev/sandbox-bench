# Sandbox provider benchmark sbx65-r1-us-east-default-main-b1-boat

Schema v2 · 2026-10-26T02:15:13.295Z · seed 45 · track default
Allocation boat: requested null; template default
Collection: 2026-10-26T02:15:13.295Z through 2026-10-26T02:21:59.376Z
Host: AMD Ryzen 9 9955HX 16-Core Processor; linux; v26.3.0
Metadata: {"repositoryCommit":"cc96da3e33334e609c435ddefd76b1e4a67df03b","harnessCommit":"cc96da3e33334e609c435ddefd76b1e4a67df03b","sdkCommit":"1185278f6f347ff6812ffb3bd4d17e7fd6c35f3b","dirty":false,"sdkVersion":"1.0.0","runtimes":{"node":"v26.3.0","bun":"1.4.4"},"runnerRegion":"us-east","runner":{"region":"us-east","label":"us-east-ms-a2","transport":"local","host":null,"datacenter":{"provider":"home","location":"Boca Raton, FL (ms-a2)"},"batchId":"sbx65-r1"},"clientLocation":{"ip":"99.20.193.62","city":"Boca Raton","region":"Florida","country":"US","org":"AS7018 AT&T Enterprises, LLC"},"clientLocationNote":"Public egress lookup; null means lookup failed"}
Configured region boat: unspecified

cleanupReview: []
cleanupReleased: []
cleanupResolved: []

admissionStopped: []

Estimates exclude credits, subscriptions and some storage/transfer charges. Local is a reference baseline.

| Provider | Scenario | Unit | n | Fail | Blocked | Skip | p50 [95% CI] | p95 | p99 | Mean [95% CI] | Min | Max | SD | Success [Wilson CI] | Est. cost |
|---|---|---|---:|---:|---:|---:|---|---:|---:|---|---:|---:|---:|---|---:|
|boat|cold|ms|10|0|0|0|1221.0 [1099.3, 1382.1]|1681.0|1681.0|1281.3 [1169.1, 1401.2]|989.94|1681.0|191.61|100.0% [0.72247, 1.0000]|0.00019000 USD|
|boat|fingerprint|ms|10|0|0|0|1864.9 [1860.2, 1975.5]|2508.8|2508.8|1971.7 [1874.8, 2107.3]|1853.3|2508.8|196.58|100.0% [0.72247, 1.0000]|0.00022000 USD|
|boat|perf|ms|10|0|0|0|851.60 [827.85, 1851.1]|1879.2|1879.2|1172.6 [895.93, 1476.9]|827.22|1879.2|457.48|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|cpu-single|iterations/s|10|0|0|0|1.7738e+7 [1.6148e+7, 1.9758e+7]|2.0549e+7|2.0549e+7|1.8269e+7 [1.7275e+7, 1.9291e+7]|1.5843e+7|2.0549e+7|1.6062e+6|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|cpu-all|iterations/s|10|0|0|0|4.8155e+7 [3.8230e+7, 5.6136e+7]|6.2817e+7|6.2817e+7|4.9039e+7 [4.4114e+7, 5.4151e+7]|3.5209e+7|6.2817e+7|8.1360e+6|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|memory-mbps|MB/s|10|0|0|0|29173 [15345, 37781]|44576|44576|29075 [22651, 35427]|12910|44576|10029|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|disk-write-mbps|MB/s|10|0|0|0|357.99 [109.07, 426.60]|529.05|529.05|324.29 [224.09, 417.93]|91.453|529.05|154.70|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|disk-read-mbps|MB/s|10|0|0|0|13854 [8987.4, 20584]|21549|21549|15439 [12373, 18698]|8243.5|21549|5097.7|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|disk-4k-write-iops|IOPS|10|0|0|0|5301.0 [764.12, 7204.9]|8501.9|8501.9|4746.0 [3070.9, 6358.5]|706.97|8501.9|2655.2|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|disk-4k-read-iops|IOPS|10|0|0|0|6.1648e+5 [4.9192e+5, 8.2215e+5]|9.1669e+5|9.1669e+5|6.6479e+5 [5.6490e+5, 7.6878e+5]|3.9870e+5|9.1669e+5|1.6495e+5|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|tcp-ms|ms|10|0|0|0|6.3706 [5.4825, 8.9191]|11.916|11.916|7.3680 [5.9951, 8.9275]|5.3837|11.916|2.4022|100.0% [0.72247, 1.0000]|0.00014000 USD|
|boat|command|ms|10|0|0|0|326.64 [314.62, 337.07]|361.36|361.36|331.06 [321.26, 341.07]|307.50|361.36|15.838|100.0% [0.72247, 1.0000]|0.00010000 USD|
|boat|npm-install-prepare|ms|3|0|0|0|3725.1 [3651.1, 3787.0]|3787.0|3787.0|3721.1 [3651.1, 3787.0]|3651.1|3787.0|55.562|100.0% [0.43850, 1.0000]|0.00012000 USD|
|boat|npm-install|ms|3|0|0|0|847.14 [830.65, 1842.4]|1842.4|1842.4|1173.4 [830.65, 1842.4]|830.65|1842.4|473.12|100.0% [0.43850, 1.0000]|0.000040000 USD|
|boat|preview-provisioning|ms|3|0|0|0|300.44 [277.80, 301.66]|301.66|301.66|293.30 [277.80, 301.66]|277.80|301.66|10.971|100.0% [0.43850, 1.0000]|0.000030000 USD|
|boat|dev-server|ms|3|0|0|0|4098.7 [3915.8, 4549.0]|4549.0|4549.0|4187.8 [3915.8, 4549.0]|3915.8|4549.0|266.07|100.0% [0.43850, 1.0000]|0.00014000 USD|
|boat|preview-first-byte|ms|3|0|0|0|956.88 [912.73, 1235.0]|1235.0|1235.0|1034.9 [912.73, 1235.0]|912.73|1235.0|142.67|100.0% [0.43850, 1.0000]|0.000040000 USD|
|boat|edit-loop|ms|3|0|0|0|1187.2 [1170.1, 2234.5]|2234.5|2234.5|1530.6 [1170.1, 2234.5]|1170.1|2234.5|497.79|100.0% [0.43850, 1.0000]|0.000070000 USD|
|boat|tool-replay|ms|3|0|0|0|42782 [40825, 42860]|42860|42860|42156 [40825, 42860]|40825|42860|941.41|100.0% [0.43850, 1.0000]|0.0012700 USD|
|boat|files-1kb|ms|10|0|0|0|861.49 [789.99, 890.92]|1454.1|1454.1|905.65 [823.73, 1038.7]|760.54|1454.1|187.98|100.0% [0.72247, 1.0000]|0.00011000 USD|
|boat|git-clone|ms|3|0|0|0|2404.4 [2117.3, 2428.1]|2428.1|2428.1|2316.6 [2117.3, 2428.1]|2117.3|2428.1|141.23|100.0% [0.43850, 1.0000]|0.000090000 USD|
|boat|pip-install|ms|3|0|0|0|4884.6 [4169.0, 15118]|15118|15118|8057.2 [4169.0, 15118]|4169.0|15118|5001.3|100.0% [0.43850, 1.0000]|0.00026000 USD|
|boat|reconnect|ms|10|0|0|0|689.72 [653.78, 819.05]|1348.4|1348.4|800.51 [697.44, 932.99]|648.77|1348.4|200.16|100.0% [0.72247, 1.0000]|0.00011000 USD|
|boat|files-10mb|ms|9|1|0|0|7448.3 [5661.3, 17325]|25575|25575|11132 [7152.7, 15722]|5545.8|25575|6638.6|90.0% [0.59585, 0.98212]|0.0013700 USD|
|boat|destroy|ms|10|0|0|0|173.63 [169.58, 189.54]|1493.8|1493.8|317.23 [174.19, 583.35]|168.55|1493.8|393.23|100.0% [0.72247, 1.0000]|0.00011000 USD|
|boat|reconnect-cleanup|ms|10|0|0|0|0.56021 [0.53053, 0.59778]|0.97560|0.97560|0.63503 [0.54817, 0.74589]|0.51027|0.97560|0.15805|100.0% [0.72247, 1.0000]|0.00010000 USD|
|boat|sandbox-lifetime|ms|10|0|0|0|15131 [12307, 77312]|1.1402e+5|1.1402e+5|40525 [19075, 64890]|11638|1.1402e+5|36651|100.0% [0.72247, 1.0000]|0.0041200 USD|
|boat|tool-replay-prepare|ms|2|0|0|0|4813.9 [4813.9, 4829.6]|4829.6|4829.6|4821.7 [4813.9, 4829.6]|4813.9|4829.6|7.8804|100.0% [0.34238, 1.0000]|0.00010000 USD|

## Hardware

| Provider | CPU | nproc | quota | RAM GiB | Disk GiB | Kernel | Egress |
|---|---|---:|---:|---:|---:|---|---|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-bbb4eb7117d6ecd0 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"178.33.236.99","hostname":"ns3053062.ip-178-33-236.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-979111bd764f1995 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"46.105.105.222","hostname":"ns318740.ip-46-105-105.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-6cd50cf52fb0a38e 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"5.135.136.200","hostname":"ns371253.ip-5-135-136.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7509|68.578|Linux box-node-a8fc2718848853be 7.0.0-38-generic #38~24.04.4-Ubuntu SMP PREEMPT_DYNAMIC Mon Sep 14 16:37:11 UTC 2 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"213.32.26.12","hostname":"ns3241153.ip-213-32-26.eu","city":"Gravelines","region":"Hauts-de-France","country":"FR","loc":"50.9865,2.1281","org":"AS16276 OVH SAS","postal":"59820","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-775bd8b1a15fddc9 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"147.135.130.239","hostname":"ns3105500.ip-147-135-130.eu","city":"Gravelines","region":"Hauts-de-France","country":"FR","loc":"50.9865,2.1281","org":"AS16276 OVH SAS","postal":"59820","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-7b333093c6a1e03e 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"213.32.26.232","hostname":"ns3058431.ip-213-32-26.eu","city":"Gravelines","region":"Hauts-de-France","country":"FR","loc":"50.9865,2.1281","org":"AS16276 OVH SAS","postal":"59820","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-86116e0190b500c1 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"5.135.136.200","hostname":"ns371253.ip-5-135-136.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-828e63c48cf8ffcb 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"5.39.75.62","hostname":"ns3186448.ip-5-39-75.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-587f1ee380cec93e 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"37.59.33.135","hostname":"ns3172948.ip-37-59-33.eu","city":"Lille","region":"Hauts-de-France","country":"FR","loc":"50.6339,3.0551","org":"AS16276 OVH SAS","postal":"59000","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|
|boat|AMD Ryzen 9 9950X 16-Core Processor|4|unlimited|7.7552|68.568|Linux box-node-4cf91d9e178f1d67 6.8.0-138-generic #138-Ubuntu SMP PREEMPT_DYNAMIC Fri Jul 31 22:41:49 UTC 2026 x86_64 x86_64 x86_64 GNU/Linux|{"ip":"213.32.27.72","hostname":"ns3058619.ip-213-32-27.eu","city":"Gravelines","region":"Hauts-de-France","country":"FR","loc":"50.9865,2.1281","org":"AS16276 OVH SAS","postal":"59820","timezone":"Europe/Paris","readme":"https://ipinfo.io/missingauth"}|

## Estimated cost

| Provider | Currency | Lifecycle observed total | per 1000 sandbox lifetimes | Source and retrieval date | Caveats |
|---|---|---:|---:|---|---|
|boat|USD|0.0041200|0.41200|https://docs.boat.dev/machines (2026-10-21)|Default VM $0.036/hour (4 vCPU, 8 GB, 50 GB). Flat rate for each size; Small, Large and Xlarge are also offered. $20 monthly minimum/packs excluded; billed per second.|

## Full-run planning estimates

100 lifecycle/command/files/fingerprint/performance iterations; 30 of each workload; K=10 and K=25 with the configured number of burst cohorts. These are extrapolations, not quotes. Unsupported work is excluded. Larger cohorts require account capacity.

| Provider | Currency | Normal 100 (including restore overlap) | Each workload 30 | Burst 10 | Burst 25 | Total |
|---|---|---:|---:|---:|---:|---:|
|boat|USD|unknown|0.020100|unknown|unknown|unknown|

## Client headroom

Host CPU/load/network describe the harness host during each sample. High-load flag: normalized load >=1 or host busy fraction >=0.90. Network includes all host traffic; overlapping samples are not additive.

| Provider | Samples flagged / total | Mean host CPU busy | Max normalized load | Mean RX B/s | Mean TX B/s |
|---|---:|---:|---:|---:|---:|
|boat|1/209|0.33658|0.38312|6.6235e+5|4.1241e+5|

Flagged samples:
- boat/reconnect-cleanup iteration 3 at 2026-10-26T02:20:09.684Z: high host load

## Run notes

- boat: Provider default image and allocation
- boat: 10 sandbox attempts, estimated budget USD 0.0041200; budget not hit.
- Cleanup boat: 0 remaining; label listing verified.
- boat/files-10mb failure: Boat request failed. The provider reported unavailable. Check the sandbox and Boat service before retrying.

## Methodology

- Daytona snapshots use its native nameable API with a 600-second completion budget to journal a run-owned snapshot name before creation. The SDK wrapper retains recovery names in errors, but generates them internally. Other lifecycle calls use the common SDK. Snapshot timeout is retained as failure and cleanup uses only journaled names.
- Round-robin iteration admission, independent per-provider and global limits. Seeded scenario groups; dependencies (install → dev → preview → edit) retain order. Fingerprint first, cold first, destroy last. No warmup samples discarded.
- Cold and restore time adapter.create through a bare adapter true command before SDK handle initialization; burst all-ready ends at the slowest bare command. adapterCreateMs, firstCommandMs, coldMs and sdkReadyMs expose phases; sdkReadyMs includes SDK initialization and is excluded from the headline. firstCommandOKMs starts at iteration admission before host sampling and budget work. Destroy/restore-destroy time only deletion requests (including retries); live ownership verification and journal writes are recorded separately. Live ownership verification and durable journal writes are excluded from cold/burst readiness and recorded as ownershipVerifyMs/ownershipPersistMs. Reconnect/resume still use SDK command readiness.
- Tracks remain separate: default uses provider defaults (local medium); same-spec records explicitly requested allocation and factory template per provider. Fingerprints establish actual resources; a track label does not prove resource equality. Fixture uploads run in separate preparation scenarios before npm-install/tool-replay. Image, package, CDN and filesystem caches are uncontrolled.
- Dependent scenarios share a sandbox. A failed cold/reconnect/resume/snapshot blocks subsequent work; blocked_by rows are reported separately and excluded from independent failure denominators. App install/provision/start/preview prerequisites also propagate blocking. Cleanup still runs.
- Preview provisioning and dev-server start are separate scenarios. Each HTTP attempt is timed through its first chunk only; cancellation and inter-attempt sleeps are outside that measurement. Failed attempts remain failure rows. Snapshot values time native API only; snapshot-setup and snapshot-total expose client setup/journal overhead.
- Repeated burst cohorts retain independent cohort indices. Client-headroom flags use load1/logical CPUs >=1 or sampled host CPU utilization >=90%; overlapping samples share host counters and must not be summed as provider-attributable traffic.
- At n=100, nearest-rank p99 depends on roughly the two slowest observations and is unstable. Bootstrap intervals do not eliminate this tail uncertainty; publish sample counts and raw values.
- All failures retained; percentiles/CI describe successful observations only. Independent success rate uses Wilson 95% interval (skips and blocked dependencies excluded). Nearest rank, population stddev, 2000 seeded bootstrap resamples for p50 and mean. No outlier removal.
- Fingerprint includes public ipinfo.io lookup (optional); region and org are observed egress, not a promise about placement. Host counters are cumulative: difference before/after to derive CPU and network load.
- CPython fixed LCG iterations/s; all-core uses ceil of min(nproc, cgroup quota), capped at 64 with worker count recorded. Python version and CPU flags retained: runtime differences remain a confounder. 16 MiB memory copy; 64 MiB buffered sequential I/O; fsync writes and 256 random 4 KiB operations at queue depth 1. Reads may be cached; no O_DIRECT. Decimal MB/s.
- Network: 25,000,000 bytes from speed.cloudflare.com including TLS; mean of five TCP connects to 1.1.1.1:443. Egress geography, CDN caches, shared host load and provider caches are uncontrolled.
- Costs are estimates, not invoices; marginal usage only, excludes subscriptions/credits/transfer/persistent snapshot retention. Cost per scenario allocates its measured duration; sandbox-lifetime records include setup and idle time and must not be summed with scenario allocations. Upstash/boxd allocated-resource estimates are upper bounds. Unknown resources yield null, never zero. Pricing retrieval dates are recorded per provider; EUR and USD remain separate with no cross-currency ranking.
- Budget admission reserves timeout × scenario count at observed or conservative default resources. Dollar budgets are estimates, not account spend caps; boxd uses conservative 2 USD/EUR for budget only. Failed/unknown creations count toward sandbox budget.
